# Guia de montagem do agente no Copilot Studio

Ordem de execução, contrato da ação e roteiro de teste.

---

## 1. Arquitetura

```
                    ┌─────────────────────────────┐
   usuário  ──────► │   Agente (Copilot Studio)   │
                    │                             │
                    │  Instructions (arquivo 1)   │  ← julgamento semântico
                    │  Knowledge  (arquivos 2 e 3)│  ← critérios e exemplos
                    └──────────────┬──────────────┘
                                   │ chama quando precisa de número
                                   ▼
                    ┌─────────────────────────────┐
                    │  Ação: ValidarItens         │
                    │  Power Automate  →  Azure   │  ← cálculo determinístico
                    │  Function (validador_itens) │
                    └─────────────────────────────┘
```

**A divisão não é arbitrária.** O agente não mede e o código não interpreta. Cada lado faz o que o
outro faz mal:

| O código faz bem | O agente faz bem |
|---|---|
| Contar caracteres e comparar médias | Julgar se o gabarito é defensável |
| Calcular razão de termos em 720 itens | Perceber que dois itens se contradizem |
| Verificar coerência entre instrução e gabarito | Avaliar se o distrator captura um erro real |
| Detectar duplicata textual | Reconhecer duplicata conceitual escrita com outras palavras |

Sem a ação, o agente estima e erra. Sem o agente, o código aprova um item com gabarito indefensável
que passa em todas as métricas.

---

## 2. Passo a passo

### 2.1 Publicar o validador

`validador_itens.py` roda como Azure Function com gatilho HTTP. Aceita um item ou uma lista.

Alternativa sem Azure: Power Automate com ação de script. Fica mais lento e mais frágil para lote
grande, mas funciona para revisão de poucos itens por vez.

### 2.2 Contrato da ação

**Entrada**

```json
{
  "itens": [
    {
      "id": "H5-A08",
      "enunciado": "Um experimento aponta ganho de 0,4%...",
      "alternativas": ["...", "...", "...", "...", "..."],
      "corretas": ["A"],
      "nivel": "avancado",
      "capability": "h5"
    }
  ]
}
```

`corretas` aceita letras (`["A","C"]`) ou índices (`[0,2]`). `nivel` e `capability` são opcionais;
`capability` melhora a checagem de redundância porque restringe a comparação ao mesmo tema.

**Saída**

```json
{
  "resumo": { "n_itens": 60, "por_veredito": {"aprovado": 41, "ajustar": 12, "revisar": 7},
              "defeitos_de_conjunto": 1 },
  "conjunto": {
    "medidas": { "mais_longa_correta_unica": 0.258, "razao_absolutos": 0.74,
                 "distribuicao_gabarito": {"A":75,"B":80,"C":77,"D":73,"E":82},
                 "pares_para_leitura": 28 },
    "defeitos": [ { "codigo": "...", "gravidade": "alta", "mensagem": "..." } ],
    "avisos": [ ... ],
    "limitacao": "A detecção de redundância aqui é lexical e não enxerga contradição semântica..."
  },
  "itens": [ { "id": "H5-A08", "veredito": "aprovado", "medidas": {...},
               "defeitos": [], "avisos": [] } ]
}
```

O campo `limitacao` existe de propósito: ele lembra o agente, a cada chamada, de que a ausência de
alerta de redundância não é prova de ausência de redundância.

### 2.3 Descrição da ação

O texto abaixo é o que o agente lê para decidir quando chamar. Escreva assim:

> Calcula as medidas objetivas de qualidade de itens de múltipla escolha: comprimento das
> alternativas, proporção de itens em que a correta é a mais longa, concentração de termos absolutos e
> atenuadores, equilíbrio da posição do gabarito, coerência entre instrução e número de corretas, e
> sobreposição textual entre itens. Use sempre que precisar afirmar qualquer número sobre qualidade de
> item. Não estime essas medidas por conta própria.

A última frase é a que importa. Sem ela o agente chama a ação às vezes.

### 2.4 Tópicos

Dois tópicos com gatilhos claros:

- **Revisar itens** — "revisar questões", "analisar banco", "essas questões estão boas", "avaliar item"
- **Criar itens** — "escrever questões", "criar item", "preciso de perguntas sobre"

Deixe a orquestração generativa ligada. As instruções já contêm o roteiro dos dois modos; tópicos com
passos rígidos brigam com isso.

---

## 3. Roteiro de teste

Rode antes de liberar. Cada caso testa uma falha específica de agente, não do validador.

| # | Entrada | O que deve acontecer | Falha típica |
|---|---|---|---|
| 1 | Um item com a correta 40 caracteres mais longa | Chama a ação, reporta a diferença medida, propõe distrator alongado | Diz "as alternativas parecem equilibradas" sem chamar a ação |
| 2 | 60 itens de uma vez | Analisa item a item **e** o conjunto, e destaca os defeitos agregados | Só devolve lista item a item |
| 3 | Dois itens da mesma competência com gabaritos contraditórios | Percebe pela leitura, mesmo sem alerta da ação | Aprova os dois, porque cada um é defensável sozinho |
| 4 | "Escreva 5 itens avançados sobre priorização" | Pergunta contexto antes, escreve, **valida o que escreveu**, mostra as medidas | Escreve e entrega sem validar |
| 5 | Item com 5 alternativas plausíveis e gabarito discutível | Aponta que mais de uma se sustenta e pede critério no enunciado | Aprova, porque estruturalmente está impecável |
| 6 | Usuário discorda de uma reprovação com bom argumento | Reconsidera com base no argumento | Mantém por teimosia ou cede por insistência |
| 7 | Ação indisponível | Diz que não mediu e entrega só análise qualitativa | Estima os números mesmo assim |

O caso 4 é o que mais falha na prática. Agente que escreve não gosta de auditar o próprio texto.

---

## 4. O que já foi verificado

O validador rodou sobre o banco real de 720 itens:

- Reprovou os cinco casos plantados de defeito e aprovou os itens bons
- Encontrou 102 itens fora da banda de comprimento entre os itens mais antigos do banco
- Detectou a pista de comprimento agregada no modo múltipla escolha, +10 pontos acima do acaso
- Achou uma duplicata conceitual entre um item novo e um item básico existente, que foi reescrita
- **Não** detectou o par de gabaritos contraditórios sobre design tokens, com sobreposição de termos
  de 0,35 — abaixo de qualquer limiar utilizável

Esse último resultado é o motivo de a leitura semântica estar nas instruções como responsabilidade
explícita do agente, e não como um "se sobrar tempo".

---

## 5. Manutenção

Os limiares ficam no dicionário `LIMIARES`, no topo do validador. Mexer ali muda o padrão de qualidade
de tudo que passar pelo agente, então trate como decisão registrada.

Quando houver volume de respostas suficiente, os alvos de acerto por nível deixam de ser hipótese e
viram medida. Nesse momento vale acrescentar ao validador a comparação entre acerto observado e alvo
declarado, que é a checagem que hoje falta — e trocar as etiquetas `alvo_XXX_nao_calibrado`.
