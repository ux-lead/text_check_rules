# -*- coding: utf-8 -*-
"""
Validador determinístico de itens de assessment.

Existe porque a maior parte dos critérios de qualidade de item é cálculo, não julgamento.
Um modelo de linguagem estima esses números e erra: numa das versões do banco de CX,
a alternativa correta era a mais longa em 76% dos itens de escolha única — contra 20%
de acaso — sem que ninguém percebesse pela leitura.

Uso como ação do agente (Azure Function / Power Automate):
    entrada  -> JSON com um item ou uma lista de itens
    saída    -> JSON com veredito, medidas e defeitos, por item e do conjunto

Uso local:
    python validador_itens.py banco.csv          # CSV separado por ; no formato HackerRank
    python validador_itens.py item.json          # um item ou lista de itens
"""
from __future__ import annotations
import json, re, sys, unicodedata, statistics as st
from difflib import SequenceMatcher

# ----------------------------------------------------------------------------
# LIMIARES — mexer aqui muda o padrão de qualidade de todo o banco
# ----------------------------------------------------------------------------
LIMIARES = {
    "banda_comprimento_caracteres": 8,      # |média(corretas) - média(distratores)|
    "mais_longa_correta_max_unica": 0.28,   # acaso = 0,20
    "mais_longa_correta_max_multipla": 0.68,# acaso = 0,60
    "razao_lexical_min": 0.60,              # distratores / corretas
    "razao_lexical_max": 1.70,
    "desvio_gabarito_max": 0.25,            # desvio sobre o esperado por letra
    "similaridade_redundancia": 0.72,     # texto corrido, SequenceMatcher
    "dice_redundancia": 0.45,             # sobreposição de termos de conteúdo
    "enunciado_max_caracteres": 220,
    "alternativa_max_caracteres": 120,
    "alternativa_min_caracteres": 15,
}

ABSOLUTOS = ["sempre", "nunca", "todos", "todas", "nenhum", "nenhuma",
             "qualquer", "apenas", "somente", "impossivel", "jamais", "totalmente"]
ATENUADORES = ["tende", "pode", "geralmente", "costuma", "em geral",
               "normalmente", "eventualmente", "talvez"]
NEGATIVAS = ["não", "exceto", "incorreto", "errado", "menos"]


def _sem_acento(t: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", t.lower())
                   if unicodedata.category(c) != "Mn")


def _tem(texto: str, lista) -> bool:
    t = _sem_acento(texto)
    return any(_sem_acento(p) in t for p in lista)


VAZIAS = set("a o e de da do das dos em um uma que se com por para na no as os ao aos como qual "
             "quais ou nao mais menos sobre entre seu sua seus suas isso este esta esse essa".split())


def _limpa_enunciado(t: str) -> str:
    return re.sub(r"selecione\s+\d+\s+alternativas?\s+corretas?\.?", "", _sem_acento(t)).strip()


def _tokens(t: str) -> set:
    return {w for w in re.findall(r"\w+", t) if w not in VAZIAS and len(w) > 2}


# ----------------------------------------------------------------------------
# NÍVEL DO ITEM
# ----------------------------------------------------------------------------
def validar_item(item: dict) -> dict:
    """item = {id, enunciado, alternativas[], corretas[índices ou letras], nivel, capability}"""
    defeitos, avisos, medidas = [], [], {}
    enun = (item.get("enunciado") or "").strip()
    alts = [a.strip() for a in (item.get("alternativas") or [])]
    cor = item.get("corretas") or []
    if cor and isinstance(cor[0], str):
        cor = [ord(c.strip().upper()) - 65 for c in cor]
    cor = sorted(set(int(c) for c in cor))
    dis = [i for i in range(len(alts)) if i not in cor]

    # --- estrutura ---
    if not enun:
        defeitos.append({"codigo": "SEM_ENUNCIADO", "gravidade": "critica",
                         "mensagem": "O item não tem enunciado."})
    if len(alts) < 4:
        defeitos.append({"codigo": "POUCAS_ALTERNATIVAS", "gravidade": "critica",
                         "mensagem": f"{len(alts)} alternativas. O mínimo operacional é 4, e 5 reduz o acerto por chute de 25% para 20%."})
    if not cor:
        defeitos.append({"codigo": "SEM_GABARITO", "gravidade": "critica",
                         "mensagem": "Nenhuma alternativa marcada como correta."})
    if len(cor) == len(alts):
        defeitos.append({"codigo": "TUDO_CORRETO", "gravidade": "critica",
                         "mensagem": "Todas as alternativas estão marcadas como corretas."})
    if not alts or not cor:
        return {"id": item.get("id"), "veredito": "reprovado", "defeitos": defeitos,
                "avisos": avisos, "medidas": medidas}

    modo = "multipla" if len(cor) > 1 else "unica"
    medidas["modo"] = modo
    medidas["n_alternativas"] = len(alts)
    medidas["n_corretas"] = len(cor)

    if modo == "multipla":
        pede = re.search(r"selecione\s+(\d+|uma|duas|tr[eê]s|quatro)", _sem_acento(enun))
        NUM = {"uma": 1, "duas": 2, "tres": 3, "quatro": 4}
        if not pede:
            defeitos.append({"codigo": "MULTIPLA_SEM_INSTRUCAO", "gravidade": "alta",
                             "mensagem": "Item de múltipla escolha sem dizer quantas alternativas selecionar. A plataforma exibe rótulo genérico e a pessoa fica sem saber quantas marcar."})
        else:
            g = pede.group(1)
            n = int(g) if g.isdigit() else NUM.get(g, 0)
            if n and n != len(cor):
                defeitos.append({"codigo": "INSTRUCAO_DIVERGE_GABARITO", "gravidade": "critica",
                                 "mensagem": f"O enunciado pede {n} alternativas e o gabarito tem {len(cor)}."})
    else:
        if re.search(r"selecione\s+\d", _sem_acento(enun)):
            defeitos.append({"codigo": "UNICA_COM_INSTRUCAO_MULTIPLA", "gravidade": "critica",
                             "mensagem": "Item de resposta única com instrução de múltipla escolha no enunciado."})

    # --- comprimento ---
    lc = [len(alts[i]) for i in cor]
    ld = [len(alts[i]) for i in dis]
    dif = st.mean(lc) - st.mean(ld) if ld else 0.0
    medidas["comprimento_medio_corretas"] = round(st.mean(lc), 1)
    medidas["comprimento_medio_distratores"] = round(st.mean(ld), 1) if ld else None
    medidas["diferenca_comprimento"] = round(dif, 1)
    if abs(dif) > LIMIARES["banda_comprimento_caracteres"]:
        defeitos.append({"codigo": "PISTA_COMPRIMENTO", "gravidade": "alta",
                         "mensagem": f"Diferença de {dif:+.0f} caracteres entre correta e distratores, acima da banda de ±{LIMIARES['banda_comprimento_caracteres']}. "
                                     f"{'Alongue um distrator.' if dif > 0 else 'Encurte a correta ou alongue os distratores.'}"})
    mais_longa = max(range(len(alts)), key=lambda i: len(alts[i]))
    medidas["mais_longa_e_correta"] = mais_longa in cor
    if mais_longa in cor and modo == "unica":
        avisos.append({"codigo": "MAIS_LONGA_E_CORRETA",
                       "mensagem": "A alternativa correta é a mais longa. Isoladamente é aceitável; no conjunto, não pode passar de 28% dos itens."})

    curtas = [i for i, a in enumerate(alts) if len(a) < LIMIARES["alternativa_min_caracteres"]]
    if curtas:
        avisos.append({"codigo": "ALTERNATIVA_MUITO_CURTA",
                       "mensagem": f"Alternativas muito curtas nas posições {[chr(65+i) for i in curtas]}. Alternativa curta demais costuma ser descartável de imediato."})
    longas = [i for i, a in enumerate(alts) if len(a) > LIMIARES["alternativa_max_caracteres"]]
    if longas:
        avisos.append({"codigo": "ALTERNATIVA_MUITO_LONGA",
                       "mensagem": f"Alternativas acima de {LIMIARES['alternativa_max_caracteres']} caracteres em {[chr(65+i) for i in longas]}."})
    medidas["comprimento_enunciado"] = len(enun)
    if len(enun) > LIMIARES["enunciado_max_caracteres"]:
        avisos.append({"codigo": "ENUNCIADO_LONGO",
                       "mensagem": f"Enunciado com {len(enun)} caracteres. Acima de {LIMIARES['enunciado_max_caracteres']} o item passa a medir leitura junto com conhecimento."})

    # --- léxico ---
    abs_c = sum(1 for i in cor if _tem(alts[i], ABSOLUTOS))
    abs_d = sum(1 for i in dis if _tem(alts[i], ABSOLUTOS))
    ate_c = sum(1 for i in cor if _tem(alts[i], ATENUADORES))
    ate_d = sum(1 for i in dis if _tem(alts[i], ATENUADORES))
    medidas["absolutos_corretas"] = abs_c
    medidas["absolutos_distratores"] = abs_d
    medidas["atenuadores_corretas"] = ate_c
    medidas["atenuadores_distratores"] = ate_d
    if abs_c == 0 and abs_d >= max(2, len(dis)):
        avisos.append({"codigo": "ABSOLUTOS_SO_NOS_DISTRATORES",
                       "mensagem": "Termos absolutos aparecem só nos distratores. Quem conhece o truque elimina sem saber o conteúdo."})
    if ate_d == 0 and ate_c == len(cor) and len(cor) > 1:
        avisos.append({"codigo": "ATENUADORES_SO_NAS_CORRETAS",
                       "mensagem": "Atenuadores aparecem só nas corretas — é a mesma pista invertida."})

    # --- enunciado ---
    if _tem(enun, ["nao ", "exceto", "incorret"]) and "?" in enun:
        avisos.append({"codigo": "ENUNCIADO_NEGATIVO",
                       "mensagem": "Enunciado na forma negativa. Se for intencional, destaque a negação; se não, reescreva na positiva."})
    if not enun.rstrip().endswith(("?", ":", ".")):
        avisos.append({"codigo": "ENUNCIADO_SEM_PERGUNTA",
                       "mensagem": "O enunciado não fecha em pergunta. A tarefa precisa estar clara antes de a pessoa ler as alternativas."})

    # --- sobreposição entre alternativas ---
    for i in range(len(alts)):
        for j in range(i + 1, len(alts)):
            s = SequenceMatcher(None, _sem_acento(alts[i]), _sem_acento(alts[j])).ratio()
            if s >= 0.80:
                grav = "alta" if (i in cor) != (j in cor) else "media"
                defeitos.append({"codigo": "ALTERNATIVAS_QUASE_IGUAIS", "gravidade": grav,
                                 "mensagem": f"Alternativas {chr(65+i)} e {chr(65+j)} são {s:.0%} semelhantes."
                                             + (" Uma é correta e a outra não, o que torna o item indefensável." if grav == "alta" else "")})

    crit = [d for d in defeitos if d["gravidade"] == "critica"]
    alta = [d for d in defeitos if d["gravidade"] == "alta"]
    veredito = "reprovado" if crit else ("ajustar" if alta else ("revisar" if avisos else "aprovado"))
    return {"id": item.get("id"), "veredito": veredito, "medidas": medidas,
            "defeitos": defeitos, "avisos": avisos}


# ----------------------------------------------------------------------------
# NÍVEL DO CONJUNTO — os defeitos que só existem no agregado
# ----------------------------------------------------------------------------
def validar_conjunto(itens: list) -> dict:
    res = {"n_itens": len(itens), "medidas": {}, "defeitos": [], "avisos": []}
    if not itens:
        return res
    norm = []
    for it in itens:
        alts = [a.strip() for a in (it.get("alternativas") or [])]
        cor = it.get("corretas") or []
        if cor and isinstance(cor[0], str):
            cor = [ord(c.strip().upper()) - 65 for c in cor]
        cor = sorted(set(int(c) for c in cor))
        if alts and cor:
            norm.append({**it, "alternativas": alts, "corretas": cor})
    for modo, chave, acaso in [("unica", "mais_longa_correta_max_unica", 0.20),
                               ("multipla", "mais_longa_correta_max_multipla", 0.60)]:
        sub = [x for x in norm if (len(x["corretas"]) > 1) == (modo == "multipla")]
        if len(sub) < 10:
            continue
        acertos = sum(1 for x in sub
                      if max(range(len(x["alternativas"])), key=lambda i: len(x["alternativas"][i])) in x["corretas"])
        taxa = acertos / len(sub)
        res["medidas"][f"mais_longa_correta_{modo}"] = round(taxa, 3)
        res["medidas"][f"n_{modo}"] = len(sub)
        if taxa > LIMIARES[chave]:
            res["defeitos"].append({"codigo": f"PISTA_COMPRIMENTO_CONJUNTO_{modo.upper()}", "gravidade": "alta",
                                    "mensagem": f"Em {taxa:.0%} dos itens de {modo} a correta é a mais longa, contra {acaso:.0%} de acaso. "
                                                f"Quem sempre escolher a alternativa mais longa acerta {(taxa-acaso)*100:.0f} pontos acima do chute, sem saber o conteúdo."})
    for nome, lista in [("absolutos", ABSOLUTOS), ("atenuadores", ATENUADORES)]:
        tc = td = ac = ad = 0
        for x in norm:
            for i, a in enumerate(x["alternativas"]):
                hit = _tem(a, lista)
                if i in x["corretas"]:
                    tc += 1; ac += hit
                else:
                    td += 1; ad += hit
        if tc and td and ac:
            razao = (ad / td) / (ac / tc)
            res["medidas"][f"razao_{nome}"] = round(razao, 2)
            if not (LIMIARES["razao_lexical_min"] <= razao <= LIMIARES["razao_lexical_max"]):
                onde = "distratores" if razao > 1 else "corretas"
                res["defeitos"].append({"codigo": f"PISTA_LEXICAL_{nome.upper()}", "gravidade": "alta",
                                        "mensagem": f"Termos {nome} aparecem {razao:.1f}x mais nos {onde}. Vira regra de eliminação independente do conteúdo."})
    letras = {}
    unicas = [x for x in norm if len(x["corretas"]) == 1]
    for x in unicas:
        L = chr(65 + x["corretas"][0]); letras[L] = letras.get(L, 0) + 1
    if len(unicas) >= 20:
        esp = len(unicas) / max(len(set(len(x["alternativas"]) for x in unicas)) and 5, 5)
        pior = max(abs(v - esp) for v in letras.values()) if letras else 0
        res["medidas"]["distribuicao_gabarito"] = letras
        if pior > esp * LIMIARES["desvio_gabarito_max"]:
            res["defeitos"].append({"codigo": "GABARITO_DESEQUILIBRADO", "gravidade": "media",
                                    "mensagem": f"A posição da resposta correta está concentrada: {letras}. Esperado ~{esp:.0f} por letra."})
    pares = []
    for i in range(len(norm)):
        for j in range(i + 1, len(norm)):
            if norm[i].get("capability") and norm[i].get("capability") != norm[j].get("capability"):
                continue
            a = _limpa_enunciado(norm[i].get("enunciado", ""))
            b = _limpa_enunciado(norm[j].get("enunciado", ""))
            seq = SequenceMatcher(None, a, b).ratio()
            ta, tb = _tokens(a), _tokens(b)
            dice = 2 * len(ta & tb) / (len(ta) + len(tb)) if (ta and tb) else 0.0
            if seq >= LIMIARES["similaridade_redundancia"] or dice >= LIMIARES["dice_redundancia"]:
                pares.append({"a": norm[i].get("id"), "b": norm[j].get("id"),
                              "similaridade_texto": round(seq, 2), "sobreposicao_termos": round(dice, 2),
                              "termos_comuns": sorted(ta & tb)[:8]})
    res["medidas"]["pares_para_leitura"] = len(pares)
    if pares:
        res["avisos"].append({"codigo": "ITENS_PARA_LEITURA_HUMANA",
                              "mensagem": f"{len(pares)} pares de itens da mesma capability com sobreposição de tema. Não é veredito: é lista de leitura. Verifique se as duas questões perguntam a mesma coisa e dão respostas incompatíveis entre si.",
                              "pares": pares[:25]})
    res["limitacao"] = ("A detecção de redundância aqui é lexical e não enxerga contradição semântica. "
                        "Caso real do banco de CX: dois itens perguntavam como introduzir tokens em legado e traziam gabaritos "
                        "incompatíveis, com sobreposição de termos de apenas 0,35 — abaixo de qualquer limiar utilizável. "
                        "Contradição entre gabaritos, defensabilidade da chave e aderência ao nível são responsabilidade do "
                        "agente, que precisa ler os itens da mesma capability em conjunto.")
    return res


def validar(payload) -> dict:
    itens = payload if isinstance(payload, list) else payload.get("itens", [payload])
    porItem = [validar_item(i) for i in itens]
    conj = validar_conjunto(itens)
    cont = {}
    for r in porItem:
        cont[r["veredito"]] = cont.get(r["veredito"], 0) + 1
    return {"resumo": {"n_itens": len(itens), "por_veredito": cont,
                       "defeitos_de_conjunto": len(conj["defeitos"])},
            "conjunto": conj, "itens": porItem}


# ----------------------------------------------------------------------------
def _do_csv(caminho):
    import csv as _csv
    itens = []
    for r in _csv.DictReader(open(caminho, encoding="utf-8-sig"), delimiter=";"):
        alts = [r.get(L, "") for L in "ABCDE" if (r.get(L) or "").strip()]
        cor = [x.strip() for x in (r.get("Answers") or "").split(",") if x.strip()]
        cap = re.search(r"cap_(\w+)", r.get("Tags", "") or "")
        itens.append({"id": (r.get("Name") or "").split(".")[0].strip(),
                      "enunciado": r.get("Description", ""), "alternativas": alts,
                      "corretas": cor, "capability": cap.group(1) if cap else None})
    return itens


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__); sys.exit(0)
    p = sys.argv[1]
    dados = _do_csv(p) if p.lower().endswith(".csv") else json.load(open(p, encoding="utf-8"))
    saida = validar(dados)
    print(json.dumps(saida["resumo"], ensure_ascii=False, indent=2))
    print("\n--- conjunto ---")
    print(json.dumps(saida["conjunto"]["medidas"], ensure_ascii=False, indent=2))
    for d in saida["conjunto"]["defeitos"] + saida["conjunto"]["avisos"]:
        print(f"  [{d['codigo']}] {d['mensagem']}")
    ruins = [r for r in saida["itens"] if r["veredito"] in ("reprovado", "ajustar")]
    print(f"\n--- itens com defeito: {len(ruins)} ---")
    for r in ruins[:40]:
        print(f"  {r['id']}  {r['veredito']}")
        for d in r["defeitos"]:
            print(f"     [{d['gravidade']}] {d['mensagem']}")
