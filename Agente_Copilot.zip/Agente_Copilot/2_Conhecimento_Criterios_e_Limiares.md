# Critérios de qualidade de item — base de conhecimento do agente

Documento para subir como knowledge source no Copilot Studio. Contém os critérios, os limiares e o
raciocínio por trás de cada um. Os limiares vieram da construção de um banco de 720 itens para
assessment de competências, com duas rodadas de homologação e 23 participantes.

Nada aqui substitui as instruções do agente. Isto é referência de consulta, não comando.

---

## 1. As duas famílias de defeito

**Defeito de item.** Mora dentro de uma questão. Gabarito indefensável, distrator absurdo,
alternativas quase idênticas, enunciado que não pergunta nada.

**Defeito de conjunto.** Só existe quando você olha o banco inteiro, e é o mais perigoso, porque
nenhum item isolado parece errado. Foi assim que 720 itens chegaram a ter uma pista explorável sem
que nenhuma revisão individual percebesse.

Revisar item por item e aprovar cada um não diz nada sobre a qualidade do conjunto.

---

## 2. Pistas estruturais — o que faz alguém acertar sem saber

### 2.1 Pista de comprimento

Quem escreve item tende a caprichar na resposta certa. Ela sai mais completa, mais qualificada, mais
longa. Vira uma regra: escolha a maior.

| Medida | Limiar | Por quê |
|---|---|---|
| Diferença entre média das corretas e média dos distratores, por item | ±8 caracteres | Banda operacional; acima disso a diferença começa a ser perceptível |
| Itens de resposta única em que a correta é a mais longa | ≤ 28% | Acaso com 5 alternativas = 20% |
| Itens de múltipla em que a mais longa é correta | ≤ 68% | Acaso com 3 corretas de 5 = 60% |

**Caso real.** Num banco em construção, a correta era a mais longa em 71% a 76% dos itens de escolha
única. Uma pessoa que sempre marcasse a alternativa mais longa acertaria mais de três vezes o que
acertaria chutando. O gate de ±8 caracteres por item derrubou isso para 18,5%.

**Armadilha.** Passar na banda por item não garante passar no conjunto. Com 1 correta e 4
distratores, uma diferença pequena e consistente ainda coloca a correta em primeiro lugar com
frequência alta. As duas medidas precisam ser verificadas.

**Correção.** Alongue um distrator, não encurte a correta. Encurtar a correta costuma custar precisão.

### 2.2 Pista lexical

Quem escreve distrator recorre a absolutos para deixá-lo errado — "sempre", "nunca", "todos",
"apenas". E qualifica a correta com atenuadores — "tende a", "geralmente", "pode". As duas coisas
criam a mesma regra de eliminação.

| Medida | Limiar |
|---|---|
| Razão entre a frequência de absolutos nos distratores e nas corretas | entre 0,6x e 1,7x |
| Mesma razão para atenuadores | entre 0,6x e 1,7x |

**Caso real.** Num banco herdado, termos absolutos apareciam em 22,7% dos distratores e em 3,9% das
corretas — 5,8 vezes mais. Dois homologadores relataram espontaneamente que "algumas alternativas
erradas eram óbvias demais", sem saber apontar o mecanismo. Depois da correção a razão ficou em 1,0x,
e dois participantes comentaram, também sem serem perguntados, que "a resposta não está tão evidente".

**Atenção ao inverter.** Corrigir com a mão pesada produz o defeito espelhado, com absolutos
concentrados nas corretas. A meta é paridade, não inversão.

### 2.3 Posição do gabarito

Se a resposta certa cai mais em uma letra, quem percebe ganha vantagem. Distribua de forma
aproximadamente uniforme, com desvio máximo de 25% sobre o esperado por letra. Embaralhamento
determinístico por identificador do item resolve isso e mantém o banco reproduzível.

### 2.4 Pista de completude

Em múltipla escolha, se a correta é sempre a que menciona mais elementos, a contagem vira atalho.
Iguale o número de elementos citados entre todas as alternativas.

---

## 3. Defensabilidade do gabarito

Nenhum limiar detecta isto. É leitura.

**Teste do advogado.** Escolha o distrator mais forte e escreva o melhor argumento possível a favor
dele. Se o argumento se sustenta sob uma interpretação razoável do enunciado, o item precisa de
conserto: ou o enunciado ganha o contexto que elimina a ambiguidade, ou o distrator é reescrito.

**Caso real.** Um item básico perguntava o custo de definir conteúdo tarde no ciclo, e as cinco
alternativas descreviam custos reais. Perguntar "o" custo quando há vários defensáveis é gabarito
discutível, não item difícil. Ninguém acertou, e a leitura preguiçosa foi classificar como "difícil".

**Sinal de alerta no dado.** Item que todo mundo erra costuma ser gabarito ruim, não conteúdo duro.

---

## 4. Contradição entre itens

Duas questões da mesma competência que perguntam a mesma coisa e trazem gabaritos incompatíveis
penalizam exatamente quem responde com coerência.

**Caso real.** Dois itens sobre como introduzir design tokens em um produto legado. Um tinha como
correta a substituição incremental e rejeitava explicitamente a camada de tradução. O outro tinha a
camada progressiva de equivalência como correta. Um participante apontou um deles como ambíguo.

**Por que nenhum detector pega.** A sobreposição de termos entre os dois enunciados era de 0,35 e a
similaridade textual de 0,57 — abaixo de qualquer limiar que não inundasse de falso positivo. Só a
leitura conjunta dos itens da mesma competência encontra esse tipo de defeito.

---

## 5. Distratores

Um distrator existe para capturar um erro de raciocínio específico e reconhecível. Escreva-o a partir
da pergunta "quem responderia isso, e por qual raciocínio?". Se não houver resposta, o distrator é
enchimento e o item passa a ter menos opções do que aparenta.

Evite:
- "Todas as anteriores" e "nenhuma das anteriores" — transformam o item em teste de lógica
- Distratores que se sobrepõem entre si — se duas alternativas dizem quase a mesma coisa, ou as duas estão certas ou as duas estão erradas, e a pessoa deduz isso
- Distrator verdadeiro no mundo mas irrelevante para a pergunta — gera contestação legítima

---

## 6. Níveis de dificuldade

| Nível | O que cobra | Alvo de acerto |
|---|---|---|
| Básico | Reconhecer o conceito correto | ~80% |
| Intermediário | Aplicar em uma situação concreta | ~65% |
| Avançado | Julgar entre alternativas todas defensáveis, com trade-offs distintos | ~50% |

O que separa os níveis é a natureza da tarefa cognitiva, não a obscuridade do vocabulário. Item
avançado não é item com jargão raro: é item em que todas as alternativas são defensáveis e uma é
mais defensável que as outras.

**Como verificar se a escala existe de fato.** Meça o acerto por nível. Se os três níveis produzem
resultados parecidos, você tem um nível só com três nomes. Num banco real, itens antigos
reaproveitados marcavam 85%, 89% e 83% nos três níveis — uma linha reta — enquanto os itens novos
faziam 64%, 53% e 48%. Cada item antigo sorteado apagava um degrau da escala.

---

## 7. Enunciado

- Feche em pergunta. A tarefa precisa estar clara antes das alternativas.
- Prefira situação a definição.
- Evite negativa; se for necessária, destaque-a.
- Acima de 220 caracteres o item começa a medir leitura junto com conhecimento.
- Jargão em outro idioma: use apenas o que a pessoa realmente encontra no trabalho. Num banco real, a
  proporção de itens com termo em inglês caiu de 22% para 12% e quatro pessoas haviam reclamado disso.

**Custo conhecido.** Endurecer itens costuma reduzir a clareza percebida. Na segunda rodada de um
banco recalibrado, "clareza dos enunciados" foi a única escala que piorou, de 4,2 para 3,71. É um
custo real do aumento de dificuldade e precisa ser vigiado, não ignorado.

---

## 8. Limites do que a revisão consegue provar

Índice de dificuldade, poder de discriminação e análise de distratores exigem dezenas de respostas
por item. Um piloto pequeno não produz isso: em um caso real, 11 pessoas responderam 60 questões cada
e as respostas se espalharam por 437 itens distintos, com 272 vistos por uma única pessoa.

Enquanto não houver volume, todo alvo de dificuldade é hipótese. Marque como hipótese — por exemplo,
com uma etiqueta `alvo_065_nao_calibrado` — para que ninguém trate a estimativa como medida.

---

## 9. Vieses de quem escreve

- **Do autor.** Quem escreve o item já sabe a resposta e não enxerga a ambiguidade.
- **Da otimização estrutural.** Itens editados para corrigir pista estrutural têm taxa de rejeição de
  conteúdo mais alta que itens não tocados. Numa medição, 6,4% contra 2,5%. Ao mexer na forma, releia
  o sentido.
- **Da confirmação na revisão.** Revisar procurando aprovar encontra menos defeito que revisar
  procurando o mecanismo pelo qual o item pode ser derrotado.
