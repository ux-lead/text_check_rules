# Exemplos anotados — base de conhecimento do agente

Itens reais de um banco de assessment de competências, com o diagnóstico de cada um. Segundo arquivo
para subir como knowledge source. Serve para o agente calibrar o padrão pelo exemplo, não só pela regra.

---

## Parte 1 — Itens que funcionam

### Exemplo A · avançado, resposta única

**H5-A08 · Experimento com efeito pequeno** — gabarito (A)

> Um experimento aponta ganho de 0,4% com intervalo que quase toca o zero. Qual leitura é mais responsável?
> - (A) Considerar o efeito indistinguível e decidir por outro critério ← **correta**
> - (B) Manter a mudança, já que a direção observada é positiva
> - (C) Repetir o experimento com amostra maior antes de decidir
> - (D) Segmentar o resultado em busca de um grupo com efeito maior
> - (E) Descartar a mudança por não ter demonstrado nenhum ganho relevante

**Por que é bom.** As cinco alternativas são condutas que gente experiente de fato adota. (B) é o
otimismo com o dado, (C) é a fuga para mais pesquisa, (D) é pescaria de subgrupo, (E) é o erro
espelhado de tratar ausência de efeito como efeito negativo. Nenhuma é absurda, e é por isso que o
item mede julgamento. Comprimentos entre 52 e 66 caracteres, sem pista. A correta não é a mais longa.

### Exemplo B · intermediário, múltipla escolha

**H9-I07 · Mensagem de erro acessível** — gabarito (A, B, C)

> O que torna uma mensagem de erro acessível a quem usa leitor de tela? Selecione 3 alternativas corretas.
> - (A) O erro é associado ao campo a que se refere ← **correta**
> - (B) A mudança é anunciada sem que a pessoa precise procurar ← **correta**
> - (C) O texto descreve o que fazer, e não apenas o que falhou ← **correta**
> - (D) Um ícone de alerta acompanha o texto da mensagem
> - (E) A mensagem aparece em cor distinta do restante do texto

**Por que é bom.** Os dois distratores são boas práticas de verdade — só que visuais, e a pergunta é
sobre leitor de tela. Quem responde precisa reconhecer que o recorte da pergunta exclui a solução
correta em outro contexto. Distrator que está certo em outro cenário é mais forte que distrator falso.

### Exemplo C · o distrator que veio do erro real

**H1-I09 · Sinais de que o problema foi mal enquadrado** — gabarito (A, C, D)

> - (B) As entrevistas trouxeram temas que não estavam no roteiro
> - (E) O discovery levou mais tempo do que estava previsto

**Por que os distratores funcionam.** Os dois descrevem coisas que acontecem em discovery e que uma
pessoa ansiosa interpretaria como sinal de problema — mas são normalidade. Cada um captura um erro de
leitura específico e reconhecível.

---

## Parte 2 — Defeitos reais, com o mecanismo

### Defeito 1 · Gabaritos contraditórios entre dois itens

**H6-I03** — Como introduzir tokens em um produto legado sem interromper as entregas?
Correta: *substituir por token as telas que já seriam tocadas por outra razão.*
Distrator (C): *manter uma camada de tradução permanente entre valor antigo e token.*

**H6-I06** — Como introduzir design tokens em um legado cheio de valores hardcoded de forma mais sustentável?
Correta: *criar uma camada progressiva de equivalência e migrar fluxos conforme prioridades reais.*

**O mecanismo.** É a mesma pergunta. Um item rejeita a camada de tradução; o outro tem a camada como
resposta certa. Quem responder aos dois com o mesmo raciocínio erra um necessariamente. Quem responde
sem raciocínio nenhum tem a mesma chance nos dois.

**Por que passou.** Cada item, lido sozinho, é defensável. A sobreposição de termos entre os
enunciados é 0,35 e a similaridade de texto 0,57 — nenhum detector automático sinaliza sem inundar de
falso positivo. Foi um participante que apontou, e a correção foi aposentar o item herdado.

**Regra que fica.** Ao revisar um conjunto, leia os itens da mesma competência juntos, procurando
perguntas equivalentes com respostas incompatíveis. É trabalho de leitura, não de ferramenta.

### Defeito 2 · Gabarito único onde há vários defensáveis

**H7-B11 · Conteúdo definido tarde** — gabarito (C)

> Qual é o custo de deixar a definição de conteúdo para o momento da implementação?
> - (A) A implementação leva mais tempo do que o previsto no ciclo
> - (B) O layout precisa ser ajustado para comportar o texto final
> - (C) O texto é escrito sob pressão por quem não decidiu ← marcada como correta
> - (D) O produto perde consistência de tom entre telas próximas
> - (E) O texto precisa ser revisado depois pela área de conteúdo

**O mecanismo.** As cinco descrevem custos reais. Perguntar "o" custo quando existem vários
defensáveis não cria dificuldade, cria loteria. Ninguém acertou entre os participantes que o
receberam, e a leitura preguiçosa seria classificá-lo como "difícil".

**Como consertar.** Ou o enunciado ganha o critério que ordena — "qual custo afeta a qualidade da
decisão, e não o prazo" — ou os distratores passam a ser consequências que não são custos.

### Defeito 3 · Pista de comprimento

Item inventado para ilustrar:

> Qual é a melhor forma de conduzir uma entrevista de discovery?
> - (A) Perguntar
> - (B) Ouvir
> - (C) Anotar
> - (D) Fazer perguntas abertas sobre comportamento passado e deixar a pessoa contar a história inteira sem interrupção ← correta
> - (E) Falar

**O mecanismo.** Não é preciso saber nada de pesquisa. A resposta é a única que parece uma resposta.

**Escala do problema.** Num banco real esse padrão apareceu de forma sutil e sistemática: a correta
era a mais longa em 76% dos itens de escolha única, contra 20% de acaso. Nenhum item isolado parecia
errado. Depois de instalar uma banda de ±8 caracteres entre a média das corretas e a dos distratores,
a taxa caiu para 18,5%.

### Defeito 4 · Absolutos concentrados nos distratores

> O que caracteriza uma boa métrica de produto?
> - (A) Ela **sempre** sobe quando o produto melhora
> - (B) Ela **nunca** é influenciada por sazonalidade
> - (C) Ela conecta o comportamento observado a um resultado ← correta
> - (D) Ela é **apenas** quantitativa
> - (E) **Todas** as áreas **somente** a acompanham

**O mecanismo.** Quatro absolutos, todos em distrator. Elimina-se por gramática.

**Escala real.** Num banco herdado, absolutos apareciam em 22,7% dos distratores e 3,9% das corretas —
5,8 vezes mais. Dois homologadores relataram que "algumas alternativas erradas eram óbvias demais" sem
conseguir nomear o mecanismo. Após a correção, razão de 1,0x, e dois participantes comentaram
espontaneamente que "a resposta não está tão evidente".

**Cuidado.** Corrigir demais inverte a pista, com atenuadores concentrados nas corretas. A meta é
paridade.

### Defeito 5 · Instrução divergente do gabarito

> Quais práticas melhoram o handoff? Selecione 3 alternativas corretas.
> Gabarito com 2 corretas.

**O mecanismo.** A plataforma zera quem marca mais opções do que o número de corretas. A pessoa segue
a instrução, marca três, e perde o ponto por obedecer ao enunciado. Defeito crítico e trivial de
detectar por código.

### Defeito 6 · Duas alternativas quase idênticas

> Como priorizar uma dívida de design?
> - (A) Pelo impacto sobre quem usa o produto ← correta
> - (B) Pelo impacto sobre quem usa o produto hoje

**O mecanismo.** Se duas dizem quase a mesma coisa e só uma é correta, o item é indefensável. E quem
percebe a duplicação deduz que a resposta está entre as duas, o que reduz o item a uma moeda.

**Caso real.** Um item novo escrito para reposição repetia um item básico já existente da mesma
competência — mesmo enunciado em outras palavras, mesma resposta correta e três distratores em comum.
Foi detectado pela sobreposição de termos, 0,67, e reescrito.

---

## Parte 3 — Defeitos de conjunto

Nenhum destes aparece na revisão item a item:

1. **Pista de comprimento agregada** — cada item na banda, o conjunto fora dela.
2. **Concentração da letra do gabarito** — resolve-se com embaralhamento determinístico por identificador.
3. **Safra desigual de itens** — num banco real, 129 itens antigos reaproveitados eram acertados em
   86% contra 55% dos itens novos, e não tinham gradiente de dificuldade nenhum: 85%, 89% e 83% nos
   três níveis. Concentrados em cinco competências, faziam essas cinco parecerem fortes para todo
   mundo. A correlação entre nota da competência e carga de itens antigos era +0,79 — o perfil media
   a idade da pergunta, não o conhecimento da pessoa.
4. **Redundância entre itens** da mesma competência.
5. **Escala comprimida** — os três níveis produzindo resultados parecidos.
