"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // ../../node_modules/papaparse/papaparse.min.js
  var require_papaparse_min = __commonJS({
    "../../node_modules/papaparse/papaparse.min.js"(exports, module) {
      ((e, t) => {
        "function" == typeof define && define.amd ? define([], t) : "object" == typeof module && "undefined" != typeof exports ? module.exports = t() : e.Papa = t();
      })(exports, function r() {
        var n = "undefined" != typeof self ? self : "undefined" != typeof window ? window : void 0 !== n ? n : {};
        var d, s = !n.document && !!n.postMessage, a = n.IS_PAPA_WORKER || false, o = {}, h = 0, v = {};
        function P(e) {
          return 65279 === e.charCodeAt(0) ? e.slice(1) : e;
        }
        function u(e) {
          this._handle = null, this._finished = false, this._completed = false, this._halted = false, this._input = null, this._baseIndex = 0, this._partialLine = "", this._rowCount = 0, this._start = 0, this._nextChunk = null, this.isFirstChunk = true, this._completeResults = { data: [], errors: [], meta: {} }, function(e2) {
            var t = b(e2);
            t.chunkSize = parseInt(t.chunkSize), e2.step || e2.chunk || (t.chunkSize = null);
            this._handle = new i(t), (this._handle.streamer = this)._config = t;
          }.call(this, e), this.parseChunk = function(t, e2) {
            var i2 = parseInt(this._config.skipFirstNLines) || 0;
            if (this.isFirstChunk && 0 < i2) {
              let e3 = this._config.newline;
              e3 || (r2 = this._config.quoteChar || '"', e3 = this._handle.guessLineEndings(t, r2)), t = [...t.split(e3).slice(i2)].join(e3);
            }
            this.isFirstChunk && q(this._config.beforeFirstChunk) && void 0 !== (r2 = this._config.beforeFirstChunk(t)) && (t = r2), this.isFirstChunk = false, this._halted = false;
            var i2 = this._partialLine + t, r2 = (this._partialLine = "", this._handle.parse(i2, this._baseIndex, !this._finished));
            if (!this._handle.paused() && !this._handle.aborted()) {
              t = r2.meta.cursor, i2 = (this._finished || (this._partialLine = i2.substring(t - this._baseIndex), this._baseIndex = t), r2 && r2.data && (this._rowCount += r2.data.length), this._finished || this._config.preview && this._rowCount >= this._config.preview);
              if (a) n.postMessage({ results: r2, workerId: v.WORKER_ID, finished: i2 });
              else if (q(this._config.chunk) && !e2) {
                if (this._config.chunk(r2, this._handle), this._handle.paused() || this._handle.aborted()) return void (this._halted = true);
                this._completeResults = r2 = void 0;
              }
              return this._config.step || this._config.chunk || (this._completeResults.data = this._completeResults.data.concat(r2.data), this._completeResults.errors = this._completeResults.errors.concat(r2.errors), this._completeResults.meta = r2.meta), this._completed || !i2 || !q(this._config.complete) || r2 && r2.meta.aborted || (this._config.complete(this._completeResults, this._input), this._completed = true), i2 || r2 && r2.meta.paused || this._nextChunk(), r2;
            }
            this._halted = true;
          }, this._sendError = function(e2) {
            q(this._config.error) ? this._config.error(e2) : a && this._config.error && n.postMessage({ workerId: v.WORKER_ID, error: e2, finished: false });
          };
        }
        function f(e) {
          var r2;
          (e = e || {}).chunkSize || (e.chunkSize = v.RemoteChunkSize), u.call(this, e), this._nextChunk = s ? function() {
            this._readChunk(), this._chunkLoaded();
          } : function() {
            this._readChunk();
          }, this.stream = function(e2) {
            this._input = e2, this._nextChunk();
          }, this._readChunk = function() {
            if (this._finished) this._chunkLoaded();
            else {
              if (r2 = new XMLHttpRequest(), this._config.withCredentials && (r2.withCredentials = this._config.withCredentials), s || (r2.onload = y(this._chunkLoaded, this), r2.onerror = y(this._chunkError, this)), r2.open(this._config.downloadRequestBody ? "POST" : "GET", this._input, !s), this._config.downloadRequestHeaders) {
                var e2, t = this._config.downloadRequestHeaders;
                for (e2 in t) r2.setRequestHeader(e2, t[e2]);
              }
              var i2;
              this._config.chunkSize && (i2 = this._start + this._config.chunkSize - 1, r2.setRequestHeader("Range", "bytes=" + this._start + "-" + i2));
              try {
                r2.send(this._config.downloadRequestBody);
              } catch (e3) {
                this._chunkError(e3.message);
              }
              s && 0 === r2.status && this._chunkError();
            }
          }, this._chunkLoaded = function() {
            4 === r2.readyState && (r2.status < 200 || 400 <= r2.status ? this._chunkError() : (this._start += this._config.chunkSize || r2.responseText.length, this._finished = !this._config.chunkSize || this._start >= ((e2) => null !== (e2 = e2.getResponseHeader("Content-Range")) ? parseInt(e2.substring(e2.lastIndexOf("/") + 1)) : -1)(r2), this.parseChunk(r2.responseText)));
          }, this._chunkError = function(e2) {
            e2 = r2.statusText || e2;
            this._sendError(new Error(e2));
          };
        }
        function l(e) {
          (e = e || {}).chunkSize || (e.chunkSize = v.LocalChunkSize), u.call(this, e);
          var i2, r2, n2 = "undefined" != typeof FileReader;
          this.stream = function(e2) {
            this._input = e2, r2 = e2.slice || e2.webkitSlice || e2.mozSlice, n2 ? ((i2 = new FileReader()).onload = y(this._chunkLoaded, this), i2.onerror = y(this._chunkError, this)) : i2 = new FileReaderSync(), this._nextChunk();
          }, this._nextChunk = function() {
            this._finished || this._config.preview && !(this._rowCount < this._config.preview) || this._readChunk();
          }, this._readChunk = function() {
            var e2 = this._input, t = (this._config.chunkSize && (t = Math.min(this._start + this._config.chunkSize, this._input.size), e2 = r2.call(e2, this._start, t)), i2.readAsText(e2, this._config.encoding));
            n2 || this._chunkLoaded({ target: { result: t } });
          }, this._chunkLoaded = function(e2) {
            this._start += this._config.chunkSize, this._finished = !this._config.chunkSize || this._start >= this._input.size, this.parseChunk(e2.target.result);
          }, this._chunkError = function() {
            this._sendError(i2.error);
          };
        }
        function c(e) {
          var i2;
          u.call(this, e = e || {}), this.stream = function(e2) {
            return i2 = e2, this._nextChunk();
          }, this._nextChunk = function() {
            var e2, t;
            if (!this._finished) return e2 = this._config.chunkSize, i2 = e2 ? (t = i2.substring(0, e2), i2.substring(e2)) : (t = i2, ""), this._finished = !i2, this.parseChunk(t);
          };
        }
        function p(e) {
          u.call(this, e = e || {});
          var t = [], i2 = true, r2 = false;
          this.pause = function() {
            u.prototype.pause.apply(this, arguments), this._input.pause();
          }, this.resume = function() {
            u.prototype.resume.apply(this, arguments), this._input.resume();
          }, this.stream = function(e2) {
            this._input = e2, this._input.on("data", this._streamData), this._input.on("end", this._streamEnd), this._input.on("error", this._streamError);
          }, this._checkIsFinished = function() {
            r2 && 1 === t.length && (this._finished = true);
          }, this._nextChunk = function() {
            this._checkIsFinished(), t.length ? this.parseChunk(t.shift()) : i2 = true;
          }, this._streamData = y(function(e2) {
            try {
              t.push("string" == typeof e2 ? e2 : e2.toString(this._config.encoding)), i2 && (i2 = false, this._checkIsFinished(), this.parseChunk(t.shift()));
            } catch (e3) {
              this._streamError(e3);
            }
          }, this), this._streamError = y(function(e2) {
            this._streamCleanUp(), this._sendError(e2);
          }, this), this._streamEnd = y(function() {
            this._streamCleanUp(), r2 = true, this._streamData("");
          }, this), this._streamCleanUp = y(function() {
            this._input.removeListener("data", this._streamData), this._input.removeListener("end", this._streamEnd), this._input.removeListener("error", this._streamError);
          }, this);
        }
        function i(m2) {
          var n2, s2, a2, t, o2 = Math.pow(2, 53), h2 = -o2, u2 = /^\s*-?(\d+\.?|\.\d+|\d+\.\d+)([eE][-+]?\d+)?\s*$/, d2 = /^((\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d:[0-5]\d\.\d+([+-][0-2]\d:[0-5]\d|Z))|(\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d:[0-5]\d([+-][0-2]\d:[0-5]\d|Z))|(\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d([+-][0-2]\d:[0-5]\d|Z)))$/, i2 = this, r2 = 0, f2 = 0, l2 = false, e = false, c2 = [], p2 = { data: [], errors: [], meta: {} };
          function y2(e2) {
            return "greedy" === m2.skipEmptyLines ? "" === e2.join("").trim() : 1 === e2.length && 0 === e2[0].length;
          }
          function g2() {
            if (p2 && a2 && (k("Delimiter", "UndetectableDelimiter", "Unable to auto-detect delimiting character; defaulted to '" + v.DefaultDelimiter + "'"), a2 = false), m2.skipEmptyLines && (p2.data = p2.data.filter(function(e3) {
              return !y2(e3);
            })), _2()) {
              let t3 = function(e3, t4) {
                e3 = P(e3), q(m2.transformHeader) && (e3 = m2.transformHeader(e3, t4)), c2.push(e3);
              };
              var t2 = t3;
              if (p2) if (Array.isArray(p2.data[0])) {
                for (var e2 = 0; _2() && e2 < p2.data.length; e2++) p2.data[e2].forEach(t3);
                p2.data.splice(0, 1);
              } else p2.data.forEach(t3);
            }
            function i3(e3, t3) {
              for (var i4 = m2.header ? {} : [], r4 = 0; r4 < e3.length; r4++) {
                var n3 = r4, s3 = e3[r4], s3 = ((e4, t4) => ((e5) => (m2.dynamicTypingFunction && void 0 === m2.dynamicTyping[e5] && (m2.dynamicTyping[e5] = m2.dynamicTypingFunction(e5)), true === (m2.dynamicTyping[e5] || m2.dynamicTyping)))(e4) ? "true" === t4 || "TRUE" === t4 || "false" !== t4 && "FALSE" !== t4 && (((e5) => {
                  if (u2.test(e5)) {
                    e5 = parseFloat(e5);
                    if (h2 < e5 && e5 < o2) return 1;
                  }
                })(t4) ? parseFloat(t4) : d2.test(t4) ? new Date(t4) : "" === t4 ? null : t4) : t4)(n3 = m2.header ? r4 >= c2.length ? "__parsed_extra" : c2[r4] : n3, s3 = m2.transform ? m2.transform(s3, n3) : s3);
                "__parsed_extra" === n3 ? (i4[n3] = i4[n3] || [], i4[n3].push(s3)) : i4[n3] = s3;
              }
              return m2.header && (r4 > c2.length ? k("FieldMismatch", "TooManyFields", "Too many fields: expected " + c2.length + " fields but parsed " + r4, f2 + t3) : r4 < c2.length && k("FieldMismatch", "TooFewFields", "Too few fields: expected " + c2.length + " fields but parsed " + r4, f2 + t3)), i4;
            }
            var r3;
            p2 && (m2.header || m2.dynamicTyping || m2.transform) && (r3 = 1, !p2.data.length || Array.isArray(p2.data[0]) ? (p2.data = p2.data.map(i3), r3 = p2.data.length) : p2.data = i3(p2.data, 0), m2.header && p2.meta && (p2.meta.fields = c2), f2 += r3);
          }
          function _2() {
            return m2.header && 0 === c2.length;
          }
          function k(e2, t2, i3, r3) {
            e2 = { type: e2, code: t2, message: i3 };
            void 0 !== r3 && (e2.row = r3), p2.errors.push(e2);
          }
          q(m2.step) && (t = m2.step, m2.step = function(e2) {
            p2 = e2, _2() ? g2() : (g2(), 0 !== p2.data.length && (r2 += e2.data.length, m2.preview && r2 > m2.preview ? s2.abort() : (p2.data = p2.data[0], t(p2, i2))));
          }), this.parse = function(e2, t2, i3) {
            var r3 = m2.quoteChar || '"', r3 = (m2.newline || (m2.newline = this.guessLineEndings(e2, r3)), a2 = false, m2.delimiter ? q(m2.delimiter) && (m2.delimiter = m2.delimiter(e2), p2.meta.delimiter = m2.delimiter) : ((r3 = ((e3, t3, i4, r4, n3) => {
              var s3, a3, o3, h3;
              n3 = n3 || [",", "	", "|", ";", v.RECORD_SEP, v.UNIT_SEP];
              for (var u3 = 0; u3 < n3.length; u3++) {
                for (var d3, f3 = n3[u3], l3 = 0, c3 = 0, p3 = 0, g3 = (o3 = void 0, new E({ comments: r4, delimiter: f3, newline: t3, preview: 10 }).parse(e3)), _3 = 0; _3 < g3.data.length; _3++) i4 && y2(g3.data[_3]) ? p3++ : (d3 = g3.data[_3].length, c3 += d3, void 0 === o3 ? o3 = d3 : 0 < d3 && (l3 += Math.abs(d3 - o3), o3 = d3));
                0 < g3.data.length && (c3 /= g3.data.length - p3), (void 0 === a3 || l3 <= a3) && (void 0 === h3 || h3 < c3) && 1.99 < c3 && (a3 = l3, s3 = f3, h3 = c3);
              }
              return { successful: !!(m2.delimiter = s3), bestDelimiter: s3 };
            })(e2, m2.newline, m2.skipEmptyLines, m2.comments, m2.delimitersToGuess)).successful ? m2.delimiter = r3.bestDelimiter : (a2 = true, m2.delimiter = v.DefaultDelimiter), p2.meta.delimiter = m2.delimiter), b(m2));
            return m2.preview && m2.header && r3.preview++, n2 = e2, s2 = new E(r3), p2 = s2.parse(n2, t2, i3), g2(), l2 ? { meta: { paused: true } } : p2 || { meta: { paused: false } };
          }, this.paused = function() {
            return l2;
          }, this.pause = function() {
            l2 = true, s2.abort(), n2 = q(m2.chunk) ? "" : n2.substring(s2.getCharIndex());
          }, this.resume = function() {
            i2.streamer._halted ? (l2 = false, i2.streamer.parseChunk(n2, true)) : setTimeout(i2.resume, 3);
          }, this.aborted = function() {
            return e;
          }, this.abort = function() {
            e = true, s2.abort(), p2.meta.aborted = true, q(m2.complete) && m2.complete(p2), n2 = "";
          }, this.guessLineEndings = function(e2, t2) {
            e2 = e2.substring(0, 1048576);
            var t2 = new RegExp(U(t2) + "([^]*?)" + U(t2), "gm"), i3 = (e2 = e2.replace(t2, "")).split("\r"), t2 = e2.split("\n"), e2 = 1 < t2.length && t2[0].length < i3[0].length;
            if (1 === i3.length || e2) return "\n";
            for (var r3 = 0, n3 = 0; n3 < i3.length; n3++) "\n" === i3[n3][0] && r3++;
            return r3 >= i3.length / 2 ? "\r\n" : "\r";
          };
        }
        function U(e) {
          return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        }
        function E(C) {
          var S = (C = C || {}).delimiter, O = C.newline, x = C.comments, I = C.step, A = C.preview, T = C.fastMode, D = null, L = false, F = null == C.quoteChar ? '"' : C.quoteChar, j = F;
          if (void 0 !== C.escapeChar && (j = C.escapeChar), ("string" != typeof S || -1 < v.BAD_DELIMITERS.indexOf(S)) && (S = ","), x === S) throw new Error("Comment character same as delimiter");
          true === x ? x = "#" : ("string" != typeof x || -1 < v.BAD_DELIMITERS.indexOf(x)) && (x = false), "\n" !== O && "\r" !== O && "\r\n" !== O && (O = "\n");
          var z = 0, M = false;
          this.parse = function(i2, t, r2) {
            if ("string" != typeof i2) throw new Error("Input must be a string");
            var n2 = i2.length, e = S.length, s2 = O.length, a2 = x.length, o2 = q(I), h2 = [], u2 = [], d2 = [], f2 = z = 0;
            if (!i2) return w();
            if (T || false !== T && -1 === i2.indexOf(F)) {
              for (var l2 = i2.split(O), c2 = 0; c2 < l2.length; c2++) {
                if (d2 = l2[c2], z += d2.length, c2 !== l2.length - 1) z += O.length;
                else if (r2) return w();
                if (!x || d2.substring(0, a2) !== x) {
                  if (o2) {
                    if (h2 = [], k(d2.split(S)), R(), M) return w();
                  } else k(d2.split(S));
                  if (A && A <= c2) return h2 = h2.slice(0, A), w(true);
                }
              }
              return w();
            }
            for (var p2 = i2.indexOf(S, z), g2 = i2.indexOf(O, z), _2 = new RegExp(U(j) + U(F), "g"), m2 = i2.indexOf(F, z); ; ) if (i2[z] === F) for (m2 = z, z++; ; ) {
              if (-1 === (m2 = i2.indexOf(F, m2 + 1))) return r2 || u2.push({ type: "Quotes", code: "MissingQuotes", message: "Quoted field unterminated", row: h2.length, index: z }), E2();
              if (m2 === n2 - 1) return E2(i2.substring(z, m2).replace(_2, F));
              if (F === j && i2[m2 + 1] === j) m2++;
              else if (F === j || 0 === m2 || i2[m2 - 1] !== j) {
                -1 !== p2 && p2 < m2 + 1 && (p2 = i2.indexOf(S, m2 + 1));
                var y2 = v2(-1 === (g2 = -1 !== g2 && g2 < m2 + 1 ? i2.indexOf(O, m2 + 1) : g2) ? p2 : Math.min(p2, g2));
                if (i2.substr(m2 + 1 + y2, e) === S) {
                  d2.push(i2.substring(z, m2).replace(_2, F)), i2[z = m2 + 1 + y2 + e] !== F && (m2 = i2.indexOf(F, z)), p2 = i2.indexOf(S, z), g2 = i2.indexOf(O, z);
                  break;
                }
                y2 = v2(g2);
                if (i2.substring(m2 + 1 + y2, m2 + 1 + y2 + s2) === O) {
                  if (d2.push(i2.substring(z, m2).replace(_2, F)), b2(m2 + 1 + y2 + s2), p2 = i2.indexOf(S, z), m2 = i2.indexOf(F, z), o2 && (R(), M)) return w();
                  if (A && h2.length >= A) return w(true);
                  break;
                }
                u2.push({ type: "Quotes", code: "InvalidQuotes", message: "Trailing quote on quoted field is malformed", row: h2.length, index: z }), m2++;
              }
            }
            else if (x && 0 === d2.length && i2.substring(z, z + a2) === x) {
              if (-1 === g2) return w();
              z = g2 + s2, g2 = i2.indexOf(O, z), p2 = i2.indexOf(S, z);
            } else if (-1 !== p2 && (p2 < g2 || -1 === g2)) d2.push(i2.substring(z, p2)), z = p2 + e, p2 = i2.indexOf(S, z);
            else {
              if (-1 === g2) break;
              if (d2.push(i2.substring(z, g2)), b2(g2 + s2), o2 && (R(), M)) return w();
              if (A && h2.length >= A) return w(true);
            }
            return E2();
            function k(e2) {
              h2.push(e2), f2 = z;
            }
            function v2(e2) {
              var t2 = 0;
              return t2 = -1 !== e2 && (e2 = i2.substring(m2 + 1, e2)) && "" === e2.trim() ? e2.length : t2;
            }
            function E2(e2) {
              return r2 || (void 0 === e2 && (e2 = i2.substring(z)), d2.push(e2), z = n2, k(d2), o2 && R()), w();
            }
            function b2(e2) {
              z = e2, k(d2), d2 = [], g2 = i2.indexOf(O, z);
            }
            function w(e2) {
              if (C.header && !t && h2.length && !L) {
                var s3 = h2[0], a3 = /* @__PURE__ */ Object.create(null), o3 = new Set(s3);
                let n3 = false;
                for (let r3 = 0; r3 < s3.length; r3++) {
                  let i3 = P(s3[r3]);
                  if (a3[i3 = q(C.transformHeader) ? C.transformHeader(i3, r3) : i3]) {
                    let e3, t2 = a3[i3];
                    for (; e3 = i3 + "_" + t2, t2++, o3.has(e3); ) ;
                    o3.add(e3), s3[r3] = e3, a3[i3]++, n3 = true, (D = null === D ? {} : D)[e3] = i3;
                  } else a3[i3] = 1, s3[r3] = i3;
                  o3.add(i3);
                }
                n3 && console.warn("Duplicate headers found and renamed."), L = true;
              }
              return { data: h2, errors: u2, meta: { delimiter: S, linebreak: O, aborted: M, truncated: !!e2, cursor: f2 + (t || 0), renamedHeaders: D } };
            }
            function R() {
              I(w()), h2 = [], u2 = [];
            }
          }, this.abort = function() {
            M = true;
          }, this.getCharIndex = function() {
            return z;
          };
        }
        function g(e) {
          var t = e.data, i2 = o[t.workerId], r2 = false;
          if (t.error) i2.userError(t.error, t.file);
          else if (t.results && t.results.data) {
            var n2 = { abort: function() {
              r2 = true, _(t.workerId, { data: [], errors: [], meta: { aborted: true } });
            }, pause: m, resume: m };
            if (q(i2.userStep)) {
              for (var s2 = 0; s2 < t.results.data.length && (i2.userStep({ data: t.results.data[s2], errors: t.results.errors, meta: t.results.meta }, n2), !r2); s2++) ;
              delete t.results;
            } else q(i2.userChunk) && (i2.userChunk(t.results, n2, t.file), delete t.results);
          }
          t.finished && !r2 && _(t.workerId, t.results);
        }
        function _(e, t) {
          var i2 = o[e];
          q(i2.userComplete) && i2.userComplete(t), i2.terminate(), delete o[e];
        }
        function m() {
          throw new Error("Not implemented.");
        }
        function b(e) {
          if ("object" != typeof e || null === e) return e;
          var t, i2 = Array.isArray(e) ? [] : {};
          for (t in e) i2[t] = b(e[t]);
          return i2;
        }
        function y(e, t) {
          return function() {
            e.apply(t, arguments);
          };
        }
        function q(e) {
          return "function" == typeof e;
        }
        return v.parse = function(e, t) {
          var i2 = (t = t || {}).dynamicTyping || false;
          q(i2) && (t.dynamicTypingFunction = i2, i2 = {});
          if (t.dynamicTyping = i2, t.transform = !!q(t.transform) && t.transform, !t.worker || !v.WORKERS_SUPPORTED) return i2 = null, v.NODE_STREAM_INPUT, "string" == typeof e ? (e = P(e), i2 = new (t.download ? f : c)(t)) : true === e.readable && q(e.read) && q(e.on) ? i2 = new p(t) : (n.File && e instanceof File || e instanceof Object) && (i2 = new l(t)), i2.stream(e);
          (i2 = (() => {
            var e2;
            return !!v.WORKERS_SUPPORTED && (e2 = (() => {
              var e3 = n.URL || n.webkitURL || null, t2 = r.toString();
              return v.BLOB_URL || (v.BLOB_URL = e3.createObjectURL(new Blob(["var global = (function() { if (typeof self !== 'undefined') { return self; } if (typeof window !== 'undefined') { return window; } if (typeof global !== 'undefined') { return global; } return {}; })(); global.IS_PAPA_WORKER=true; ", "(", t2, ")();"], { type: "text/javascript" })));
            })(), (e2 = new n.Worker(e2)).onmessage = g, e2.id = h++, o[e2.id] = e2);
          })()).userStep = t.step, i2.userChunk = t.chunk, i2.userComplete = t.complete, i2.userError = t.error, t.step = q(t.step), t.chunk = q(t.chunk), t.complete = q(t.complete), t.error = q(t.error), delete t.worker, i2.postMessage({ input: e, config: t, workerId: i2.id });
        }, v.unparse = function(e, t) {
          var s2 = false, _2 = true, m2 = ",", y2 = "\r\n", a2 = '"', o2 = a2 + a2, i2 = false, r2 = null, h2 = false, u2 = ((() => {
            if ("object" == typeof t) {
              if ("string" != typeof t.delimiter || v.BAD_DELIMITERS.filter(function(e2) {
                return -1 !== t.delimiter.indexOf(e2);
              }).length || (m2 = t.delimiter), "boolean" != typeof t.quotes && "function" != typeof t.quotes && !Array.isArray(t.quotes) || (s2 = t.quotes), "boolean" != typeof t.skipEmptyLines && "string" != typeof t.skipEmptyLines || (i2 = t.skipEmptyLines), "string" == typeof t.newline && (y2 = t.newline), "string" == typeof t.quoteChar && (a2 = t.quoteChar, o2 = a2 + a2), "boolean" == typeof t.header && (_2 = t.header), Array.isArray(t.columns)) {
                if (0 === t.columns.length) throw new Error("Option columns is empty");
                r2 = t.columns;
              }
              void 0 !== t.escapeChar && (o2 = t.escapeChar + a2), t.escapeFormulae instanceof RegExp ? h2 = t.escapeFormulae : "boolean" == typeof t.escapeFormulae && t.escapeFormulae && (h2 = /^[=+\-@\t\r].*$/);
            }
          })(), new RegExp(U(a2), "g"));
          "string" == typeof e && (e = JSON.parse(e));
          if (Array.isArray(e)) {
            if (!e.length || Array.isArray(e[0])) return n2(null, e, i2);
            if ("object" == typeof e[0]) return n2(r2 || Object.keys(e[0]), e, i2);
          } else if ("object" == typeof e) return "string" == typeof e.data && (e.data = JSON.parse(e.data)), Array.isArray(e.data) && (e.fields || (e.fields = e.meta && e.meta.fields || r2), e.fields || (e.fields = Array.isArray(e.data[0]) ? e.fields : "object" == typeof e.data[0] ? Object.keys(e.data[0]) : []), Array.isArray(e.data[0]) || "object" == typeof e.data[0] || (e.data = [e.data])), n2(e.fields || [], e.data || [], i2);
          throw new Error("Unable to serialize unrecognized input");
          function n2(e2, t2, i3) {
            var r3 = "", n3 = ("string" == typeof e2 && (e2 = JSON.parse(e2)), "string" == typeof t2 && (t2 = JSON.parse(t2)), Array.isArray(e2) && 0 < e2.length), s3 = !Array.isArray(t2[0]);
            if (n3 && _2) {
              for (var a3 = 0; a3 < e2.length; a3++) 0 < a3 && (r3 += m2), r3 += k(e2[a3], a3);
              0 < t2.length && (r3 += y2);
            }
            for (var o3 = 0; o3 < t2.length; o3++) {
              var h3 = (n3 ? e2 : t2[o3]).length, u3 = false, d2 = n3 ? 0 === Object.keys(t2[o3]).length : 0 === t2[o3].length;
              if (i3 && !n3 && (u3 = "greedy" === i3 ? "" === t2[o3].join("").trim() : 1 === t2[o3].length && 0 === t2[o3][0].length), "greedy" === i3 && n3) {
                for (var f2 = [], l2 = 0; l2 < h3; l2++) {
                  var c2 = s3 ? e2[l2] : l2;
                  f2.push(t2[o3][c2]);
                }
                u3 = "" === f2.join("").trim();
              }
              if (!u3) {
                for (var p2 = 0; p2 < h3; p2++) {
                  0 < p2 && !d2 && (r3 += m2);
                  var g2 = n3 && s3 ? e2[p2] : p2;
                  r3 += k(t2[o3][g2], p2);
                }
                o3 < t2.length - 1 && (!i3 || 0 < h3 && !d2) && (r3 += y2);
              }
            }
            return r3;
          }
          function k(e2, t2) {
            var i3, r3, n3;
            return null == e2 ? "" : e2.constructor === Date ? JSON.stringify(e2).slice(1, 25) : (n3 = false, h2 && "string" == typeof e2 && h2.test(e2) && (e2 = "'" + e2, n3 = true), r3 = (i3 = e2.toString()).replace(u2, o2), (n3 = n3 || true === s2 || "function" == typeof s2 && s2(e2, t2) || Array.isArray(s2) && s2[t2] || ((e3, t3) => {
              for (var i4 = 0; i4 < t3.length; i4++) if (-1 < e3.indexOf(t3[i4])) return true;
              return false;
            })(r3, v.BAD_DELIMITERS) || -1 < r3.indexOf(m2) || -1 < i3.indexOf(a2) || " " === r3.charAt(0) || " " === r3.charAt(r3.length - 1)) ? a2 + r3 + a2 : r3);
          }
        }, v.RECORD_SEP = String.fromCharCode(30), v.UNIT_SEP = String.fromCharCode(31), v.BYTE_ORDER_MARK = "\uFEFF", v.BAD_DELIMITERS = ["\r", "\n", '"', v.BYTE_ORDER_MARK], v.WORKERS_SUPPORTED = !s && !!n.Worker, v.NODE_STREAM_INPUT = 1, v.LocalChunkSize = 10485760, v.RemoteChunkSize = 5242880, v.DefaultDelimiter = ",", v.Parser = E, v.ParserHandle = i, v.NetworkStreamer = f, v.FileStreamer = l, v.StringStreamer = c, v.ReadableStreamStreamer = p, n.jQuery && ((d = n.jQuery).fn.parse = function(o2) {
          var i2 = o2.config || {}, h2 = [];
          return this.each(function(e2) {
            if (!("INPUT" === d(this).prop("tagName").toUpperCase() && "file" === d(this).attr("type").toLowerCase() && n.FileReader) || !this.files || 0 === this.files.length) return true;
            for (var t = 0; t < this.files.length; t++) h2.push({ file: this.files[t], inputElem: this, instanceConfig: d.extend({}, i2) });
          }), e(), this;
          function e() {
            if (0 === h2.length) q(o2.complete) && o2.complete();
            else {
              var e2, t, i3, r2, n2 = h2[0];
              if (q(o2.before)) {
                var s2 = o2.before(n2.file, n2.inputElem);
                if ("object" == typeof s2) {
                  if ("abort" === s2.action) return e2 = "AbortError", t = n2.file, i3 = n2.inputElem, r2 = s2.reason, void (q(o2.error) && o2.error({ name: e2 }, t, i3, r2));
                  if ("skip" === s2.action) return void u2();
                  "object" == typeof s2.config && (n2.instanceConfig = d.extend(n2.instanceConfig, s2.config));
                } else if ("skip" === s2) return void u2();
              }
              var a2 = n2.instanceConfig.complete;
              n2.instanceConfig.complete = function(e3) {
                q(a2) && a2(e3, n2.file, n2.inputElem), u2();
              }, v.parse(n2.file, n2.instanceConfig);
            }
          }
          function u2() {
            h2.splice(0, 1), e();
          }
        }), a && (n.onmessage = function(e) {
          e = e.data;
          void 0 === v.WORKER_ID && e && (v.WORKER_ID = e.workerId);
          "string" == typeof e.input ? n.postMessage({ workerId: v.WORKER_ID, results: v.parse(e.input, e.config), finished: true }) : (n.File && e.input instanceof File || e.input instanceof Object) && (e = v.parse(e.input, e.config)) && n.postMessage({ workerId: v.WORKER_ID, results: e, finished: true });
        }), (f.prototype = Object.create(u.prototype)).constructor = f, (l.prototype = Object.create(u.prototype)).constructor = l, (c.prototype = Object.create(c.prototype)).constructor = c, (p.prototype = Object.create(u.prototype)).constructor = p, v;
      });
    }
  });

  // src/shared/protocol.ts
  function isNormalizedAssessmentImport(value) {
    if (!value || typeof value !== "object") return false;
    const candidate = value;
    return typeof candidate.fileName === "string" && typeof candidate.importedAt === "string" && typeof candidate.sourceHash === "string" && Array.isArray(candidate.people) && Array.isArray(candidate.assessments) && Array.isArray(candidate.results) && Array.isArray(candidate.catalog) && Boolean(candidate.framework && typeof candidate.framework === "object") && Array.isArray(candidate.diagnostics);
  }
  function isApplyAssessmentContextInput(value) {
    if (!value || typeof value !== "object") return false;
    const candidate = value;
    return Array.isArray(candidate.assessmentIds) && candidate.assessmentIds.every((id) => typeof id === "string") && typeof candidate.roleId === "string" && typeof candidate.specializationId === "string" && Array.isArray(candidate.additionalRoles) && candidate.additionalRoles.every((role) => typeof role === "string") && (candidate.cycle === null || typeof candidate.cycle === "string");
  }
  function hasObjectPayload(value) {
    return Boolean(
      value && typeof value === "object" && value.payload && typeof value.payload === "object"
    );
  }
  function isReportGenerationRequest(value) {
    if (!value || typeof value !== "object") return false;
    const candidate = value;
    if (candidate.strategy !== "safe-update" && candidate.strategy !== "duplicate") return false;
    if (candidate.target === "individual") {
      return typeof candidate.assessmentId === "string";
    }
    if (candidate.target === "collective") {
      return Boolean(
        candidate.filters && typeof candidate.filters === "object"
      );
    }
    if (candidate.target !== "comparison") return false;
    const groupIds = candidate.groupIds;
    if (Array.isArray(groupIds)) {
      return groupIds.length >= 2 && groupIds.every((groupId) => typeof groupId === "string");
    }
    return typeof candidate.leftGroupId === "string" && typeof candidate.rightGroupId === "string";
  }
  function isUiToPluginMessage(value) {
    if (!value || typeof value !== "object") return false;
    const type = value.type;
    if (type === "ui/ready" || type === "schema/initialize" || type === "storage/run-synthetic-proof" || type === "storage/clear" || type === "backup/export") {
      return true;
    }
    return type === "ui/resize" && (value.size === "compact" || value.size === "workspace" || value.size === "wide") || type === "backup/import" && typeof value.serialized === "string" || type === "assessment-import/commit" && isNormalizedAssessmentImport(
      value.payload
    ) || type === "context/apply" && isApplyAssessmentContextInput(value.payload) || (type === "group/save" || type === "cycle/save" || type === "development/save" || type === "framework/mutate" || type === "catalog/mutate" || type === "analytics/evolution" || type === "assessment-result/resolve" || type === "assessment-result/undo-resolution") && hasObjectPayload(value) || (type === "group/delete" || type === "group/duplicate") && typeof value.groupId === "string" || type === "cycle/register-basis" && typeof value.cycleId === "string" || type === "development/delete" && typeof value.actionId === "string" || type === "assessments/delete" && Array.isArray(value.assessmentIds) && value.assessmentIds.every(
      (id) => typeof id === "string"
    ) || type === "analytics/individual" && typeof value.assessmentId === "string" || type === "analytics/collective" && Boolean(
      value.filters && typeof value.filters === "object"
    ) || type === "analytics/group-comparison" && (() => {
      const groupIds = value.groupIds;
      if (Array.isArray(groupIds)) {
        return groupIds.length >= 2 && groupIds.every((groupId) => typeof groupId === "string");
      }
      return typeof value.leftGroupId === "string" && typeof value.rightGroupId === "string";
    })() || type === "reports/generate" && isReportGenerationRequest(value.payload) || type === "reports/generate-batch" && (() => {
      const payload = value.payload;
      return payload?.target === "individual-batch" && Array.isArray(payload.assessmentIds) && payload.assessmentIds.every((id) => typeof id === "string") && (payload.strategy === "safe-update" || payload.strategy === "duplicate") && Boolean(payload.composition && typeof payload.composition === "object");
    })();
  }

  // src/storage/backup.ts
  function createWorkspaceBackup(snapshot, now = /* @__PURE__ */ new Date()) {
    return {
      format: "skill-mapping-backup",
      formatVersion: 1,
      exportedAt: now.toISOString(),
      snapshot
    };
  }
  function serializeWorkspaceBackup(snapshot, now = /* @__PURE__ */ new Date()) {
    return JSON.stringify(createWorkspaceBackup(snapshot, now));
  }
  function parseWorkspaceBackup(serialized) {
    let value;
    try {
      value = JSON.parse(serialized);
    } catch {
      throw new Error("O backup n\xE3o cont\xE9m JSON v\xE1lido.");
    }
    if (!value || typeof value !== "object") {
      throw new Error("O backup n\xE3o possui a estrutura esperada.");
    }
    const backup = value;
    if (backup.format !== "skill-mapping-backup" || backup.formatVersion !== 1 || typeof backup.exportedAt !== "string" || !backup.snapshot || typeof backup.snapshot !== "object") {
      throw new Error("O arquivo n\xE3o \xE9 um backup compat\xEDvel do Skill Mapping.");
    }
    const snapshot = backup.snapshot;
    if (!snapshot.workspace || !snapshot.framework || !Array.isArray(snapshot.people) || !Array.isArray(snapshot.assessments) || !Array.isArray(snapshot.results) || !Array.isArray(snapshot.groups) || !Array.isArray(snapshot.catalog)) {
      throw new Error("O backup est\xE1 incompleto ou corrompido.");
    }
    return backup;
  }

  // src/shared/schema.ts
  var SCHEMA_PLUGIN_DATA_KEY = "skill-mapping:schema";
  var CURRENT_SCHEMA_VERSION = 1;
  function createSchemaMetadata(now = /* @__PURE__ */ new Date()) {
    const timestamp2 = now.toISOString();
    return {
      product: "skill-mapping-figma",
      schemaVersion: CURRENT_SCHEMA_VERSION,
      createdAt: timestamp2,
      updatedAt: timestamp2,
      activeGenerationId: null,
      revision: 0
    };
  }
  function parseSchemaMetadata(serialized) {
    if (!serialized) return null;
    try {
      const value = JSON.parse(serialized);
      if (!value || typeof value !== "object") return null;
      const candidate = value;
      if (candidate.product !== "skill-mapping-figma" || candidate.schemaVersion !== CURRENT_SCHEMA_VERSION || typeof candidate.createdAt !== "string" || typeof candidate.updatedAt !== "string" || !(candidate.revision === void 0 || typeof candidate.revision === "number" && Number.isInteger(candidate.revision) && candidate.revision >= 0) || !(candidate.activeGenerationId === null || typeof candidate.activeGenerationId === "string")) {
        return null;
      }
      return {
        ...candidate,
        revision: candidate.revision ?? 0
      };
    } catch {
      return null;
    }
  }

  // src/storage/encoding.ts
  var MAX_PLUGIN_DATA_VALUE_BYTES = 7e4;
  function utf8ByteLength(value) {
    let bytes = 0;
    for (let index = 0; index < value.length; index += 1) {
      const code = value.charCodeAt(index);
      if (code < 128) bytes += 1;
      else if (code < 2048) bytes += 2;
      else if (code >= 55296 && code <= 56319) {
        const next = value.charCodeAt(index + 1);
        if (next >= 56320 && next <= 57343) {
          bytes += 4;
          index += 1;
        } else bytes += 3;
      } else bytes += 3;
    }
    return bytes;
  }
  function checksum(value) {
    let hash = 2166136261;
    for (let index = 0; index < value.length; index += 1) {
      hash ^= value.charCodeAt(index);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(16).padStart(8, "0");
  }
  function serializeRecordChunks(records, maxBytes = MAX_PLUGIN_DATA_VALUE_BYTES) {
    if (!Number.isInteger(maxBytes) || maxBytes <= 256) {
      throw new Error("O limite de fragmento precisa ser maior que 256 bytes.");
    }
    if (records.length === 0) return [];
    const chunks = [];
    let current = [];
    const finalize2 = () => {
      if (current.length === 0) return;
      const value = JSON.stringify(current);
      const bytes = utf8ByteLength(value);
      chunks.push({ value, records: current, bytes, checksum: checksum(value) });
      current = [];
    };
    for (const record of records) {
      const candidate = [...current, record];
      const candidateValue = JSON.stringify(candidate);
      const candidateBytes = utf8ByteLength(candidateValue);
      if (candidateBytes <= maxBytes) {
        current = candidate;
        continue;
      }
      if (current.length === 0) {
        throw new Error(
          `Um registro isolado possui ${candidateBytes} bytes e excede o limite de ${maxBytes}.`
        );
      }
      finalize2();
      const isolatedValue = JSON.stringify([record]);
      const isolatedBytes = utf8ByteLength(isolatedValue);
      if (isolatedBytes > maxBytes) {
        throw new Error(
          `Um registro isolado possui ${isolatedBytes} bytes e excede o limite de ${maxBytes}.`
        );
      }
      current = [record];
    }
    finalize2();
    return chunks;
  }

  // src/identity/personIdentity.ts
  function normalizeFunctionalId(value) {
    const raw = typeof value === "string" || typeof value === "number" ? String(value) : "";
    const compacted = raw.normalize("NFKC").trim().replace(/\s+/gu, "");
    if (!compacted) {
      return { raw, normalized: null, valid: false, changed: false, reason: "missing" };
    }
    const numericMatch = compacted.match(/^([1-9])([0-9]{6})$/u);
    const normalized = numericMatch ? `${String.fromCharCode(96 + Number(numericMatch[1]))}${numericMatch[2]}` : compacted.replace(/^[A-I]/u, (prefix) => prefix.toLocaleLowerCase("pt-BR"));
    const valid = /^[a-i][0-9]{6}$/u.test(normalized);
    return {
      raw,
      normalized: valid ? normalized : null,
      valid,
      changed: valid && normalized !== raw,
      reason: valid ? null : "invalid_format"
    };
  }
  function resolveStoredFunctionalId(functionalId, functionalIdRaw) {
    const sourceNormalization = normalizeFunctionalId(functionalIdRaw);
    if (sourceNormalization.valid) return sourceNormalization.normalized;
    return normalizeFunctionalId(functionalId).normalized;
  }

  // src/storage/documentStore.ts
  var GENERATION_KEY_PREFIX = "skill-mapping:generation:";
  var WorkspaceStorageError = class extends Error {
    constructor(code, message) {
      super(message);
      this.code = code;
      this.name = "WorkspaceStorageError";
    }
  };
  function generationManifestKey(generationId) {
    return `${GENERATION_KEY_PREFIX}${generationId}:manifest`;
  }
  function generationChunkKey(generationId, kind, index) {
    return `${GENERATION_KEY_PREFIX}${generationId}:${kind}:${index}`;
  }
  function createGenerationId(now = /* @__PURE__ */ new Date()) {
    return `${now.getTime().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
  }
  function entityRecords(snapshot) {
    return [
      { kind: "framework", records: [snapshot.framework] },
      { kind: "people", records: snapshot.people },
      { kind: "assessments", records: snapshot.assessments },
      { kind: "results", records: snapshot.results },
      { kind: "groups", records: snapshot.groups },
      { kind: "catalog", records: snapshot.catalog },
      { kind: "cycles", records: snapshot.cycles ?? [] },
      { kind: "developmentActions", records: snapshot.developmentActions ?? [] },
      { kind: "reportRecords", records: snapshot.reportRecords ?? [] }
    ];
  }
  function snapshotCounts(snapshot) {
    return {
      framework: 1,
      people: snapshot.people.length,
      assessments: snapshot.assessments.length,
      results: snapshot.results.length,
      groups: snapshot.groups.length,
      catalog: snapshot.catalog.length,
      cycles: snapshot.cycles?.length ?? 0,
      developmentActions: snapshot.developmentActions?.length ?? 0,
      reportRecords: snapshot.reportRecords?.length ?? 0
    };
  }
  function summaryFromManifest(manifest) {
    return {
      generationId: manifest.generationId,
      revision: manifest.revision,
      workspaceName: manifest.workspace.name,
      createdAt: manifest.createdAt,
      fragmentCount: manifest.chunks.length,
      totalBytes: manifest.totalBytes,
      counts: manifest.counts
    };
  }
  var DocumentWorkspaceStore = class {
    constructor(document, maxEntryBytes = MAX_PLUGIN_DATA_VALUE_BYTES) {
      this.document = document;
      this.maxEntryBytes = maxEntryBytes;
    }
    ensureSchema(now = /* @__PURE__ */ new Date()) {
      const existing = parseSchemaMetadata(
        this.document.getPluginData(SCHEMA_PLUGIN_DATA_KEY)
      );
      if (existing) return existing;
      const schema = createSchemaMetadata(now);
      this.document.setPluginData(SCHEMA_PLUGIN_DATA_KEY, JSON.stringify(schema));
      return schema;
    }
    readSchema() {
      return parseSchemaMetadata(
        this.document.getPluginData(SCHEMA_PLUGIN_DATA_KEY)
      );
    }
    getActiveSummary() {
      const schema = this.readSchema();
      if (!schema?.activeGenerationId) return null;
      return summaryFromManifest(this.readManifest(schema.activeGenerationId));
    }
    writeWorkspace(snapshot, options = {}) {
      const now = options.now ?? /* @__PURE__ */ new Date();
      const schema = this.ensureSchema(now);
      if (options.expectedRevision !== void 0 && options.expectedRevision !== schema.revision) {
        throw new WorkspaceStorageError(
          "REVISION_CONFLICT",
          `O workspace est\xE1 na revis\xE3o ${schema.revision}, n\xE3o na revis\xE3o esperada ${options.expectedRevision}.`
        );
      }
      const generationId = options.generationId ?? createGenerationId(now);
      const descriptors = [];
      for (const entity of entityRecords(snapshot)) {
        const chunks = serializeRecordChunks(entity.records, this.maxEntryBytes);
        chunks.forEach((chunk, index) => {
          const key = generationChunkKey(generationId, entity.kind, index);
          this.document.setPluginData(key, chunk.value);
          const persisted = this.document.getPluginData(key);
          if (utf8ByteLength(persisted) !== chunk.bytes || checksum(persisted) !== chunk.checksum) {
            throw new WorkspaceStorageError(
              "CORRUPTED_GENERATION",
              `O fragmento ${key} n\xE3o p\xF4de ser confirmado ap\xF3s a grava\xE7\xE3o.`
            );
          }
          descriptors.push({
            key,
            kind: entity.kind,
            index,
            recordCount: chunk.records.length,
            bytes: chunk.bytes,
            checksum: chunk.checksum
          });
        });
      }
      const manifest = {
        format: "skill-mapping-generation",
        formatVersion: 1,
        generationId,
        previousGenerationId: schema.activeGenerationId,
        revision: schema.revision + 1,
        createdAt: now.toISOString(),
        workspace: snapshot.workspace,
        chunks: descriptors,
        counts: snapshotCounts(snapshot),
        totalBytes: descriptors.reduce((total, chunk) => total + chunk.bytes, 0)
      };
      const serializedManifest = JSON.stringify(manifest);
      if (utf8ByteLength(serializedManifest) > this.maxEntryBytes) {
        throw new WorkspaceStorageError(
          "ENTRY_LIMIT_EXCEEDED",
          "O manifesto da gera\xE7\xE3o excede o limite seguro de pluginData."
        );
      }
      const manifestKey = generationManifestKey(generationId);
      this.document.setPluginData(manifestKey, serializedManifest);
      if (this.document.getPluginData(manifestKey) !== serializedManifest) {
        throw new WorkspaceStorageError(
          "CORRUPTED_GENERATION",
          "O manifesto n\xE3o p\xF4de ser confirmado ap\xF3s a grava\xE7\xE3o."
        );
      }
      const nextSchema = {
        ...schema,
        activeGenerationId: generationId,
        revision: manifest.revision,
        updatedAt: now.toISOString()
      };
      this.document.setPluginData(
        SCHEMA_PLUGIN_DATA_KEY,
        JSON.stringify(nextSchema)
      );
      this.pruneGenerations(
        new Set(
          [generationId, schema.activeGenerationId].filter(
            (id) => Boolean(id)
          )
        )
      );
      return summaryFromManifest(manifest);
    }
    loadActiveWorkspace() {
      const schema = this.readSchema();
      if (!schema?.activeGenerationId) return null;
      return this.loadGeneration(schema.activeGenerationId);
    }
    loadGeneration(generationId) {
      const manifest = this.readManifest(generationId);
      const records = /* @__PURE__ */ new Map();
      for (const kind of [
        "framework",
        "people",
        "assessments",
        "results",
        "groups",
        "catalog",
        "cycles",
        "developmentActions",
        "reportRecords"
      ]) {
        records.set(kind, []);
      }
      const sortedChunks = [...manifest.chunks].sort(
        (left, right) => left.kind.localeCompare(right.kind) || left.index - right.index
      );
      for (const descriptor of sortedChunks) {
        const serialized = this.document.getPluginData(descriptor.key);
        if (!serialized || utf8ByteLength(serialized) !== descriptor.bytes || checksum(serialized) !== descriptor.checksum) {
          throw new WorkspaceStorageError(
            "CORRUPTED_GENERATION",
            `O fragmento ${descriptor.key} est\xE1 ausente ou corrompido.`
          );
        }
        let chunkRecords;
        try {
          chunkRecords = JSON.parse(serialized);
        } catch {
          throw new WorkspaceStorageError(
            "CORRUPTED_GENERATION",
            `O fragmento ${descriptor.key} n\xE3o cont\xE9m JSON v\xE1lido.`
          );
        }
        if (!Array.isArray(chunkRecords) || chunkRecords.length !== descriptor.recordCount) {
          throw new WorkspaceStorageError(
            "CORRUPTED_GENERATION",
            `O fragmento ${descriptor.key} possui contagem incompat\xEDvel.`
          );
        }
        records.get(descriptor.kind)?.push(...chunkRecords);
      }
      const framework = records.get("framework") ?? [];
      if (framework.length !== 1) {
        throw new WorkspaceStorageError(
          "CORRUPTED_GENERATION",
          "A gera\xE7\xE3o n\xE3o cont\xE9m exatamente um framework."
        );
      }
      const snapshot = {
        workspace: manifest.workspace,
        framework: framework[0],
        people: records.get("people") ?? [],
        assessments: records.get("assessments") ?? [],
        results: records.get("results") ?? [],
        groups: records.get("groups") ?? [],
        catalog: records.get("catalog") ?? [],
        cycles: records.get("cycles") ?? [],
        developmentActions: records.get("developmentActions") ?? [],
        reportRecords: records.get("reportRecords") ?? []
      };
      const actualCounts = snapshotCounts(snapshot);
      const countsMatch = Object.keys(manifest.counts).every((kind) => actualCounts[kind] === manifest.counts[kind]);
      if (!countsMatch) {
        throw new WorkspaceStorageError(
          "CORRUPTED_GENERATION",
          "A contagem reconstru\xEDda n\xE3o corresponde ao manifesto."
        );
      }
      return {
        ...snapshot,
        people: snapshot.people.map((person) => ({
          ...person,
          functionalId: resolveStoredFunctionalId(
            person.functionalId,
            person.functionalIdRaw
          )
        }))
      };
    }
    clearWorkspace(now = /* @__PURE__ */ new Date()) {
      for (const key of this.document.getPluginDataKeys()) {
        if (key.startsWith(GENERATION_KEY_PREFIX)) {
          this.document.setPluginData(key, "");
        }
      }
      const schema = this.ensureSchema(now);
      this.document.setPluginData(
        SCHEMA_PLUGIN_DATA_KEY,
        JSON.stringify({
          ...schema,
          activeGenerationId: null,
          revision: schema.revision + 1,
          updatedAt: now.toISOString()
        })
      );
    }
    runProof(snapshot, now = /* @__PURE__ */ new Date()) {
      const writeStartedAt = Date.now();
      const summary = this.writeWorkspace(snapshot, { now });
      const writeDurationMs = Date.now() - writeStartedAt;
      const readStartedAt = Date.now();
      const recovered = this.loadActiveWorkspace();
      const readDurationMs = Date.now() - readStartedAt;
      const manifest = this.readManifest(summary.generationId);
      return {
        ...summary,
        writeDurationMs,
        readDurationMs,
        maxFragmentBytes: Math.max(0, ...manifest.chunks.map((chunk) => chunk.bytes)),
        recoveredEquivalentSnapshot: JSON.stringify(recovered) === JSON.stringify(snapshot)
      };
    }
    readManifest(generationId) {
      const serialized = this.document.getPluginData(
        generationManifestKey(generationId)
      );
      if (!serialized) {
        throw new WorkspaceStorageError(
          "MISSING_GENERATION",
          `A gera\xE7\xE3o ${generationId} n\xE3o foi encontrada.`
        );
      }
      let manifest;
      try {
        manifest = JSON.parse(serialized);
      } catch {
        throw new WorkspaceStorageError(
          "CORRUPTED_GENERATION",
          `O manifesto da gera\xE7\xE3o ${generationId} est\xE1 corrompido.`
        );
      }
      const candidate = manifest;
      if (candidate.format !== "skill-mapping-generation" || candidate.formatVersion !== 1 || candidate.generationId !== generationId || !Array.isArray(candidate.chunks) || !candidate.counts || !candidate.workspace) {
        throw new WorkspaceStorageError(
          "CORRUPTED_GENERATION",
          `O manifesto da gera\xE7\xE3o ${generationId} \xE9 incompat\xEDvel.`
        );
      }
      return candidate;
    }
    pruneGenerations(keepGenerationIds) {
      try {
        for (const key of this.document.getPluginDataKeys()) {
          if (!key.startsWith(GENERATION_KEY_PREFIX)) continue;
          const generationId = key.slice(GENERATION_KEY_PREFIX.length).split(":", 1)[0];
          if (!keepGenerationIds.has(generationId)) {
            this.document.setPluginData(key, "");
          }
        }
      } catch {
      }
    }
  };

  // src/storage/syntheticDataset.ts
  function createSyntheticWorkspace(assessmentCount = 200, now = /* @__PURE__ */ new Date("2026-08-21T12:00:00.000Z")) {
    const capabilities = Array.from({ length: 20 }, (_, index) => ({
      id: index < 10 ? `H${index + 1}` : `S${index - 9}`,
      name: `Capacidade sint\xE9tica ${index + 1}`,
      type: index < 10 ? "hard" : "soft"
    }));
    const people = Array.from({ length: assessmentCount }, (_, index) => ({
      id: `person-${String(index + 1).padStart(4, "0")}`,
      name: `Pessoa sint\xE9tica ${index + 1}`,
      functionalId: `i${String(index + 1).padStart(6, "0")}`,
      functionalIdRaw: `i${String(index + 1).padStart(6, "0")}`,
      sourceName: `Pessoa sint\xE9tica ${index + 1}`,
      sourceCandidateIds: [`synthetic-candidate-${index + 1}`],
      email: `pessoa.${index + 1}@dados-sinteticos.example`,
      roleId: `role-${index % 4 + 1}`,
      specializationId: index % 2 === 0 ? "product-design" : "designops",
      additionalRoles: [
        ...index % 5 === 0 ? ["RT"] : [],
        ...index % 7 === 0 ? ["Mentor"] : []
      ]
    }));
    const assessments = people.map((person, index) => ({
      id: `assessment-${String(index + 1).padStart(4, "0")}`,
      personId: person.id,
      testName: "Assessment sint\xE9tico de carga",
      completedAt: now.toISOString(),
      percentage: 40 + index % 61,
      context: {
        roleId: person.roleId,
        specializationId: person.specializationId,
        additionalRoles: person.additionalRoles,
        cycle: "Prova sint\xE9tica 2026",
        cycleId: "cycle-synthetic-2026"
      },
      methodologyBasis: {
        frameworkId: "synthetic-framework",
        frameworkVersion: 1,
        roleId: person.roleId,
        specializationId: person.specializationId,
        capturedAt: now.toISOString(),
        source: "context_assignment"
      }
    }));
    const levels = ["B\xE1sico", "Intermedi\xE1rio", "Avan\xE7ado"];
    const results = assessments.flatMap(
      (assessment, assessmentIndex) => capabilities.flatMap(
        (capability, capabilityIndex) => levels.map((level, levelIndex) => ({
          assessmentId: assessment.id,
          personId: assessment.personId,
          capabilityId: capability.id,
          level,
          percentage: 25 + (assessmentIndex * 7 + capabilityIndex * 11 + levelIndex * 13) % 76,
          score: 25 + (assessmentIndex * 7 + capabilityIndex * 11 + levelIndex * 13) % 76,
          scoreMax: 100,
          dataStatus: "ok"
        }))
      )
    );
    const groups = Array.from({ length: 4 }, (_, index) => ({
      id: `group-${index + 1}`,
      name: `Grupo sint\xE9tico ${index + 1}`,
      type: "manual",
      personIds: people.filter((_2, personIndex) => personIndex % 4 === index).map((person) => person.id),
      assessmentIds: assessments.filter((_2, assessmentIndex) => assessmentIndex % 4 === index).map((assessment) => assessment.id),
      filter: null
    }));
    const catalog = capabilities.map((capability, index) => ({
      id: `course-${index + 1}`,
      title: `Curso sint\xE9tico para ${capability.name}`,
      capabilityIds: [capability.id],
      level: levels[index % levels.length],
      url: `https://dados-sinteticos.example/curso-${index + 1}`,
      trackName: `Trilha sint\xE9tica ${capability.name}`
    }));
    const framework = {
      id: "synthetic-framework",
      name: "Framework sint\xE9tico",
      version: 1,
      capabilities,
      roles: Array.from({ length: 4 }, (_, index) => ({
        id: `role-${index + 1}`,
        name: ["Designer J\xFAnior", "Designer Pleno", "Designer S\xEAnior", "Designer Especialista"][index],
        expectations: capabilities.map((capability) => ({
          capabilityId: capability.id,
          description: `Expectativa sint\xE9tica de ${capability.name}`,
          referencedLevels: [`N${Math.min(5, index + 1)}`],
          parsingStatus: "parsed"
        }))
      })),
      specializations: [
        { id: "product-design", name: "Product Design", group: "UX", capabilityApplicability: [] },
        { id: "designops", name: "DesignOps", group: "DesignOps", capabilityApplicability: [] }
      ]
    };
    return {
      workspace: {
        id: "synthetic-load-proof",
        name: "Prova sint\xE9tica \u2014 200 assessments",
        importedAt: now.toISOString(),
        sourceFileName: "dados-sinteticos-gerados.json",
        sourceHash: "synthetic-only-no-real-data"
      },
      framework,
      people,
      assessments,
      results,
      groups,
      catalog,
      cycles: [{
        id: "cycle-synthetic-2026",
        name: "Prova sint\xE9tica 2026",
        status: "active",
        createdAt: now.toISOString(),
        updatedAt: now.toISOString(),
        frameworkSnapshot: framework
      }],
      developmentActions: people.slice(0, 3).map((person, index) => ({
        id: `action-${index + 1}`,
        personId: person.id,
        assessmentId: assessments[index]?.id ?? null,
        capabilityIds: [capabilities[index].id],
        courseId: catalog[index].id,
        title: `A\xE7\xE3o sint\xE9tica ${index + 1}`,
        description: "A\xE7\xE3o usada somente na prova t\xE9cnica de persist\xEAncia.",
        decision: "accepted",
        priority: "medium",
        dueDate: null,
        owner: "Lideran\xE7a sint\xE9tica",
        status: "planned",
        createdAt: now.toISOString(),
        updatedAt: now.toISOString()
      })),
      reportRecords: []
    };
  }

  // src/context/additionalRoles.ts
  function normalizeAdditionalRoles(values = []) {
    const normalized = /* @__PURE__ */ new Map();
    values.forEach((value) => {
      const trimmed = value.trim().replace(/\s+/gu, " ");
      if (!trimmed) return;
      const key = trimmed.toLocaleLowerCase("pt-BR");
      if (!normalized.has(key)) normalized.set(key, trimmed);
    });
    return [...normalized.values()];
  }
  function readAdditionalRoles(additionalRoles, legacySeniority) {
    return normalizeAdditionalRoles([
      ...additionalRoles ?? [],
      ...legacySeniority ? [legacySeniority] : []
    ]);
  }

  // src/groups/groupDefinition.ts
  function actualValues(assessment, key) {
    if (key === "roleId") return assessment.context?.roleId ? [assessment.context.roleId] : [];
    if (key === "specializationId") {
      return assessment.context?.specializationId ? [assessment.context.specializationId] : [];
    }
    if (key === "cycle") return assessment.context?.cycle ? [assessment.context.cycle] : [];
    if (key === "additionalRole" || key === "seniority") {
      return readAdditionalRoles(
        assessment.context?.additionalRoles,
        assessment.context?.seniority
      );
    }
    return [];
  }
  function activeGroupCriteria(filter) {
    return Object.entries(filter ?? {}).filter(([, accepted]) => accepted.length > 0);
  }
  function explainGroupAssessmentMatch(assessment, filter, matchMode = "all") {
    const criteria = activeGroupCriteria(filter).map(([key, accepted]) => {
      const actual = actualValues(assessment, key);
      return {
        key,
        accepted,
        actual,
        matches: actual.some((value) => accepted.includes(value))
      };
    });
    return {
      matches: criteria.length > 0 && (matchMode === "any" ? criteria.some((criterion) => criterion.matches) : criteria.every((criterion) => criterion.matches)),
      criteria
    };
  }
  function readGroupDefinition(group) {
    return group.definition ?? {
      type: group.type,
      assessmentIds: group.type === "manual" ? group.assessmentIds ?? [] : [],
      filter: group.filter,
      matchMode: group.matchMode ?? "all"
    };
  }
  function readGroupComputed(group) {
    return group.computed ?? {
      assessmentIds: group.assessmentIds ?? [],
      personIds: group.personIds
    };
  }
  function computeGroupResult(assessments, definition) {
    const available = new Map(assessments.map((assessment) => [assessment.id, assessment]));
    const selected = definition.type === "manual" ? [...new Set(definition.assessmentIds)].map((id) => available.get(id)).filter((assessment) => Boolean(assessment)) : assessments.filter(
      (assessment) => explainGroupAssessmentMatch(
        assessment,
        definition.filter,
        definition.matchMode
      ).matches
    );
    return {
      assessmentIds: selected.map((assessment) => assessment.id),
      personIds: [...new Set(selected.map((assessment) => assessment.personId))]
    };
  }
  function hydrateStoredGroup(group) {
    const definition = readGroupDefinition(group);
    const computed = readGroupComputed(group);
    return {
      ...group,
      type: definition.type,
      assessmentIds: computed.assessmentIds,
      personIds: computed.personIds,
      filter: definition.filter,
      matchMode: definition.matchMode,
      definition,
      computed
    };
  }

  // src/operations/workspaceOperations.ts
  function resultMatches(result, input) {
    return result.assessmentId === input.assessmentId && result.capabilityId === input.capabilityId && result.level === input.level;
  }
  function resolveAssessmentResult(snapshot, input, now = /* @__PURE__ */ new Date()) {
    const decidedBy = input.decidedBy.trim();
    const reason = input.reason.trim();
    if (!decidedBy) throw new Error("Informe quem tomou a decis\xE3o sobre o dado.");
    if (!reason) throw new Error("Registre o motivo da decis\xE3o.");
    const target = snapshot.results.find((result) => resultMatches(result, input));
    if (!target?.resolutionCandidate) {
      throw new Error("Este resultado n\xE3o possui evid\xEAncias para uma decis\xE3o assistida.");
    }
    const original = target.manualResolution?.original ?? {
      percentage: target.percentage,
      score: target.score ?? null,
      scoreMax: target.scoreMax ?? null,
      dataStatus: target.dataStatus
    };
    const next = {
      ...target,
      percentage: input.decision === "confirmed_zero" ? 0 : null,
      score: input.decision === "confirmed_zero" ? 0 : null,
      scoreMax: input.decision === "confirmed_zero" ? target.resolutionCandidate.suggestedScoreMax : null,
      dataStatus: input.decision === "confirmed_zero" ? "ok" : "ausente",
      manualResolution: {
        decision: input.decision,
        decidedAt: now.toISOString(),
        decidedBy,
        reason,
        original
      }
    };
    return {
      ...snapshot,
      results: snapshot.results.map((result) => resultMatches(result, input) ? next : result)
    };
  }
  function undoAssessmentResultResolution(snapshot, input) {
    const target = snapshot.results.find((result) => resultMatches(result, input));
    if (!target?.manualResolution) throw new Error("N\xE3o h\xE1 decis\xE3o manual para desfazer neste resultado.");
    const { original } = target.manualResolution;
    const restored = {
      ...target,
      percentage: original.percentage,
      score: original.score,
      scoreMax: original.scoreMax,
      dataStatus: original.dataStatus
    };
    delete restored.manualResolution;
    return {
      ...snapshot,
      results: snapshot.results.map((result) => resultMatches(result, input) ? restored : result)
    };
  }
  function slug(value) {
    return value.normalize("NFD").replace(/[\u0300-\u036f]/gu, "").toLowerCase().replace(/[^a-z0-9]+/gu, "-").replace(/^-|-$/gu, "");
  }
  function groupMembers(snapshot, input) {
    const available = new Map(
      snapshot.assessments.map((assessment) => [assessment.id, assessment])
    );
    const definition = {
      type: input.type,
      assessmentIds: input.type === "manual" ? [...new Set(input.assessmentIds)] : [],
      filter: input.type === "dynamic" ? input.filter ?? {} : null,
      matchMode: input.matchMode ?? "all"
    };
    if (input.type === "dynamic") {
      if (activeGroupCriteria(definition.filter).length === 0) {
        throw new Error("Defina ao menos um crit\xE9rio para o grupo din\xE2mico.");
      }
    } else {
      const missing = definition.assessmentIds.filter((id) => !available.has(id));
      if (missing.length > 0) {
        throw new Error(`${missing.length} assessment(s) do grupo n\xE3o existem mais.`);
      }
    }
    const result = computeGroupResult(snapshot.assessments, definition);
    if (result.assessmentIds.length === 0) {
      throw new Error("O grupo precisa conter ao menos um assessment.");
    }
    return { definition, result };
  }
  function recomputeDynamicGroups(snapshot) {
    const groups = snapshot.groups.map((group) => {
      const definition = readGroupDefinition(group);
      if (definition.type !== "dynamic" || !definition.filter) {
        return hydrateStoredGroup(group);
      }
      const computed = computeGroupResult(snapshot.assessments, definition);
      return {
        ...group,
        type: definition.type,
        filter: definition.filter,
        matchMode: definition.matchMode,
        definition,
        computed,
        assessmentIds: computed.assessmentIds,
        personIds: computed.personIds
      };
    });
    return { ...snapshot, groups };
  }
  function saveGroup(snapshot, input, now = /* @__PURE__ */ new Date()) {
    const name = input.name.trim();
    if (!name) throw new Error("Informe um nome para o grupo.");
    const existing = input.id ? snapshot.groups.find((group2) => group2.id === input.id) : void 0;
    if (input.id && !existing) throw new Error("O grupo selecionado n\xE3o existe mais.");
    const members = groupMembers(snapshot, input);
    const id = existing?.id ?? `group-${slug(name) || "sem-nome"}-${now.getTime().toString(36)}`;
    const group = {
      id,
      name,
      type: input.type,
      personIds: members.result.personIds,
      assessmentIds: members.result.assessmentIds,
      filter: members.definition.filter,
      matchMode: members.definition.matchMode,
      definition: members.definition,
      computed: members.result
    };
    return {
      snapshot: {
        ...snapshot,
        groups: existing ? snapshot.groups.map((item) => item.id === id ? group : item) : [...snapshot.groups, group]
      },
      group
    };
  }
  function duplicateGroup(snapshot, groupId, now = /* @__PURE__ */ new Date()) {
    const source = snapshot.groups.find((group) => group.id === groupId);
    if (!source) throw new Error("O grupo selecionado n\xE3o existe mais.");
    const definition = readGroupDefinition(source);
    const existingNames = new Set(snapshot.groups.map((group) => group.name));
    let name = `C\xF3pia de ${source.name}`;
    let suffix = 2;
    while (existingNames.has(name)) {
      name = `C\xF3pia ${suffix} de ${source.name}`;
      suffix += 1;
    }
    return saveGroup(snapshot, {
      name,
      type: definition.type,
      assessmentIds: definition.assessmentIds,
      filter: definition.filter,
      matchMode: definition.matchMode
    }, now);
  }
  function deleteGroup(snapshot, groupId) {
    if (!snapshot.groups.some((group) => group.id === groupId)) {
      throw new Error("O grupo selecionado n\xE3o existe mais.");
    }
    return {
      ...snapshot,
      groups: snapshot.groups.filter((group) => group.id !== groupId)
    };
  }
  function deleteAssessments(snapshot, assessmentIds) {
    const ids = new Set(assessmentIds);
    if (ids.size === 0) throw new Error("Selecione ao menos um assessment para excluir.");
    const existingCount = snapshot.assessments.filter((assessment) => ids.has(assessment.id)).length;
    if (existingCount !== ids.size) {
      throw new Error("A sele\xE7\xE3o cont\xE9m assessments que n\xE3o existem mais.");
    }
    const assessments = snapshot.assessments.filter((assessment) => !ids.has(assessment.id));
    const retainedPersonIds = new Set(assessments.map((assessment) => assessment.personId));
    const people = snapshot.people.filter((person) => retainedPersonIds.has(person.id));
    const groups = snapshot.groups.map((group) => {
      const definition = readGroupDefinition(group);
      const nextDefinition = definition.type === "manual" ? {
        ...definition,
        assessmentIds: definition.assessmentIds.filter((id) => !ids.has(id))
      } : definition;
      const computed = computeGroupResult(assessments, nextDefinition);
      return {
        ...group,
        type: nextDefinition.type,
        filter: nextDefinition.filter,
        matchMode: nextDefinition.matchMode,
        definition: nextDefinition,
        computed,
        assessmentIds: computed.assessmentIds,
        personIds: computed.personIds
      };
    });
    const next = recomputeDynamicGroups({
      ...snapshot,
      assessments,
      people,
      results: snapshot.results.filter((result) => !ids.has(result.assessmentId)),
      groups
    });
    return {
      snapshot: next,
      deletedAssessments: existingCount,
      deletedPeople: snapshot.people.length - people.length
    };
  }
  function bumpFramework(snapshot, framework) {
    return {
      ...snapshot,
      framework: { ...framework, version: snapshot.framework.version + 1 }
    };
  }
  function mutateFramework(snapshot, mutation) {
    const framework = snapshot.framework;
    const roles = framework.roles ?? [];
    const specializations = framework.specializations ?? [];
    if (mutation.type === "rename-framework") {
      const name2 = mutation.name.trim();
      if (!name2) throw new Error("Informe um nome para o framework.");
      return bumpFramework(snapshot, { ...framework, name: name2 });
    }
    if (mutation.type === "upsert-role") {
      const name2 = mutation.name.trim();
      if (!name2) throw new Error("Informe o nome do cargo.");
      if (mutation.roleId) {
        if (!roles.some((role) => role.id === mutation.roleId)) throw new Error("O cargo n\xE3o existe mais.");
        return bumpFramework(snapshot, {
          ...framework,
          roles: roles.map((role) => role.id === mutation.roleId ? { ...role, name: name2 } : role)
        });
      }
      const id = slug(name2);
      if (!id || roles.some((role) => role.id === id)) throw new Error("J\xE1 existe um cargo com esse identificador.");
      return bumpFramework(snapshot, {
        ...framework,
        roles: [...roles, { id, name: name2, expectations: [] }]
      });
    }
    if (mutation.type === "delete-role") {
      if (snapshot.assessments.some((assessment) => assessment.context?.roleId === mutation.roleId)) {
        throw new Error("Este cargo est\xE1 atribu\xEDdo a assessments e n\xE3o pode ser exclu\xEDdo.");
      }
      if (!roles.some((role) => role.id === mutation.roleId)) throw new Error("O cargo n\xE3o existe mais.");
      return bumpFramework(snapshot, { ...framework, roles: roles.filter((role) => role.id !== mutation.roleId) });
    }
    if (mutation.type === "upsert-role-expectation") {
      if (!framework.capabilities.some((capability2) => capability2.id === mutation.capabilityId)) throw new Error("A capability n\xE3o existe no framework.");
      if (mutation.referencedLevels.some((level) => !/^N[1-5]$/u.test(level))) throw new Error("As refer\xEAncias devem estar entre N1 e N5.");
      const role = roles.find((item) => item.id === mutation.roleId);
      if (!role) throw new Error("O cargo n\xE3o existe mais.");
      const description = mutation.description.trim();
      const nextExpectation = {
        capabilityId: mutation.capabilityId,
        description,
        referencedLevels: [...new Set(mutation.referencedLevels)].sort(),
        parsingStatus: mutation.referencedLevels.length > 0 ? "parsed" : "partial"
      };
      const expectations = role.expectations.some((item) => item.capabilityId === mutation.capabilityId) ? role.expectations.map((item) => item.capabilityId === mutation.capabilityId ? nextExpectation : item) : [...role.expectations, nextExpectation];
      return bumpFramework(snapshot, {
        ...framework,
        roles: roles.map((item) => item.id === role.id ? { ...item, expectations } : item)
      });
    }
    if (mutation.type === "upsert-specialization") {
      const name2 = mutation.name.trim();
      const group = mutation.group.trim() || "Design";
      if (!name2) throw new Error("Informe o nome da especializa\xE7\xE3o.");
      if (mutation.specializationId) {
        if (!specializations.some((item) => item.id === mutation.specializationId)) throw new Error("A especializa\xE7\xE3o n\xE3o existe mais.");
        return bumpFramework(snapshot, {
          ...framework,
          specializations: specializations.map((item) => item.id === mutation.specializationId ? { ...item, name: name2, group } : item)
        });
      }
      const id = slug(name2);
      if (!id || specializations.some((item) => item.id === id)) throw new Error("J\xE1 existe uma especializa\xE7\xE3o com esse identificador.");
      return bumpFramework(snapshot, {
        ...framework,
        specializations: [...specializations, {
          id,
          name: name2,
          group,
          capabilityApplicability: framework.capabilities.map((capability2) => ({
            capabilityId: capability2.id,
            applicable: capability2.type === "soft"
          }))
        }]
      });
    }
    if (mutation.type === "delete-specialization") {
      if (snapshot.assessments.some((assessment) => assessment.context?.specializationId === mutation.specializationId)) {
        throw new Error("Esta especializa\xE7\xE3o est\xE1 atribu\xEDda a assessments e n\xE3o pode ser exclu\xEDda.");
      }
      if (!specializations.some((item) => item.id === mutation.specializationId)) throw new Error("A especializa\xE7\xE3o n\xE3o existe mais.");
      return bumpFramework(snapshot, {
        ...framework,
        specializations: specializations.filter((item) => item.id !== mutation.specializationId)
      });
    }
    if (mutation.type === "set-applicability") {
      if (!framework.capabilities.some((item) => item.id === mutation.capabilityId)) throw new Error("A capability n\xE3o existe no framework.");
      const specialization = specializations.find((item) => item.id === mutation.specializationId);
      if (!specialization) throw new Error("A especializa\xE7\xE3o n\xE3o existe mais.");
      const capabilityApplicability = specialization.capabilityApplicability.some((item) => item.capabilityId === mutation.capabilityId) ? specialization.capabilityApplicability.map((item) => item.capabilityId === mutation.capabilityId ? { ...item, applicable: mutation.applicable } : item) : [...specialization.capabilityApplicability, { capabilityId: mutation.capabilityId, applicable: mutation.applicable }];
      return bumpFramework(snapshot, {
        ...framework,
        specializations: specializations.map((item) => item.id === specialization.id ? { ...item, capabilityApplicability } : item)
      });
    }
    const capability = framework.capabilities.find((item) => item.id === mutation.capabilityId);
    if (!capability) throw new Error("A capability n\xE3o existe no framework.");
    const name = mutation.name.trim();
    if (!name) throw new Error("Informe o nome da capability.");
    return bumpFramework(snapshot, {
      ...framework,
      capabilities: framework.capabilities.map((item) => item.id === capability.id ? {
        ...item,
        name,
        definition: mutation.definition.trim()
      } : item)
    });
  }
  function mutateCatalog(snapshot, mutation, now = /* @__PURE__ */ new Date()) {
    if (mutation.type === "delete-course") {
      if (!snapshot.catalog.some((course2) => course2.id === mutation.courseId)) {
        throw new Error("O curso selecionado n\xE3o existe mais.");
      }
      return {
        ...snapshot,
        catalog: snapshot.catalog.filter((course2) => course2.id !== mutation.courseId)
      };
    }
    const title = mutation.title.trim();
    if (!title) throw new Error("Informe o nome do curso.");
    const capabilityIds = [...new Set(mutation.capabilityIds)];
    if (capabilityIds.length === 0) {
      throw new Error("Associe o curso a pelo menos uma capability.");
    }
    const knownCapabilityIds = new Set(
      snapshot.framework.capabilities.map((capability) => capability.id)
    );
    if (capabilityIds.some((capabilityId) => !knownCapabilityIds.has(capabilityId))) {
      throw new Error("O curso cont\xE9m uma capability que n\xE3o existe no framework.");
    }
    const existing = mutation.courseId ? snapshot.catalog.find((course2) => course2.id === mutation.courseId) : void 0;
    if (mutation.courseId && !existing) {
      throw new Error("O curso selecionado n\xE3o existe mais.");
    }
    const id = existing?.id ?? `course-${slug(title) || "sem-nome"}-${now.getTime().toString(36)}`;
    const course = {
      id,
      title,
      capabilityIds,
      level: mutation.level?.trim() || null,
      url: mutation.url?.trim() || null,
      trackName: mutation.trackName.trim(),
      objective: mutation.objective.trim(),
      expectedOutcome: mutation.expectedOutcome.trim(),
      careerConnection: mutation.careerConnection.trim()
    };
    return {
      ...snapshot,
      catalog: existing ? snapshot.catalog.map((item) => item.id === existing.id ? course : item) : [...snapshot.catalog, course]
    };
  }

  // src/cycles/cycleModel.ts
  function slug2(value) {
    return value.normalize("NFD").replace(/[\u0300-\u036f]/gu, "").toLocaleLowerCase("pt-BR").replace(/[^a-z0-9]+/gu, "-").replace(/^-|-$/gu, "") || "sem-nome";
  }
  function legacyCycleId(name) {
    return `cycle-legacy-${slug2(name)}`;
  }
  function readAssessmentCycleId(assessment) {
    const name = assessment.context?.cycle?.trim();
    return assessment.context?.cycleId ?? (name ? legacyCycleId(name) : null);
  }
  function hydrateCycles(snapshot) {
    const stored = new Map((snapshot.cycles ?? []).map((cycle) => [cycle.id, cycle]));
    for (const assessment of snapshot.assessments) {
      const name = assessment.context?.cycle?.trim();
      const id = readAssessmentCycleId(assessment);
      if (!name || !id || stored.has(id)) continue;
      const fallbackDate = assessment.completedAt ?? snapshot.workspace.importedAt;
      stored.set(id, {
        id,
        name,
        status: "active",
        createdAt: fallbackDate,
        updatedAt: fallbackDate
      });
    }
    return [...stored.values()].sort(
      (left, right) => left.name.localeCompare(right.name, "pt-BR")
    );
  }
  function summarizeCycles(snapshot) {
    return hydrateCycles(snapshot).map((cycle) => {
      const assessments = snapshot.assessments.filter(
        (assessment) => readAssessmentCycleId(assessment) === cycle.id
      );
      return {
        ...cycle,
        assessmentCount: assessments.length,
        peopleCount: new Set(assessments.map((assessment) => assessment.personId)).size,
        basisRecordedCount: assessments.filter((assessment) => assessment.methodologyBasis).length,
        basisEligibleCount: assessments.filter(
          (assessment) => assessment.context?.roleId && assessment.context?.specializationId
        ).length
      };
    });
  }
  function findCycleByName(snapshot, name) {
    const normalized = name.trim().toLocaleLowerCase("pt-BR");
    return hydrateCycles(snapshot).find(
      (cycle) => cycle.name.trim().toLocaleLowerCase("pt-BR") === normalized
    ) ?? null;
  }
  function saveCycle(snapshot, input, now = /* @__PURE__ */ new Date()) {
    const name = input.name.trim();
    if (!name) throw new Error("Informe o nome do ciclo.");
    const cycles = hydrateCycles(snapshot);
    const duplicate = cycles.find(
      (cycle2) => cycle2.id !== input.id && cycle2.name.toLocaleLowerCase("pt-BR") === name.toLocaleLowerCase("pt-BR")
    );
    if (duplicate) throw new Error("J\xE1 existe um ciclo com esse nome.");
    const existing = input.id ? cycles.find((cycle2) => cycle2.id === input.id) : null;
    if (input.id && !existing) throw new Error("O ciclo editado n\xE3o existe mais.");
    const timestamp2 = now.toISOString();
    const cycle = {
      id: existing?.id ?? `cycle-${now.getTime().toString(36)}-${slug2(name)}`,
      name,
      status: input.status,
      createdAt: existing?.createdAt ?? timestamp2,
      updatedAt: timestamp2,
      frameworkSnapshot: existing?.frameworkSnapshot
    };
    const assessments = existing && existing.name !== name ? snapshot.assessments.map(
      (assessment) => readAssessmentCycleId(assessment) === existing.id && assessment.context ? { ...assessment, context: { ...assessment.context, cycleId: existing.id, cycle: name } } : assessment
    ) : snapshot.assessments;
    return {
      snapshot: {
        ...snapshot,
        assessments,
        cycles: [...cycles.filter((item) => item.id !== cycle.id), cycle]
      },
      cycle
    };
  }
  function registerLegacyCycleBasis(snapshot, cycleId, now = /* @__PURE__ */ new Date()) {
    const cycle = hydrateCycles(snapshot).find((item) => item.id === cycleId);
    if (!cycle) throw new Error("O ciclo selecionado n\xE3o existe.");
    let updatedAssessments = 0;
    const assessments = snapshot.assessments.map((assessment) => {
      if (readAssessmentCycleId(assessment) !== cycleId || assessment.methodologyBasis) return assessment;
      const roleId = assessment.context?.roleId;
      const specializationId = assessment.context?.specializationId;
      if (!roleId || !specializationId) return assessment;
      updatedAssessments += 1;
      return {
        ...assessment,
        context: assessment.context ? { ...assessment.context, cycleId, cycle: cycle.name } : assessment.context,
        methodologyBasis: {
          frameworkId: snapshot.framework.id,
          frameworkVersion: snapshot.framework.version,
          roleId,
          specializationId,
          capturedAt: now.toISOString(),
          source: "explicit_legacy_confirmation"
        }
      };
    });
    if (updatedAssessments === 0) {
      throw new Error("Nenhum assessment contextualizado deste ciclo precisa registrar a base.");
    }
    return {
      snapshot: {
        ...snapshot,
        assessments,
        cycles: hydrateCycles(snapshot).map((item) => item.id === cycleId ? { ...item, frameworkSnapshot: item.frameworkSnapshot ?? snapshot.framework } : item)
      },
      updatedAssessments
    };
  }

  // src/import/mergeAssessmentImport.ts
  function workspaceName(fileName) {
    return fileName.replace(/\.csv$/iu, "").trim() || "Skill Mapping";
  }
  function mergeAssessmentImport(current, incoming) {
    if (current?.workspace.id === "synthetic-load-proof" || current?.workspace.name.startsWith("Prova sint\xE9tica")) {
      throw new Error(
        "A prova sint\xE9tica est\xE1 ativa. Restaure o template padr\xE3o antes de persistir um CSV real."
      );
    }
    if (incoming.assessments.length === 0 || incoming.results.length === 0) {
      throw new Error("A importa\xE7\xE3o n\xE3o cont\xE9m assessments e resultados v\xE1lidos.");
    }
    const existingAssessmentIds = new Set(
      current?.assessments.map((assessment) => assessment.id) ?? []
    );
    const conflictingIds = incoming.assessments.map((assessment) => assessment.id).filter((id) => existingAssessmentIds.has(id));
    if (conflictingIds.length > 0) {
      throw new Error(
        `${conflictingIds.length} assessment(s) j\xE1 existem neste workspace. A importa\xE7\xE3o foi cancelada sem alterar o documento.`
      );
    }
    const people = new Map(
      (current?.people ?? []).map((person) => [person.id, person])
    );
    const peopleByFunctionalId = /* @__PURE__ */ new Map();
    const peopleBySourceCandidateId = /* @__PURE__ */ new Map();
    for (const person of people.values()) {
      if (person.functionalId) {
        const existing = peopleByFunctionalId.get(person.functionalId);
        if (existing && existing.id !== person.id) {
          throw new Error(`O workspace j\xE1 possui duas pessoas com a matr\xEDcula ${person.functionalId}.`);
        }
        peopleByFunctionalId.set(person.functionalId, person);
      }
      const sourceIds = person.sourceCandidateIds?.length ? person.sourceCandidateIds : person.functionalId ? [] : [person.id];
      sourceIds.forEach((sourceId) => {
        const existing = peopleBySourceCandidateId.get(sourceId);
        if (existing && existing.id !== person.id) {
          throw new Error(`O Candidate Id ${sourceId} j\xE1 est\xE1 associado a mais de uma pessoa.`);
        }
        peopleBySourceCandidateId.set(sourceId, person);
      });
    }
    const reconciledPersonIds = /* @__PURE__ */ new Map();
    for (const incomingPerson of incoming.people) {
      const functionalId = incomingPerson.functionalId;
      const normalized = normalizeFunctionalId(functionalId);
      if (!functionalId || !normalized.valid || normalized.normalized !== functionalId) {
        throw new Error("A importa\xE7\xE3o cont\xE9m uma matr\xEDcula funcional ausente ou inv\xE1lida.");
      }
      const sourceIds = [...new Set(incomingPerson.sourceCandidateIds ?? [])];
      if (sourceIds.length === 0) {
        throw new Error(`A matr\xEDcula ${incomingPerson.functionalId} n\xE3o possui Candidate Id de origem.`);
      }
      const functionalMatch = peopleByFunctionalId.get(functionalId);
      const sourceMatches = [...new Set(sourceIds.map((sourceId) => peopleBySourceCandidateId.get(sourceId)).filter((person) => Boolean(person)))];
      if (sourceMatches.length > 1) {
        throw new Error(`Os Candidate Ids de ${functionalId} apontam para pessoas diferentes.`);
      }
      const sourceMatch = sourceMatches[0];
      if (functionalMatch && sourceMatch && functionalMatch.id !== sourceMatch.id) {
        throw new Error(
          `Conflito de identidade: a matr\xEDcula ${functionalId} e seu Candidate Id apontam para pessoas diferentes.`
        );
      }
      if (sourceMatch?.functionalId && sourceMatch.functionalId !== functionalId) {
        throw new Error(
          `Conflito de identidade: um Candidate Id conhecido mudou de ${sourceMatch.functionalId} para ${functionalId}.`
        );
      }
      const existing = functionalMatch ?? sourceMatch;
      const targetId = existing?.id ?? incomingPerson.id;
      if (!existing && people.has(targetId)) {
        throw new Error(`O ID t\xE9cnico ${targetId} j\xE1 pertence a outra pessoa.`);
      }
      const reconciled = existing ? {
        ...existing,
        name: incomingPerson.name || existing.name,
        sourceName: incomingPerson.sourceName ?? existing.sourceName ?? null,
        functionalId,
        functionalIdRaw: incomingPerson.functionalIdRaw ?? functionalId,
        sourceCandidateIds: [.../* @__PURE__ */ new Set([
          ...existing.sourceCandidateIds ?? (existing.functionalId ? [] : [existing.id]),
          ...sourceIds
        ])],
        email: incomingPerson.email ?? existing.email
      } : incomingPerson;
      people.set(targetId, { ...reconciled, id: targetId });
      peopleByFunctionalId.set(functionalId, { ...reconciled, id: targetId });
      sourceIds.forEach((sourceId) => {
        peopleBySourceCandidateId.set(sourceId, { ...reconciled, id: targetId });
      });
      reconciledPersonIds.set(incomingPerson.id, targetId);
    }
    const assessments = incoming.assessments.map((assessment) => {
      const personId = reconciledPersonIds.get(assessment.personId);
      if (!personId) throw new Error(`O assessment ${assessment.id} n\xE3o possui pessoa funcional v\xE1lida.`);
      return { ...assessment, personId };
    });
    const results = incoming.results.map((result) => {
      const personId = reconciledPersonIds.get(result.personId);
      if (!personId) throw new Error(`Um resultado de ${result.assessmentId} n\xE3o possui pessoa funcional v\xE1lida.`);
      return { ...result, personId };
    });
    const snapshot = {
      workspace: current?.workspace ?? {
        id: `workspace-${incoming.sourceHash.replace(/[^a-z0-9]/giu, "-")}`,
        name: workspaceName(incoming.fileName),
        importedAt: incoming.importedAt,
        sourceFileName: incoming.fileName,
        sourceHash: incoming.sourceHash
      },
      framework: current?.framework ?? incoming.framework,
      people: [...people.values()],
      assessments: [...current?.assessments ?? [], ...assessments],
      results: [...current?.results ?? [], ...results],
      groups: current?.groups ?? [],
      catalog: current?.catalog.length ? current.catalog : incoming.catalog,
      cycles: current?.cycles ?? [],
      developmentActions: current?.developmentActions ?? [],
      reportRecords: current?.reportRecords ?? []
    };
    if (current) {
      snapshot.workspace = {
        ...current.workspace,
        importedAt: incoming.importedAt,
        sourceFileName: incoming.fileName,
        sourceHash: incoming.sourceHash
      };
    }
    return {
      snapshot: recomputeDynamicGroups({ ...snapshot, cycles: hydrateCycles(snapshot) }),
      importedPeople: incoming.people.length,
      importedAssessments: incoming.assessments.length,
      importedResults: incoming.results.length
    };
  }

  // src/people/personDirectory.ts
  function timestamp(value) {
    if (!value) return Number.NEGATIVE_INFINITY;
    const parsed = Date.parse(value);
    return Number.isFinite(parsed) ? parsed : Number.NEGATIVE_INFINITY;
  }
  function assessmentContext(assessment, person) {
    const context = assessment.context;
    return {
      roleId: context ? context.roleId : person.roleId,
      specializationId: context ? context.specializationId : person.specializationId,
      additionalRoles: readAdditionalRoles(
        context ? context.additionalRoles : person.additionalRoles,
        context ? context.seniority : person.seniority
      ),
      cycle: context?.cycle ?? null
    };
  }
  function issue(value, target) {
    target.push(value);
  }
  var evidenceWarningLabels = {
    ausente: "valor ausente",
    invalido: "valor inv\xE1lido",
    sem_max: "m\xE1ximo ausente ou zero",
    sem_coluna: "coluna n\xE3o reconhecida"
  };
  function evidenceWarningDetail(results) {
    const problematic = results.filter(
      (result) => result.dataStatus !== "ok"
    );
    const visible = problematic.slice(0, 4).map(
      (result) => `${result.capabilityId} ${result.level}: ${evidenceWarningLabels[result.dataStatus]}`
    );
    const remaining = problematic.length - visible.length;
    return [
      ...visible,
      ...remaining > 0 ? [`+${remaining} outro(s)`] : []
    ].join("; ");
  }
  function buildDataQuality(snapshot) {
    const issues = [];
    const people = new Map(snapshot.people.map((person) => [person.id, person]));
    const roles = new Map((snapshot.framework.roles ?? []).map((role) => [role.id, role]));
    const specializations = new Set(
      (snapshot.framework.specializations ?? []).map((item) => item.id)
    );
    const resultsByAssessment = /* @__PURE__ */ new Map();
    snapshot.results.forEach((result) => {
      const current = resultsByAssessment.get(result.assessmentId) ?? [];
      current.push(result);
      resultsByAssessment.set(result.assessmentId, current);
    });
    const capabilityNames = new Map(
      snapshot.framework.capabilities.map((capability) => [capability.id, capability.name])
    );
    const resolvedDecisions = snapshot.results.flatMap((result) => {
      if (!result.manualResolution) return [];
      return [{
        id: `decision-${result.assessmentId}-${result.capabilityId}-${result.level}`,
        personId: result.personId,
        assessmentId: result.assessmentId,
        capabilityId: result.capabilityId,
        capabilityName: capabilityNames.get(result.capabilityId) ?? result.capabilityId,
        level: result.level,
        decision: result.manualResolution.decision,
        decidedAt: result.manualResolution.decidedAt,
        decidedBy: result.manualResolution.decidedBy,
        reason: result.manualResolution.reason
      }];
    });
    const peopleByFunctionalId = /* @__PURE__ */ new Map();
    const peopleByCandidateId = /* @__PURE__ */ new Map();
    snapshot.people.forEach((person) => {
      const normalized = normalizeFunctionalId(person.functionalId);
      if (!normalized.valid || normalized.normalized !== person.functionalId) {
        issue({
          id: `identity-functional-${person.id}`,
          category: "identity",
          severity: "blocking",
          entityKind: "person",
          entityId: person.id,
          personId: person.id,
          assessmentId: null,
          title: "Matr\xEDcula funcional ausente ou inv\xE1lida",
          detail: `${person.name} precisa ser reconciliada por uma nova importa\xE7\xE3o v\xE1lida.`,
          correction: "import"
        }, issues);
      } else if (person.functionalId) {
        const current = peopleByFunctionalId.get(person.functionalId) ?? [];
        current.push(person);
        peopleByFunctionalId.set(person.functionalId, current);
      }
      (person.sourceCandidateIds ?? []).forEach((candidateId) => {
        const current = peopleByCandidateId.get(candidateId) ?? [];
        current.push(person);
        peopleByCandidateId.set(candidateId, current);
      });
    });
    peopleByFunctionalId.forEach((matches, functionalId) => {
      if (matches.length < 2) return;
      matches.forEach((person) => issue({
        id: `identity-duplicate-functional-${functionalId}-${person.id}`,
        category: "identity",
        severity: "blocking",
        entityKind: "person",
        entityId: person.id,
        personId: person.id,
        assessmentId: null,
        title: "Matr\xEDcula associada a mais de uma pessoa",
        detail: `${functionalId} aparece em ${matches.length} registros de pessoa.`,
        correction: "import"
      }, issues));
    });
    peopleByCandidateId.forEach((matches, candidateId) => {
      if (matches.length < 2) return;
      matches.forEach((person) => issue({
        id: `identity-duplicate-candidate-${candidateId}-${person.id}`,
        category: "identity",
        severity: "blocking",
        entityKind: "person",
        entityId: person.id,
        personId: person.id,
        assessmentId: null,
        title: "Candidate Id associado a mais de uma pessoa",
        detail: `${candidateId} aparece em ${matches.length} registros de pessoa.`,
        correction: "import"
      }, issues));
    });
    snapshot.assessments.forEach((assessment) => {
      const person = people.get(assessment.personId);
      if (!person) {
        issue({
          id: `identity-orphan-assessment-${assessment.id}`,
          category: "identity",
          severity: "blocking",
          entityKind: "assessment",
          entityId: assessment.id,
          personId: null,
          assessmentId: assessment.id,
          title: "Assessment sem pessoa vinculada",
          detail: `${assessment.testName} referencia uma pessoa inexistente.`,
          correction: "import"
        }, issues);
        return;
      }
      const context = assessmentContext(assessment, person);
      const missing = [
        !context.roleId ? "cargo" : null,
        !context.specializationId ? "especializa\xE7\xE3o" : null
      ].filter((value) => Boolean(value));
      if (missing.length > 0) {
        issue({
          id: `context-missing-${assessment.id}`,
          category: "context",
          severity: "blocking",
          entityKind: "assessment",
          entityId: assessment.id,
          personId: person.id,
          assessmentId: assessment.id,
          title: "Contexto profissional incompleto",
          detail: `${person.name}: informe ${missing.join(" e ")} para ${assessment.testName}.`,
          correction: "context"
        }, issues);
      }
      if (context.roleId) {
        const role = roles.get(context.roleId);
        if (!role) {
          issue({
            id: `framework-role-missing-${assessment.id}`,
            category: "framework",
            severity: "blocking",
            entityKind: "assessment",
            entityId: assessment.id,
            personId: person.id,
            assessmentId: assessment.id,
            title: "Cargo hist\xF3rico n\xE3o existe no framework",
            detail: `${person.name}: o cargo ${context.roleId} precisa ser revisado.`,
            correction: "framework"
          }, issues);
        } else if (!role.expectations.some((expectation) => expectation.referencedLevels.length > 0)) {
          issue({
            id: `framework-role-no-expectation-${assessment.id}`,
            category: "framework",
            severity: "blocking",
            entityKind: "assessment",
            entityId: assessment.id,
            personId: person.id,
            assessmentId: assessment.id,
            title: "Cargo sem expectativa avali\xE1vel",
            detail: `${role.name} n\xE3o possui refer\xEAncias N1\u2013N5 para produzir ader\xEAncia.`,
            correction: "framework"
          }, issues);
        }
      }
      if (context.specializationId && !specializations.has(context.specializationId)) {
        issue({
          id: `framework-specialization-missing-${assessment.id}`,
          category: "framework",
          severity: "blocking",
          entityKind: "assessment",
          entityId: assessment.id,
          personId: person.id,
          assessmentId: assessment.id,
          title: "Especializa\xE7\xE3o hist\xF3rica n\xE3o existe no framework",
          detail: `${person.name}: a especializa\xE7\xE3o ${context.specializationId} precisa ser revisada.`,
          correction: "framework"
        }, issues);
      }
      const assessmentResults = resultsByAssessment.get(assessment.id) ?? [];
      if (assessmentResults.length === 0) {
        issue({
          id: `evidence-empty-${assessment.id}`,
          category: "evidence",
          severity: "blocking",
          entityKind: "assessment",
          entityId: assessment.id,
          personId: person.id,
          assessmentId: assessment.id,
          title: "Assessment sem evid\xEAncias",
          detail: `${person.name}: nenhum resultado de capability foi persistido.`,
          correction: "evidence"
        }, issues);
      } else {
        assessmentResults.filter((result) => result.resolutionCandidate && !result.manualResolution).forEach((result) => {
          const candidate = result.resolutionCandidate;
          issue({
            id: `evidence-human-decision-${assessment.id}-${result.capabilityId}-${result.level}`,
            category: "evidence",
            severity: "warning",
            entityKind: "assessment",
            entityId: assessment.id,
            personId: person.id,
            assessmentId: assessment.id,
            title: "Quest\xE3o n\xE3o respondida \u2014 decis\xE3o necess\xE1ria",
            detail: `${result.capabilityId} ${result.level}: o arquivo informa N/A na se\xE7\xE3o, mas registra a quest\xE3o \u201C${candidate.questionName}\u201D como n\xE3o respondida e com nota 0. O sistema n\xE3o converteu o valor.`,
            correction: "evidence",
            resolutionCandidate: {
              capabilityId: result.capabilityId,
              level: result.level,
              questionName: candidate.questionName,
              questionAnswered: candidate.questionAnswered,
              questionScore: candidate.questionScore,
              suggestedScoreMax: candidate.suggestedScoreMax,
              evidence: candidate.evidence
            }
          }, issues);
        });
        const usable = assessmentResults.filter(
          (result) => result.dataStatus === "ok" || typeof result.percentage === "number" && Number.isFinite(result.percentage)
        );
        if (usable.length === 0) {
          issue({
            id: `evidence-unusable-${assessment.id}`,
            category: "evidence",
            severity: "blocking",
            entityKind: "assessment",
            entityId: assessment.id,
            personId: person.id,
            assessmentId: assessment.id,
            title: "Assessment sem evid\xEAncia utiliz\xE1vel",
            detail: `${assessmentResults.length} resultado(s) existem, mas nenhum est\xE1 v\xE1lido.`,
            correction: "evidence"
          }, issues);
        } else {
          const expectedCapabilities = snapshot.framework.capabilities.length;
          const observedCapabilities = new Set(
            assessmentResults.map((result) => result.capabilityId)
          ).size;
          const problematicResults = assessmentResults.filter(
            (result) => result.dataStatus !== "ok" && !result.manualResolution && !result.resolutionCandidate
          );
          const problematic = problematicResults.length;
          if (observedCapabilities < expectedCapabilities || problematic > 0) {
            issue({
              id: `evidence-partial-${assessment.id}`,
              category: "evidence",
              severity: "warning",
              entityKind: "assessment",
              entityId: assessment.id,
              personId: person.id,
              assessmentId: assessment.id,
              title: "Cobertura de evid\xEAncia requer aten\xE7\xE3o",
              detail: [
                `${observedCapabilities}/${expectedCapabilities} capabilities encontradas; ${problematic} resultado(s) com aviso.`,
                problematic > 0 ? evidenceWarningDetail(problematicResults) : null
              ].filter(Boolean).join(" "),
              correction: "evidence"
            }, issues);
          }
        }
      }
    });
    const catalogCapabilityIds = new Set(
      snapshot.catalog.flatMap((course) => course.capabilityIds)
    );
    const capabilitiesWithoutCourse = snapshot.framework.capabilities.filter(
      (capability) => !catalogCapabilityIds.has(capability.id)
    );
    if (capabilitiesWithoutCourse.length > 0) {
      issue({
        id: "catalog-capabilities-without-course",
        category: "catalog",
        severity: "warning",
        entityKind: "workspace",
        entityId: snapshot.workspace.id,
        personId: null,
        assessmentId: null,
        title: "Capabilities sem curso relacionado",
        detail: `${capabilitiesWithoutCourse.length} capability(ies): ${capabilitiesWithoutCourse.map((item) => item.id).join(", ")}.`,
        correction: "catalog"
      }, issues);
    }
    const countsByCategory = {
      identity: 0,
      context: 0,
      framework: 0,
      catalog: 0,
      evidence: 0
    };
    issues.forEach((item) => {
      countsByCategory[item.category] += 1;
    });
    return {
      issues,
      resolvedDecisions,
      blockingCount: issues.filter((item) => item.severity === "blocking").length,
      warningCount: issues.filter((item) => item.severity === "warning").length,
      affectedPeopleCount: new Set(
        issues.map((item) => item.personId).filter((id) => Boolean(id))
      ).size,
      countsByCategory
    };
  }
  function buildPeopleWorkspaceView(snapshot) {
    const quality = buildDataQuality(snapshot);
    const issuesByPerson = /* @__PURE__ */ new Map();
    quality.issues.forEach((item) => {
      if (!item.personId) return;
      const current = issuesByPerson.get(item.personId) ?? [];
      current.push(item);
      issuesByPerson.set(item.personId, current);
    });
    const assessmentsByPerson = /* @__PURE__ */ new Map();
    snapshot.assessments.forEach((assessment) => {
      const current = assessmentsByPerson.get(assessment.personId) ?? [];
      current.push(assessment);
      assessmentsByPerson.set(assessment.personId, current);
    });
    const people = snapshot.people.map((person) => {
      const assessments = (assessmentsByPerson.get(person.id) ?? []).map((assessment) => ({
        id: assessment.id,
        testName: assessment.testName,
        completedAt: assessment.completedAt,
        percentage: assessment.percentage,
        context: assessmentContext(assessment, person)
      })).sort((left, right) => timestamp(right.completedAt) - timestamp(left.completedAt));
      const personIssues = issuesByPerson.get(person.id) ?? [];
      const latest = assessments[0] ?? null;
      return {
        id: person.id,
        name: person.name,
        sourceName: person.sourceName ?? null,
        functionalId: person.functionalId ?? null,
        email: person.email,
        sourceCandidateIds: person.sourceCandidateIds ?? [],
        assessments,
        latestAssessmentId: latest?.id ?? null,
        currentContext: latest?.context ?? {
          roleId: person.roleId,
          specializationId: person.specializationId,
          additionalRoles: readAdditionalRoles(person.additionalRoles, person.seniority),
          cycle: null
        },
        contextCompleteCount: assessments.filter(
          (assessment) => assessment.context.roleId && assessment.context.specializationId
        ).length,
        groupIds: snapshot.groups.filter((group) => group.personIds.includes(person.id)).map((group) => group.id),
        qualityStatus: personIssues.some((item) => item.severity === "blocking") ? "blocking" : personIssues.length > 0 ? "warning" : "ready",
        qualityIssueCount: personIssues.length
      };
    }).sort((left, right) => left.name.localeCompare(right.name, "pt-BR"));
    return { people, quality };
  }

  // ../../src/domain/constants.ts
  var ALL_CAPS = [
    "H1",
    "H2",
    "H3",
    "H4",
    "H5",
    "H6",
    "H7",
    "H8",
    "H9",
    "H10",
    "S1",
    "S2",
    "S3",
    "S4",
    "S5",
    "S6",
    "S7",
    "S8",
    "S9",
    "S10"
  ];
  var HARD_CAPS = ALL_CAPS.filter((c) => c.startsWith("H"));
  var SOFT_CAPS = ALL_CAPS.filter((c) => c.startsWith("S"));
  var NIVEIS = ["B\xE1sico", "Intermedi\xE1rio", "Avan\xE7ado"];
  var SPEC_DISPLAY = {
    PD: "Product Design",
    CD2: "Content Design",
    SD: "Service Design",
    ContentOps: "Content Ops",
    Visual: "Visual Design",
    DesignOps: "Design Ops"
  };
  var SPEC_GROUP = {
    PD: "UX",
    CD2: "UX",
    SD: "UX",
    ContentOps: "DesignOps",
    Visual: "DesignOps",
    DesignOps: "DesignOps"
  };

  // ../../src/services/calculations.ts
  function buildCapRows(capScores, capMap) {
    return ALL_CAPS.map((capId) => {
      const rows = capScores.filter((s) => s.capabilityId === capId);
      const cap = capMap.get(capId);
      const byNivel = {
        B\u00E1sico: rows.find((r) => r.nivel === "B\xE1sico"),
        Intermedi\u00E1rio: rows.find((r) => r.nivel === "Intermedi\xE1rio"),
        Avan\u00E7ado: rows.find((r) => r.nivel === "Avan\xE7ado")
      };
      let sumScore = 0, sumMax = 0, hasValid = false;
      for (const n of NIVEIS) {
        const s = byNivel[n];
        if (s?.scoreState.kind === "value" && s.maxState.kind === "value" && s.maxState.value > 0) {
          sumScore += s.scoreState.value;
          sumMax += s.maxState.value;
          hasValid = true;
        }
      }
      const pctAgregado = hasValid && sumMax > 0 ? sumScore / sumMax * 100 : null;
      const anyInvalid = NIVEIS.some((n) => byNivel[n]?.statusValidacao === "invalido");
      const anySemMax = NIVEIS.some((n) => byNivel[n]?.statusValidacao === "sem_max");
      const anyAusente = NIVEIS.some((n) => ["ausente", "sem_coluna"].includes(byNivel[n]?.statusValidacao ?? ""));
      return {
        capId,
        nome: cap?.nome ?? "Capability n\xE3o cadastrada",
        tipo: cap?.tipo ?? (capId.startsWith("H") ? "Hard Skill" : "Soft Skill"),
        byNivel,
        pctAgregado,
        integridade: anyInvalid ? "invalido" : anySemMax ? "sem_max" : anyAusente ? "ausente" : "ok"
      };
    });
  }
  function weightedCapRowsPercentage(rows) {
    let score = 0;
    let maxScore = 0;
    for (const row of rows) {
      for (const nivel of NIVEIS) {
        const result = row.byNivel[nivel];
        if (result?.scoreState.kind === "value" && result.maxState.kind === "value" && result.maxState.value > 0) {
          score += result.scoreState.value;
          maxScore += result.maxState.value;
        }
      }
    }
    return maxScore > 0 ? score / maxScore * 100 : null;
  }

  // ../../src/methodology/roleExpectationScope.ts
  function normalizeExpectationMarker(value) {
    return value.normalize("NFD").replace(/[\u0300-\u036f]/gu, "").toLocaleLowerCase("pt-BR").replace(/^[-–—]\s*/u, "").replace(/[.!]+$/u, "").trim();
  }
  function roleExpectationScope(expectation) {
    if (!expectation) return "unconfigured";
    if (expectation.referencedLevels.length > 0) return "expected";
    const marker = normalizeExpectationMarker(
      expectation.sourceValue || expectation.expectedDescription
    );
    return marker === "nao observado" || marker === "sem expectativa para este cargo" ? "not_expected" : "unconfigured";
  }

  // ../../src/methodology/alignmentEngine.ts
  function computeAlignment(capabilityId, evidence, expectation, coverage, isApplicable) {
    if (isApplicable === false) {
      return { capabilityId, observedEvidence: evidence, expectation, coverage, alignmentStatus: "not_applicable", explanation: "Esta capability n\xE3o \xE9 aplic\xE1vel \xE0 especializa\xE7\xE3o selecionada. Nenhuma leitura de ader\xEAncia \xE9 gerada." };
    }
    if (roleExpectationScope(expectation) === "not_expected") {
      return { capabilityId, observedEvidence: evidence, expectation, coverage, alignmentStatus: "not_expected_for_role", explanation: "Esta capability est\xE1 explicitamente fora da expectativa do cargo. O resultado observado \xE9 preservado apenas como contexto." };
    }
    if (!expectation) {
      return { capabilityId, observedEvidence: evidence, expectation, coverage, alignmentStatus: "no_expectation", explanation: "O cargo n\xE3o possui expectativa documentada para esta capability. Nenhuma leitura de ader\xEAncia \xE9 gerada." };
    }
    const aggEvidence = evidence.aggregate;
    if (aggEvidence.dataStatus === "insufficient" || aggEvidence.percentage === null) {
      return { capabilityId, observedEvidence: evidence, expectation, coverage, alignmentStatus: "insufficient_data", explanation: "Dados insuficientes para interpretar esta capability neste assessment." };
    }
    if (coverage.coverageStatus === "unknown") {
      return { capabilityId, observedEvidence: evidence, expectation, coverage, alignmentStatus: "no_expectation", explanation: `O resultado observado est\xE1 dispon\xEDvel, mas a expectativa do cargo n\xE3o possui uma refer\xEAncia avali\xE1vel. ${coverage.explanation}` };
    }
    const levelEvidenceMap = {
      basic: evidence.basic,
      intermediate: evidence.intermediate,
      advanced: evidence.advanced
    };
    const coveredLevelEvidence = coverage.coveredAssessmentLevels.map((l) => levelEvidenceMap[l]).filter((e) => e.dataStatus !== "insufficient");
    if (coveredLevelEvidence.length === 0) {
      return { capabilityId, observedEvidence: evidence, expectation, coverage, alignmentStatus: "insufficient_data", explanation: "Os blocos do assessment relacionados \xE0 expectativa n\xE3o possuem dados v\xE1lidos." };
    }
    const allConsistent = coveredLevelEvidence.every((e) => e.bandId === "consistent");
    const allAtLeastDemonstrated = coveredLevelEvidence.every((e) => e.bandId === "demonstrated" || e.bandId === "consistent");
    const anyDemonstrated = coveredLevelEvidence.some((e) => e.bandId === "demonstrated" || e.bandId === "consistent");
    const anyEmerging = coveredLevelEvidence.some((e) => e.bandId === "emerging");
    const allNotObserved = coveredLevelEvidence.every((e) => e.bandId === "not_observed");
    let alignmentStatus;
    if (allConsistent) alignmentStatus = "evidence_consistent";
    else if (allAtLeastDemonstrated) alignmentStatus = "evidence_available";
    else if (anyDemonstrated || anyEmerging) alignmentStatus = "partial_evidence";
    else if (allNotObserved) alignmentStatus = "evidence_not_observed";
    else alignmentStatus = "partial_evidence";
    return { capabilityId, observedEvidence: evidence, expectation, coverage, alignmentStatus, explanation: "" };
  }

  // ../../src/methodology/coverageMapping.ts
  var ASSESSMENT_LEVEL_MAPPINGS = [
    {
      assessmentLevel: "basic",
      relatedCareerLevels: ["N1", "N2"],
      status: "provisional",
      rationale: "O bloco B\xE1sico tende a cobrir expectativas de entrada (N1) e in\xEDcio de desenvolvimento (N2). Configura\xE7\xE3o provis\xF3ria para valida\xE7\xE3o do prot\xF3tipo."
    },
    {
      assessmentLevel: "intermediate",
      relatedCareerLevels: ["N2", "N3", "N4"],
      status: "provisional",
      rationale: "O bloco Intermedi\xE1rio tende a cobrir expectativas de desenvolvimento (N2, N3) e consolida\xE7\xE3o (N4). Configura\xE7\xE3o provis\xF3ria para valida\xE7\xE3o do prot\xF3tipo."
    },
    {
      assessmentLevel: "advanced",
      relatedCareerLevels: ["N4", "N5"],
      status: "provisional",
      rationale: "O bloco Avan\xE7ado tende a cobrir expectativas de seniority (N4) e expertise (N5). Configura\xE7\xE3o provis\xF3ria para valida\xE7\xE3o do prot\xF3tipo."
    }
  ];
  function getRelatedAssessmentLevels(careerLevels, mappings = ASSESSMENT_LEVEL_MAPPINGS) {
    const result = [];
    for (const m of mappings) {
      if (careerLevels.some((cl) => m.relatedCareerLevels.includes(cl))) {
        result.push(m.assessmentLevel);
      }
    }
    return result;
  }

  // ../../src/methodology/evidenceBands.ts
  var EVIDENCE_BANDS = [
    { id: "not_observed", label: "Evid\xEAncia n\xE3o observada", minPercentage: 0, maxPercentage: 39.99, description: "O assessment n\xE3o apresentou evid\xEAncia suficiente da capability naquele recorte. Isso n\xE3o significa aus\xEAncia da capability na pr\xE1tica profissional.", order: 1 },
    { id: "emerging", label: "Evid\xEAncia emergente", minPercentage: 40, maxPercentage: 59.99, description: "H\xE1 sinais parciais da capability, mas o resultado ainda apresenta inconsist\xEAncia ou cobertura limitada.", order: 2 },
    { id: "demonstrated", label: "Evid\xEAncia demonstrada", minPercentage: 60, maxPercentage: 79.99, description: "O assessment apresentou evid\xEAncia relevante e utiliz\xE1vel da capability naquele recorte.", order: 3 },
    { id: "consistent", label: "Evid\xEAncia consistente", minPercentage: 80, maxPercentage: 100, description: "O resultado apresentou evid\xEAncia recorrente e est\xE1vel dentro do escopo avaliado.", order: 4 }
  ];
  var METHODOLOGY_VERSION = "1.0.0-provisional";
  var METHODOLOGY_DATE = "2026-07";
  function getBandForPercentage(pct, bands = EVIDENCE_BANDS) {
    if (!Number.isFinite(pct)) return null;
    const sorted = [...bands].sort((a, b) => a.minPercentage - b.minPercentage);
    return sorted.find((band, index) => {
      const next = sorted[index + 1];
      return pct >= band.minPercentage && (next ? pct < next.minPercentage : pct <= band.maxPercentage);
    }) ?? null;
  }

  // ../../src/methodology/coverageCalculator.ts
  function computeCoverage(capabilityId, evidence, expectation) {
    if (!expectation) {
      return { capabilityId, coverageStatus: "unknown", coveredAssessmentLevels: [], expectedCareerLevels: [], explanation: "Sem expectativa documentada para este cargo." };
    }
    const careerLevels = expectation.referencedLevels;
    if (careerLevels.length === 0) {
      return { capabilityId, coverageStatus: "unknown", coveredAssessmentLevels: [], expectedCareerLevels: [], explanation: "A expectativa n\xE3o referencia n\xEDveis N1\u2013N5 explicitamente. Cobertura n\xE3o pode ser determinada." };
    }
    const relatedLevels = getRelatedAssessmentLevels(careerLevels);
    if (relatedLevels.length === 0) {
      return { capabilityId, coverageStatus: "unknown", coveredAssessmentLevels: [], expectedCareerLevels: careerLevels, explanation: "Nenhuma rela\xE7\xE3o de cobertura encontrada para os n\xEDveis N referenciados." };
    }
    const levelEvidenceMap = {
      basic: evidence.basic,
      intermediate: evidence.intermediate,
      advanced: evidence.advanced
    };
    const withData = relatedLevels.filter((l) => levelEvidenceMap[l].dataStatus !== "insufficient");
    const covered = withData.filter((l) => {
      const e = levelEvidenceMap[l];
      if (e.percentage === null) return false;
      const band = getBandForPercentage(e.percentage, EVIDENCE_BANDS);
      return band && ["demonstrated", "consistent"].includes(band.id);
    });
    const partial = withData.filter((l) => {
      const e = levelEvidenceMap[l];
      if (e.percentage === null) return false;
      const band = getBandForPercentage(e.percentage, EVIDENCE_BANDS);
      return band && ["emerging"].includes(band.id);
    });
    let coverageStatus;
    if (withData.length === 0) coverageStatus = "unknown";
    else if (covered.length === relatedLevels.length) coverageStatus = "covered";
    else if (covered.length > 0 || partial.length > 0) coverageStatus = "partially_covered";
    else coverageStatus = "not_covered";
    const relNames = { basic: "B\xE1sico", intermediate: "Intermedi\xE1rio", advanced: "Avan\xE7ado" };
    const relDesc = relatedLevels.map((l) => relNames[l] ?? l).join(", ");
    const explanation = `A expectativa referencia ${careerLevels.join(", ")}. Pela configura\xE7\xE3o metodol\xF3gica (provis\xF3ria), isso se relaciona ao(s) bloco(s) ${relDesc} do assessment.`;
    return { capabilityId, coverageStatus, coveredAssessmentLevels: relatedLevels, expectedCareerLevels: careerLevels, explanation };
  }

  // ../../src/methodology/evidenceClassifier.ts
  function classifyPercentage(pct, statusValidacao) {
    if (pct === null) {
      const dataStatus2 = statusValidacao === "sem_coluna" || statusValidacao === "ausente" ? "insufficient" : "partial";
      return { percentage: null, bandId: null, label: "Dados insuficientes", dataStatus: dataStatus2 };
    }
    const band = getBandForPercentage(pct, EVIDENCE_BANDS);
    const dataStatus = statusValidacao === "sem_max" ? "partial" : "available";
    return {
      percentage: pct,
      bandId: band?.id ?? null,
      label: band?.label ?? "Fora do intervalo",
      dataStatus
    };
  }
  function buildCapabilityEvidence(capRow) {
    const basic = capRow.byNivel["B\xE1sico"];
    const intermediate = capRow.byNivel["Intermedi\xE1rio"];
    const advanced = capRow.byNivel["Avan\xE7ado"];
    return {
      capabilityId: capRow.capId,
      basic: classifyPercentage(basic?.percentual ?? null, basic?.statusValidacao ?? "sem_coluna"),
      intermediate: classifyPercentage(intermediate?.percentual ?? null, intermediate?.statusValidacao ?? "sem_coluna"),
      advanced: classifyPercentage(advanced?.percentual ?? null, advanced?.statusValidacao ?? "sem_coluna"),
      aggregate: classifyPercentage(capRow.pctAgregado, capRow.integridade === "sem_coluna" ? "sem_coluna" : capRow.integridade === "ausente" ? "ausente" : capRow.integridade === "invalido" ? "invalido" : "ok")
    };
  }

  // ../../src/methodology/explanationGenerator.ts
  var LEVEL_NAMES = { basic: "B\xE1sico", intermediate: "Intermedi\xE1rio", advanced: "Avan\xE7ado" };
  function generateExplanation(alignment) {
    const { alignmentStatus, observedEvidence, expectation, coverage } = alignment;
    const DISCLAIMER = "Esta leitura utiliza apenas os dados dispon\xEDveis neste assessment e n\xE3o substitui avalia\xE7\xE3o de desempenho, observa\xE7\xE3o profissional ou decis\xE3o de carreira.";
    switch (alignmentStatus) {
      case "not_applicable":
        return `Esta capability n\xE3o \xE9 aplic\xE1vel \xE0 especializa\xE7\xE3o selecionada. ${DISCLAIMER}`;
      case "not_expected_for_role":
        return `O assessment apresentou um resultado para esta capability, mas ela est\xE1 explicitamente fora da expectativa do cargo. O resultado \xE9 preservado como contexto e n\xE3o gera leitura de ader\xEAncia nem recomenda\xE7\xE3o autom\xE1tica de desenvolvimento. ${DISCLAIMER}`;
      case "no_expectation":
        return `O cargo n\xE3o possui uma expectativa avali\xE1vel para esta capability. O resultado observado est\xE1 dispon\xEDvel, mas n\xE3o h\xE1 refer\xEAncia de ader\xEAncia. ${DISCLAIMER}`;
      case "insufficient_data":
        return `Dados insuficientes para interpretar esta capability neste assessment. Verifique a integridade dos dados. ${DISCLAIMER}`;
      default: {
        const coveredLevels = coverage.coveredAssessmentLevels.map((l) => LEVEL_NAMES[l] ?? l);
        const careerLevels = coverage.expectedCareerLevels;
        const bandFn = (e) => e.bandId ? EVIDENCE_BANDS.find((b) => b.id === e.bandId)?.label ?? e.label : "Dados insuficientes";
        const parts = [];
        if (expectation && careerLevels.length > 0) {
          parts.push(`A expectativa do cargo referencia ${careerLevels.join(" e ")}.`);
          parts.push(`A configura\xE7\xE3o metodol\xF3gica (provis\xF3ria) relaciona esse(s) n\xEDvel(is) principalmente ao(s) bloco(s) ${coveredLevels.join(", ")} do assessment.`);
        }
        for (const level of coverage.coveredAssessmentLevels) {
          const levelKey = level;
          const e = observedEvidence[levelKey];
          if (e.dataStatus !== "insufficient" && e.percentage !== null) {
            const pctStr = `${e.percentage.toFixed(1)}%`;
            parts.push(`O resultado ${LEVEL_NAMES[level] ?? level} apresentou ${pctStr}, classificado como ${bandFn(e)}.`);
          }
        }
        const statusPhrases = {
          evidence_consistent: "O resultado indica evid\xEAncia consistente dentro do escopo avaliado.",
          evidence_available: "O resultado indica evid\xEAncia dispon\xEDvel dentro do escopo avaliado.",
          partial_evidence: "O resultado indica correspond\xEAncia parcial dentro do escopo avaliado.",
          evidence_not_observed: "O resultado n\xE3o apresentou evid\xEAncia observ\xE1vel no escopo avaliado."
        };
        if (statusPhrases[alignmentStatus]) parts.push(statusPhrases[alignmentStatus]);
        parts.push("Este resultado n\xE3o confirma sozinho ader\xEAncia completa ao cargo.");
        parts.push(DISCLAIMER);
        return parts.join(" ");
      }
    }
  }

  // src/analytics/analyticsEngine.ts
  var PRIORITIES = [
    "no_action_needed",
    "monitor",
    "develop",
    "prioritize",
    "investigate_data",
    "configure_framework",
    "not_applicable"
  ];
  function mean(values) {
    const valid = values.filter((value) => value !== null && Number.isFinite(value));
    return valid.length > 0 ? valid.reduce((sum, value) => sum + value, 0) / valid.length : null;
  }
  function scoreState(result, kind) {
    if (result.dataStatus === "sem_coluna") return { kind: "no_column" };
    if (result.dataStatus === "invalido") return { kind: "invalid", raw: "valor inv\xE1lido no CSV" };
    if (result.dataStatus === "ausente") return { kind: "absent" };
    const stored = kind === "score" ? result.score : result.scoreMax;
    if (typeof stored === "number" && Number.isFinite(stored)) return { kind: "value", value: stored };
    if (kind === "max" && result.dataStatus === "sem_max") return { kind: "no_column" };
    if (result.percentage !== null && Number.isFinite(result.percentage)) {
      return { kind: "value", value: kind === "score" ? result.percentage : 100 };
    }
    return { kind: "absent" };
  }
  function toDesktopScore(result, capabilityName, capabilityType) {
    const score = scoreState(result, "score");
    const max = scoreState(result, "max");
    return {
      assessmentId: result.assessmentId,
      candidateId: result.personId,
      capabilityId: result.capabilityId,
      capabilityNome: capabilityName,
      capabilityTipo: capabilityType === "hard" ? "Hard Skill" : "Soft Skill",
      nivel: result.level,
      score: score.kind === "value" ? score.value : null,
      scoreMax: max.kind === "value" ? max.value : null,
      percentual: result.percentage,
      origemScore: "pluginData normalizado",
      statusValidacao: result.dataStatus,
      scoreState: score,
      maxState: max,
      scoreColName: null,
      maxColName: null
    };
  }
  function priorityForAlignment(status) {
    if (status === "not_applicable") return "not_applicable";
    if (status === "not_expected_for_role") return "not_applicable";
    if (status === "no_expectation") return "configure_framework";
    if (status === "insufficient_data") return "investigate_data";
    if (status === "evidence_not_observed") return "prioritize";
    if (status === "partial_evidence") return "develop";
    if (status === "evidence_available") return "monitor";
    return "no_action_needed";
  }
  function expectationFor(snapshot, roleId, capabilityId) {
    if (!roleId) return null;
    const role = snapshot.framework.roles?.find((item) => item.id === roleId);
    const expectation = role?.expectations.find((item) => item.capabilityId === capabilityId);
    if (!role || !expectation) return null;
    return {
      cargoId: role.id,
      cargoName: role.name,
      capabilityId,
      expectedDescription: expectation.description,
      referencedLevels: expectation.referencedLevels,
      sourceValue: expectation.description,
      parsingStatus: expectation.parsingStatus
    };
  }
  function applicabilityFor(snapshot, specializationId, capabilityId, capabilityType) {
    if (!specializationId) return null;
    const specialization = snapshot.framework.specializations?.find(
      (item) => item.id === specializationId
    );
    const configured = specialization?.capabilityApplicability.find(
      (item) => item.capabilityId === capabilityId
    );
    return configured?.applicable ?? (capabilityType === "soft" ? true : null);
  }
  function buildIndividualAnalysis(snapshot, assessmentId) {
    const assessment = snapshot.assessments.find((item) => item.id === assessmentId);
    if (!assessment) throw new Error("Assessment n\xE3o encontrado para an\xE1lise.");
    const person = snapshot.people.find((item) => item.id === assessment.personId);
    if (!person) throw new Error("Pessoa do assessment n\xE3o encontrada.");
    const context = assessment.context ?? {
      roleId: person.roleId,
      specializationId: person.specializationId,
      additionalRoles: person.additionalRoles,
      seniority: person.seniority,
      cycle: null
    };
    const additionalRoles = readAdditionalRoles(
      assessment.context ? context.additionalRoles : person.additionalRoles,
      assessment.context ? context.seniority : person.seniority
    );
    const role = snapshot.framework.roles?.find((item) => item.id === context.roleId) ?? null;
    const specialization = snapshot.framework.specializations?.find(
      (item) => item.id === context.specializationId
    ) ?? null;
    const capabilityMap = new Map(
      snapshot.framework.capabilities.map((capability) => [capability.id, {
        id: capability.id,
        nome: capability.name,
        tipo: capability.type === "hard" ? "Hard Skill" : "Soft Skill",
        definicao: capability.definition ?? ""
      }])
    );
    const storedResults = snapshot.results.filter((result) => result.assessmentId === assessmentId);
    const resultMap = new Map(storedResults.map((result) => [
      `${result.capabilityId}:${result.level}`,
      result
    ]));
    const desktopScores = storedResults.map((result) => {
      const capability = snapshot.framework.capabilities.find((item) => item.id === result.capabilityId);
      return toDesktopScore(result, capability?.name ?? result.capabilityId, capability?.type ?? "hard");
    });
    const capRows = buildCapRows(desktopScores, capabilityMap);
    const capabilities = capRows.map((row) => {
      const frameworkCapability = snapshot.framework.capabilities.find((item) => item.id === row.capId);
      const capabilityType = frameworkCapability?.type ?? (row.capId.startsWith("H") ? "hard" : "soft");
      const evidence = buildCapabilityEvidence(row);
      const expectation = expectationFor(snapshot, context.roleId, row.capId);
      const coverage = computeCoverage(row.capId, evidence, expectation);
      const applicable = applicabilityFor(
        snapshot,
        context.specializationId,
        row.capId,
        capabilityType
      );
      const alignment = computeAlignment(row.capId, evidence, expectation, coverage, applicable);
      alignment.explanation = generateExplanation(alignment);
      const priority = priorityForAlignment(alignment.alignmentStatus);
      return {
        capabilityId: row.capId,
        capabilityName: frameworkCapability?.name ?? row.nome,
        capabilityType,
        applicable,
        aggregatePercentage: row.pctAgregado,
        levels: ["B\xE1sico", "Intermedi\xE1rio", "Avan\xE7ado"].map((level) => {
          const result = resultMap.get(`${row.capId}:${level}`);
          return {
            level,
            percentage: result?.percentage ?? null,
            dataStatus: result?.dataStatus ?? "sem_coluna",
            ...result?.manualResolution ? { manualResolution: result.manualResolution } : {}
          };
        }),
        evidenceBandId: evidence.aggregate.bandId,
        evidenceLabel: evidence.aggregate.label,
        alignmentStatus: alignment.alignmentStatus,
        priority,
        explanation: alignment.explanation,
        recommendations: ["develop", "prioritize"].includes(priority) ? snapshot.catalog.filter((course) => course.capabilityIds.includes(row.capId)).slice(0, 3) : []
      };
    });
    const counts = Object.fromEntries(PRIORITIES.map((priority) => [
      priority,
      capabilities.filter((capability) => capability.priority === priority).length
    ]));
    const usable = capabilities.filter(
      (capability) => capability.aggregatePercentage !== null && capability.applicable !== false && capability.alignmentStatus !== "not_expected_for_role"
    );
    const inBookCapabilityIds = new Set(capabilities.filter((capability) => capability.applicable !== false && capability.alignmentStatus !== "not_expected_for_role").map((capability) => capability.capabilityId));
    const strengths = [...usable].sort(
      (left, right) => (right.aggregatePercentage ?? -1) - (left.aggregatePercentage ?? -1)
    );
    const opportunityOrder = {
      prioritize: 0,
      develop: 1,
      investigate_data: 2,
      configure_framework: 3,
      monitor: 4,
      no_action_needed: 5,
      not_applicable: 6
    };
    const opportunities = capabilities.filter((capability) => ["prioritize", "develop", "investigate_data", "configure_framework"].includes(capability.priority)).sort(
      (left, right) => opportunityOrder[left.priority] - opportunityOrder[right.priority] || (left.aggregatePercentage ?? 101) - (right.aggregatePercentage ?? 101)
    );
    const hasPercentageOnly = storedResults.some(
      (result) => result.percentage !== null && (typeof result.score !== "number" || typeof result.scoreMax !== "number")
    );
    return {
      assessmentId,
      personId: person.id,
      personName: person.name,
      personFunctionalId: person.functionalId ?? null,
      personEmail: person.email,
      testName: assessment.testName,
      completedAt: assessment.completedAt,
      status: role && specialization ? "ready" : "context_missing",
      role: role ? { id: role.id, name: role.name } : null,
      specialization: specialization ? { id: specialization.id, name: specialization.name } : null,
      additionalRoles,
      cycle: context.cycle,
      overallPercentage: assessment.percentage,
      hardAveragePercentage: weightedCapRowsPercentage(capRows.filter(
        (row) => row.tipo === "Hard Skill" && inBookCapabilityIds.has(row.capId)
      )),
      softAveragePercentage: weightedCapRowsPercentage(capRows.filter(
        (row) => row.tipo === "Soft Skill" && inBookCapabilityIds.has(row.capId)
      )),
      calculationBasis: hasPercentageOnly ? "percentage_only" : "weighted_scores",
      capabilities,
      counts,
      strengths,
      opportunities
    };
  }
  function normalize(value) {
    return value.normalize("NFD").replace(/[\u0300-\u036f]/gu, "").toLocaleLowerCase("pt-BR").trim();
  }
  function buildCollectiveAnalysis(snapshot, filters = {}) {
    const group = filters.groupId ? snapshot.groups.find((item) => item.id === filters.groupId) : void 0;
    const groupAssessmentIds = group ? new Set(group.assessmentIds ?? snapshot.assessments.filter(
      (assessment) => group.personIds.includes(assessment.personId)
    ).map((assessment) => assessment.id)) : null;
    const people = new Map(snapshot.people.map((person) => [person.id, person]));
    const query = normalize(filters.query ?? "");
    const selected = snapshot.assessments.filter((assessment) => {
      const person = people.get(assessment.personId);
      if (groupAssessmentIds && !groupAssessmentIds.has(assessment.id)) return false;
      if (query && !normalize([
        person?.name ?? "",
        person?.sourceName ?? "",
        person?.functionalId ?? "",
        person?.email ?? "",
        assessment.id
      ].join(" ")).includes(query)) return false;
      if (filters.roleId && assessment.context?.roleId !== filters.roleId) return false;
      if (filters.specializationId && assessment.context?.specializationId !== filters.specializationId) return false;
      if (filters.additionalRole && !readAdditionalRoles(
        assessment.context ? assessment.context.additionalRoles : person?.additionalRoles,
        assessment.context ? assessment.context.seniority : person?.seniority
      ).includes(filters.additionalRole)) return false;
      if (filters.cycle && assessment.context?.cycle !== filters.cycle) return false;
      return true;
    });
    const individual = selected.map((assessment) => buildIndividualAnalysis(snapshot, assessment.id));
    const capabilities = snapshot.framework.capabilities.map((capability) => {
      const allValues = individual.map((analysis) => analysis.capabilities.find((item) => item.capabilityId === capability.id)).filter((item) => Boolean(item));
      const outsideScope = allValues.filter(
        (item) => item.applicable === false || item.alignmentStatus === "not_expected_for_role"
      );
      const values = allValues.filter(
        (item) => item.applicable !== false && item.alignmentStatus !== "not_expected_for_role"
      );
      const percentages = values.map((item) => item.aggregatePercentage).filter((value) => value !== null && Number.isFinite(value));
      const observedPercentages = allValues.map((item) => item.aggregatePercentage).filter((value) => value !== null && Number.isFinite(value));
      return {
        capabilityId: capability.id,
        capabilityName: capability.name,
        capabilityType: capability.type,
        averagePercentage: mean(percentages),
        minimumPercentage: percentages.length > 0 ? Math.min(...percentages) : null,
        maximumPercentage: percentages.length > 0 ? Math.max(...percentages) : null,
        assessmentCount: percentages.length,
        dataCoveragePercentage: individual.length > 0 ? percentages.length / individual.length * 100 : 0,
        observedAveragePercentage: mean(observedPercentages),
        observedAssessmentCount: observedPercentages.length,
        observedDataCoveragePercentage: individual.length > 0 ? observedPercentages.length / individual.length * 100 : 0,
        developingCount: values.filter((item) => ["develop", "prioritize"].includes(item.priority)).length,
        investigateCount: values.filter((item) => ["investigate_data", "configure_framework"].includes(item.priority)).length,
        dataReviewCount: values.filter((item) => item.priority === "investigate_data").length,
        frameworkReviewCount: values.filter((item) => item.priority === "configure_framework").length,
        outsideScopeCount: outsideScope.length,
        outsideScopeObservedCount: outsideScope.filter((item) => item.aggregatePercentage !== null).length
      };
    });
    const strengths = [...capabilities].filter((item) => item.averagePercentage !== null).sort((left, right) => (right.averagePercentage ?? -1) - (left.averagePercentage ?? -1));
    const opportunities = [...capabilities].filter((item) => item.developingCount > 0 || item.investigateCount > 0).sort(
      (left, right) => right.developingCount - left.developingCount || right.investigateCount - left.investigateCount || (left.averagePercentage ?? 101) - (right.averagePercentage ?? 101)
    );
    const overall = individual.map((item) => item.overallPercentage);
    const usableOverall = overall.filter((value) => value !== null);
    const selectedAssessmentIds = new Set(selected.map((assessment) => assessment.id));
    return {
      filters,
      filterLabels: {
        role: filters.roleId ? snapshot.framework.roles?.find((item) => item.id === filters.roleId)?.name ?? filters.roleId : null,
        specialization: filters.specializationId ? snapshot.framework.specializations?.find((item) => item.id === filters.specializationId)?.name ?? filters.specializationId : null,
        additionalRole: filters.additionalRole ?? null,
        cycle: filters.cycle ?? null,
        query: filters.query ?? null
      },
      totalAssessments: individual.length,
      uniquePeople: new Set(individual.map((item) => item.personId)).size,
      contextualizedAssessments: individual.filter((item) => item.status === "ready").length,
      manualDataDecisionCount: snapshot.results.filter(
        (result) => selectedAssessmentIds.has(result.assessmentId) && result.manualResolution
      ).length,
      averageAssessmentPercentage: mean(overall),
      averageHardPercentage: mean(individual.map((item) => item.hardAveragePercentage)),
      averageSoftPercentage: mean(individual.map((item) => item.softAveragePercentage)),
      distribution: {
        above70: usableOverall.filter((value) => value >= 70).length,
        between40And70: usableOverall.filter((value) => value >= 40 && value < 70).length,
        below40: usableOverall.filter((value) => value < 40).length,
        withoutResult: overall.filter((value) => value === null).length
      },
      capabilities,
      strengths,
      opportunities,
      people: individual.map((item) => ({
        assessmentId: item.assessmentId,
        personName: item.personName,
        personFunctionalId: item.personFunctionalId,
        overallPercentage: item.overallPercentage,
        developmentCount: item.counts.develop + item.counts.prioritize,
        investigateCount: item.counts.investigate_data + item.counts.configure_framework
      })).sort(
        (left, right) => (right.overallPercentage ?? -1) - (left.overallPercentage ?? -1)
      )
    };
  }
  function buildGroupComparison(snapshot, leftGroupId, rightGroupId) {
    return buildMultiGroupComparison(snapshot, [leftGroupId, rightGroupId]);
  }
  function buildMultiGroupComparison(snapshot, groupIds) {
    const uniqueGroupIds = [...new Set(groupIds.filter(Boolean))];
    if (uniqueGroupIds.length < 2) {
      throw new Error("Selecione pelo menos dois grupos diferentes para comparar.");
    }
    const selectedGroups = uniqueGroupIds.map((groupId) => {
      const group = snapshot.groups.find((candidate) => candidate.id === groupId);
      if (!group) throw new Error("Um dos grupos selecionados n\xE3o existe mais.");
      return group;
    });
    const analyses = selectedGroups.map((group) => ({
      group,
      analysis: buildCollectiveAnalysis(snapshot, { groupId: group.id }),
      computed: readGroupComputed(group)
    }));
    const groups = analyses.map(({ group, analysis }) => ({
      groupId: group.id,
      groupName: group.name,
      totalAssessments: analysis.totalAssessments,
      uniquePeople: analysis.uniquePeople,
      contextualizedAssessments: analysis.contextualizedAssessments,
      averageAssessmentPercentage: analysis.averageAssessmentPercentage,
      averageHardPercentage: analysis.averageHardPercentage,
      averageSoftPercentage: analysis.averageSoftPercentage
    }));
    const overlaps = analyses.flatMap(
      (leftEntry, leftIndex) => analyses.slice(leftIndex + 1).flatMap((rightEntry) => {
        const rightPeople = new Set(rightEntry.computed.personIds);
        const rightAssessments = new Set(rightEntry.computed.assessmentIds);
        const overlappingPeopleCount = leftEntry.computed.personIds.filter((id) => rightPeople.has(id)).length;
        const overlappingAssessmentCount = leftEntry.computed.assessmentIds.filter((id) => rightAssessments.has(id)).length;
        return overlappingPeopleCount > 0 || overlappingAssessmentCount > 0 ? [{
          leftGroupId: leftEntry.group.id,
          leftGroupName: leftEntry.group.name,
          rightGroupId: rightEntry.group.id,
          rightGroupName: rightEntry.group.name,
          overlappingPeopleCount,
          overlappingAssessmentCount
        }] : [];
      })
    );
    const warnings = [];
    if (overlaps.length > 0) {
      warnings.push(
        `${overlaps.length} par(es) de grupos possuem pessoas ou avalia\xE7\xF5es em comum; trate as m\xE9dias como recortes sobrepostos.`
      );
    }
    const smallGroups = groups.filter((group) => group.uniquePeople < 3);
    if (smallGroups.length > 0) {
      warnings.push(
        `${smallGroups.length} grupo(s) possuem menos de tr\xEAs pessoas; evite expor ou inferir resultados individuais.`
      );
    }
    const capabilityMaps = analyses.map(({ group, analysis }) => ({
      group,
      analysis,
      capabilities: new Map(analysis.capabilities.map((capability) => [capability.capabilityId, capability]))
    }));
    const left = analyses[0].analysis;
    const right = analyses[1].analysis;
    const rightCapabilities = capabilityMaps[1].capabilities;
    const capabilities = left.capabilities.map((leftCapability) => {
      const rightCapability = rightCapabilities.get(leftCapability.capabilityId);
      const differencePercentagePoints = leftCapability.averagePercentage !== null && rightCapability?.averagePercentage !== null && rightCapability?.averagePercentage !== void 0 ? rightCapability.averagePercentage - leftCapability.averagePercentage : null;
      const observedDifferencePercentagePoints = leftCapability.observedAveragePercentage !== null && rightCapability?.observedAveragePercentage !== null && rightCapability?.observedAveragePercentage !== void 0 ? rightCapability.observedAveragePercentage - leftCapability.observedAveragePercentage : null;
      const groupValues = capabilityMaps.map(({ group, analysis, capabilities: currentCapabilities }) => {
        const capability = currentCapabilities.get(leftCapability.capabilityId);
        return {
          groupId: group.id,
          groupName: group.name,
          totalAssessments: analysis.totalAssessments,
          averagePercentage: capability?.averagePercentage ?? null,
          observedAveragePercentage: capability?.observedAveragePercentage ?? null,
          observedAssessmentCount: capability?.observedAssessmentCount ?? 0,
          developingCount: capability?.developingCount ?? 0
        };
      });
      const observed = groupValues.map((value) => value.observedAveragePercentage).filter((value) => value !== null);
      return {
        capabilityId: leftCapability.capabilityId,
        capabilityName: leftCapability.capabilityName,
        capabilityType: leftCapability.capabilityType,
        leftAveragePercentage: leftCapability.averagePercentage,
        rightAveragePercentage: rightCapability?.averagePercentage ?? null,
        differencePercentagePoints,
        leftObservedAveragePercentage: leftCapability.observedAveragePercentage,
        rightObservedAveragePercentage: rightCapability?.observedAveragePercentage ?? null,
        observedDifferencePercentagePoints,
        leftObservedAssessmentCount: leftCapability.observedAssessmentCount,
        rightObservedAssessmentCount: rightCapability?.observedAssessmentCount ?? 0,
        leftDevelopingCount: leftCapability.developingCount,
        rightDevelopingCount: rightCapability?.developingCount ?? 0,
        observedRangePercentagePoints: observed.length >= 2 ? Math.max(...observed) - Math.min(...observed) : null,
        groupValues
      };
    }).sort((first, second) => {
      const firstMagnitude = first.observedRangePercentagePoints === null ? -1 : first.observedRangePercentagePoints;
      const secondMagnitude = second.observedRangePercentagePoints === null ? -1 : second.observedRangePercentagePoints;
      return secondMagnitude - firstMagnitude;
    });
    const firstOverlap = overlaps.find(
      (overlap) => overlap.leftGroupId === groups[0].groupId && overlap.rightGroupId === groups[1].groupId
    );
    return {
      groups,
      overlaps,
      left: groups[0],
      right: groups[1],
      overlappingPeopleCount: firstOverlap?.overlappingPeopleCount ?? 0,
      overlappingAssessmentCount: firstOverlap?.overlappingAssessmentCount ?? 0,
      warnings,
      capabilities
    };
  }

  // src/dashboard/managerialDashboard.ts
  function buildManagerialDashboard(snapshot, quality) {
    const assessmentCount = snapshot.assessments.length;
    const contextualizedAssessmentCount = snapshot.assessments.filter(
      (assessment) => assessment.context?.roleId && assessment.context?.specializationId
    ).length;
    let analysis = null;
    if (assessmentCount > 0) {
      try {
        analysis = buildCollectiveAnalysis(snapshot, {});
      } catch {
        analysis = null;
      }
    }
    const contextCompletionPercentage = assessmentCount > 0 ? contextualizedAssessmentCount / assessmentCount * 100 : 0;
    const status = assessmentCount === 0 ? "empty" : quality.blockingCount > 0 || contextualizedAssessmentCount < assessmentCount ? "attention" : "ready";
    const nextAction = assessmentCount === 0 ? {
      target: "home",
      title: "Importe os assessments",
      detail: "Analise um CSV e confirme a persist\xEAncia para iniciar a leitura do time."
    } : quality.blockingCount > 0 ? {
      target: "people",
      title: `Revise ${quality.blockingCount} bloqueio(s) de qualidade`,
      detail: "Resolva identidade, contexto, framework ou evid\xEAncia antes de confiar nas an\xE1lises."
    } : contextualizedAssessmentCount < assessmentCount ? {
      target: "people",
      title: `Contextualize ${assessmentCount - contextualizedAssessmentCount} assessment(s)`,
      detail: "Complete cargo e especializa\xE7\xE3o para liberar ader\xEAncia e recomenda\xE7\xF5es."
    } : snapshot.groups.length === 0 ? {
      target: "groups",
      title: "Crie um primeiro grupo",
      detail: "Organize um recorte reutiliz\xE1vel para acompanhar uma equipe ou responsabilidade."
    } : {
      target: "analysis",
      title: "Explore maturidade e oportunidades",
      detail: "O workspace est\xE1 contextualizado e possui grupos prontos para an\xE1lise."
    };
    return {
      status,
      peopleCount: snapshot.people.length,
      assessmentCount,
      contextualizedAssessmentCount,
      contextCompletionPercentage,
      blockingIssueCount: quality.blockingCount,
      warningIssueCount: quality.warningCount,
      groupCount: snapshot.groups.length,
      averageAssessmentPercentage: analysis?.averageAssessmentPercentage ?? null,
      averageHardPercentage: analysis?.averageHardPercentage ?? null,
      averageSoftPercentage: analysis?.averageSoftPercentage ?? null,
      topOpportunities: (analysis?.opportunities ?? []).slice(0, 5).map((item) => ({
        capabilityId: item.capabilityId,
        capabilityName: item.capabilityName,
        developingCount: item.developingCount,
        investigateCount: item.investigateCount,
        averagePercentage: item.averagePercentage
      })),
      lastImport: {
        fileName: snapshot.workspace.sourceFileName,
        importedAt: snapshot.workspace.importedAt
      },
      nextAction
    };
  }

  // src/reports/reportNarrative.ts
  function countLabel(count, singular, plural) {
    return `${count} ${count === 1 ? singular : plural}`;
  }
  function formatReportPercentage(value) {
    return value === null ? "\u2014" : `${value.toFixed(1).replace(".", ",")}%`;
  }
  function formatReportDate(value) {
    if (!value) return "Data n\xE3o informada";
    const isoDate = /^(\d{4})-(\d{2})-(\d{2})(?:T|$)/.exec(value.trim());
    if (isoDate) {
      const [, year, month2, day2] = isoDate;
      const parsed = new Date(Date.UTC(Number(year), Number(month2) - 1, Number(day2)));
      if (parsed.getUTCFullYear() === Number(year) && parsed.getUTCMonth() === Number(month2) - 1 && parsed.getUTCDate() === Number(day2)) {
        return `${day2}/${month2}/${year}`;
      }
    }
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value;
    const day = String(date.getUTCDate()).padStart(2, "0");
    const month = String(date.getUTCMonth() + 1).padStart(2, "0");
    return `${day}/${month}/${date.getUTCFullYear()}`;
  }
  function levelDetails(capability) {
    return capability.levels.map((level) => {
      if (level.manualResolution?.decision === "confirmed_zero") {
        return `${level.level}: 0% confirmado por decis\xE3o humana`;
      }
      if (level.manualResolution?.decision === "kept_missing") {
        return `${level.level}: aus\xEAncia mantida por decis\xE3o humana`;
      }
      if (level.percentage !== null) {
        return `${level.level}: ${formatReportPercentage(level.percentage)}`;
      }
      const state = level.dataStatus === "ausente" ? "sem dado" : level.dataStatus === "invalido" ? "dado inv\xE1lido" : level.dataStatus === "sem_max" ? "m\xE1ximo indispon\xEDvel" : "n\xE3o avaliado";
      return `${level.level}: ${state}`;
    }).join(" \xB7 ");
  }
  function buildCapabilityNarrative(capability) {
    const percentage = formatReportPercentage(capability.aggregatePercentage);
    let category;
    let plainSummary;
    if (capability.alignmentStatus === "not_expected_for_role") {
      category = "scope";
      plainSummary = capability.aggregatePercentage === null ? "Esta capacidade est\xE1 explicitamente fora da expectativa do cargo atual e n\xE3o possui resultado utiliz\xE1vel neste assessment. Ela n\xE3o gera gap nem recomenda\xE7\xE3o autom\xE1tica." : `O assessment registrou ${percentage} nesta capacidade, mas ela est\xE1 explicitamente fora da expectativa do cargo atual. O resultado \xE9 preservado como contexto e n\xE3o gera gap nem recomenda\xE7\xE3o autom\xE1tica.`;
    } else if (capability.applicable === false || capability.alignmentStatus === "not_applicable") {
      category = "scope";
      plainSummary = capability.aggregatePercentage === null ? "Esta capacidade n\xE3o faz parte da especializa\xE7\xE3o atual e n\xE3o possui resultado utiliz\xE1vel neste assessment. Ela n\xE3o gera gap nem recomenda\xE7\xE3o autom\xE1tica." : `O assessment registrou ${percentage} nesta capacidade, mas ela n\xE3o faz parte da especializa\xE7\xE3o atual. O resultado \xE9 preservado como contexto e n\xE3o gera gap nem recomenda\xE7\xE3o autom\xE1tica.`;
    } else if (capability.priority === "investigate_data") {
      category = "data";
      plainSummary = "N\xE3o existem dados suficientes para interpretar esta capacidade. Este item n\xE3o representa um resultado de 0% e precisa ser revisado antes de qualquer decis\xE3o.";
    } else if (capability.priority === "configure_framework") {
      category = "framework";
      plainSummary = capability.aggregatePercentage === null ? "N\xE3o h\xE1 resultado suficiente e o cargo tamb\xE9m n\xE3o possui uma expectativa configurada para esta capacidade. Esta \xE9 uma pend\xEAncia dos dados e do framework, n\xE3o da pessoa." : "A avalia\xE7\xE3o possui resultado para esta capacidade, mas o cargo n\xE3o tem uma expectativa configurada que permita interpret\xE1-lo. Esta \xE9 uma pend\xEAncia do framework, n\xE3o da pessoa.";
    } else if (capability.aggregatePercentage === 0) {
      category = "development";
      plainSummary = "Nenhum ponto foi obtido nos blocos v\xE1lidos desta capacidade. Isso sinaliza prioridade para uma conversa e poss\xEDvel desenvolvimento; n\xE3o confirma aus\xEAncia da capacidade no trabalho.";
    } else if (capability.priority === "prioritize") {
      category = "development";
      plainSummary = `O resultado observado foi ${percentage}. Pelas regras atuais do assessment, a evid\xEAncia encontrada foi baixa e merece uma conversa priorit\xE1ria; isso n\xE3o representa uma conclus\xE3o sobre desempenho profissional.`;
    } else {
      category = "development";
      plainSummary = `O resultado observado foi ${percentage} e indica evid\xEAncia parcial neste assessment. Use este sinal para orientar uma conversa e validar a necessidade de desenvolvimento no trabalho real.`;
    }
    return {
      category,
      plainSummary,
      technicalDetail: [
        `Resultado agregado: ${percentage}`,
        `Faixa de evid\xEAncia: ${capability.evidenceLabel}`,
        `Resultados por bloco: ${levelDetails(capability)}`,
        `Vers\xE3o metodol\xF3gica: ${METHODOLOGY_VERSION} (${METHODOLOGY_DATE})`,
        capability.explanation
      ].join("\n")
    };
  }
  function buildIndividualSummary(analysis) {
    const zeroCount = analysis.capabilities.filter((item) => item.aggregatePercentage === 0).length;
    const developmentCount = analysis.counts.develop + analysis.counts.prioritize;
    const dataCount = analysis.counts.investigate_data;
    const frameworkCount = analysis.counts.configure_framework;
    const outsideBookCount = analysis.capabilities.filter(
      (item) => item.applicable === false || item.alignmentStatus === "not_expected_for_role"
    ).length;
    return [
      `Este relat\xF3rio resume os resultados observados em \u201C${analysis.testName}\u201D, conclu\xEDda em ${formatReportDate(analysis.completedAt)}.`,
      `Sinais encontrados: ${countLabel(developmentCount, "capacidade para desenvolver", "capacidades para desenvolver")}; ${countLabel(dataCount, "capacidade para revisar nos dados", "capacidades para revisar nos dados")}; ${countLabel(frameworkCount, "capacidade dependente do framework", "capacidades dependentes do framework")}.`,
      ...zeroCount > 0 ? [`${countLabel(zeroCount, "capacidade possui", "capacidades possuem")} resultado observado de 0%. Zero \xE9 um resultado v\xE1lido e n\xE3o significa dado ausente.`] : [],
      ...outsideBookCount > 0 ? [`${countLabel(outsideBookCount, "capacidade est\xE1", "capacidades est\xE3o")} fora do book profissional atual e ${outsideBookCount === 1 ? "aparece" : "aparecem"} separadamente, sem gerar gap ou recomenda\xE7\xE3o autom\xE1tica.`] : [],
      "Os resultados apoiam conversas de desenvolvimento e n\xE3o determinam desempenho, senioridade, promo\xE7\xE3o ou valor profissional."
    ];
  }
  function buildCollectiveSummary(analysis) {
    const outsideBookCapabilities = analysis.capabilities.filter((item) => item.outsideScopeCount > 0).length;
    return [
      `O recorte re\xFAne ${countLabel(analysis.totalAssessments, "avalia\xE7\xE3o", "avalia\xE7\xF5es")} de ${countLabel(analysis.uniquePeople, "pessoa", "pessoas")}; ${countLabel(analysis.contextualizedAssessments, "avalia\xE7\xE3o possui", "avalia\xE7\xF5es possuem")} contexto profissional completo.`,
      "Os radares mostram os resultados observados no assessment, inclusive fora do book. As m\xE9dias do book, os gaps e as recomenda\xE7\xF5es permanecem limitados ao contexto profissional.",
      "Esses resultados n\xE3o constituem, sozinhos, uma medida validada de maturidade ou desempenho do time.",
      "Nas capacidades, as contagens se referem a avalia\xE7\xF5es. Na lista de pessoas, as contagens se referem a capacidades.",
      "Um resultado de 0% participa das m\xE9dias; um dado ausente n\xE3o participa e deve aparecer como indispon\xEDvel.",
      ...analysis.manualDataDecisionCount > 0 ? [`O recorte cont\xE9m ${countLabel(analysis.manualDataDecisionCount, "decis\xE3o humana registrada sobre dado", "decis\xF5es humanas registradas sobre dados")}; consulte os relat\xF3rios individuais para a trilha completa.`] : [],
      ...outsideBookCapabilities > 0 ? [`${countLabel(outsideBookCapabilities, "capacidade possui", "capacidades possuem")} resultados fora do book de pelo menos uma avalia\xE7\xE3o e ${outsideBookCapabilities === 1 ? "aparece" : "aparecem"} separadamente das leituras de ader\xEAncia.`] : []
    ];
  }

  // src/reports/types.ts
  var DEFAULT_REPORT_COMPOSITION = {
    sections: {
      metrics: true,
      radars: true,
      opportunities: true,
      outsideBook: true,
      recommendations: true,
      developmentPlan: true,
      strengths: true,
      people: true,
      technicalAppendix: false
    },
    privacy: {
      includeFunctionalId: true,
      includeEmail: false
    }
  };

  // src/reports/reportModel.ts
  var INDIVIDUAL_DISCLAIMER = "Este relat\xF3rio apoia conversas de desenvolvimento. Os resultados pertencem ao recorte da avalia\xE7\xE3o e n\xE3o representam, sozinhos, desempenho, senioridade, promo\xE7\xE3o ou decis\xE3o de carreira.";
  var COLLECTIVE_DISCLAIMER = "Este panorama agrega resultados de avalia\xE7\xF5es. N\xE3o mede sozinho a maturidade do time, n\xE3o substitui an\xE1lise contextual e n\xE3o deve ser usado para decis\xF5es autom\xE1ticas sobre pessoas.";
  var COMPARISON_DISCLAIMER = "Esta compara\xE7\xE3o descreve recortes coletivos. Diferen\xE7as n\xE3o representam superioridade, causalidade ou avalia\xE7\xE3o individual e devem ser interpretadas com contexto, cobertura e poss\xEDvel sobreposi\xE7\xE3o entre grupos.";
  function finalize(model) {
    return { ...model, dataHash: checksum(JSON.stringify(model)) };
  }
  function countLabel2(count, singular, plural) {
    return `${count} ${count === 1 ? singular : plural}`;
  }
  function radarsFromIndividual(analysis) {
    return ["hard", "soft"].map((type) => ({
      title: type === "hard" ? "Capacidades t\xE9cnicas" : "Capacidades comportamentais",
      values: analysis.capabilities.filter(
        (item) => item.capabilityType === type && item.applicable !== false && item.alignmentStatus !== "not_expected_for_role"
      ).map((item) => ({
        id: item.capabilityId,
        label: item.capabilityName,
        value: item.aggregatePercentage
      }))
    }));
  }
  function radarsFromCollective(analysis) {
    return ["hard", "soft"].map((type) => ({
      title: type === "hard" ? "Capacidades t\xE9cnicas \u2014 resultados observados" : "Capacidades comportamentais \u2014 resultados observados",
      values: analysis.capabilities.filter((item) => item.capabilityType === type).map((item) => ({
        id: item.capabilityId,
        label: item.capabilityName,
        value: item.observedAveragePercentage
      }))
    }));
  }
  function radarsFromComparison(comparison) {
    const byType = (type) => comparison.capabilities.filter((item) => item.capabilityType === type).sort((left, right) => left.capabilityId.localeCompare(right.capabilityId, "pt-BR", { numeric: true }));
    if (comparison.groups.length === 2) {
      return ["hard", "soft"].map((type) => {
        const capabilities = byType(type);
        const series = comparison.groups.map((group) => ({
          id: group.groupId,
          label: group.groupName,
          values: capabilities.map((item) => {
            const value = item.groupValues.find((candidate) => candidate.groupId === group.groupId);
            return {
              id: item.capabilityId,
              label: item.capabilityName,
              value: value?.observedAveragePercentage ?? null
            };
          })
        }));
        return {
          title: type === "hard" ? "Compara\xE7\xE3o t\xE9cnica \u2014 resultados observados" : "Compara\xE7\xE3o comportamental \u2014 resultados observados",
          values: series[0].values,
          series
        };
      });
    }
    if (comparison.groups.length <= 4) {
      return comparison.groups.flatMap((group) => ["hard", "soft"].map((type) => {
        const values = byType(type).map((item) => {
          const value = item.groupValues.find((candidate) => candidate.groupId === group.groupId);
          return {
            id: item.capabilityId,
            label: item.capabilityName,
            value: value?.observedAveragePercentage ?? null
          };
        });
        return {
          title: `${group.groupName} \xB7 ${type === "hard" ? "Capacidades t\xE9cnicas" : "Capacidades comportamentais"}`,
          values
        };
      }));
    }
    return [];
  }
  function filtersKey(filters) {
    return checksum(JSON.stringify({
      groupId: filters.groupId ?? null,
      query: filters.query ?? null,
      roleId: filters.roleId ?? null,
      specializationId: filters.specializationId ?? null,
      additionalRole: filters.additionalRole ?? null,
      cycle: filters.cycle ?? null
    }));
  }
  function collectiveContext(analysis, groupName) {
    const context = [];
    if (groupName) context.push(`Grupo: ${groupName}`);
    if (analysis.filterLabels.role) context.push(`Cargo: ${analysis.filterLabels.role}`);
    if (analysis.filterLabels.specialization) context.push(`Especializa\xE7\xE3o: ${analysis.filterLabels.specialization}`);
    if (analysis.filterLabels.additionalRole) context.push(`Papel adicional: ${analysis.filterLabels.additionalRole}`);
    if (analysis.filterLabels.cycle) context.push(`Ciclo: ${analysis.filterLabels.cycle}`);
    if (analysis.filterLabels.query) context.push(`Busca aplicada: ${analysis.filterLabels.query}`);
    return context;
  }
  function developmentRecommendations(analysis) {
    const recommendations = /* @__PURE__ */ new Map();
    analysis.opportunities.forEach((capability) => {
      capability.recommendations.forEach((course) => {
        const current = recommendations.get(course.id) ?? { course, capabilities: [] };
        if (!current.capabilities.some((item) => item.id === capability.capabilityId)) {
          current.capabilities.push({ id: capability.capabilityId, name: capability.capabilityName });
        }
        recommendations.set(course.id, current);
      });
    });
    if (recommendations.size === 0) return null;
    return {
      title: "Sugest\xF5es do cat\xE1logo para conversar",
      description: "As sugest\xF5es s\xE3o associa\xE7\xF5es autom\xE1ticas do cat\xE1logo. Valide sua adequa\xE7\xE3o com a pessoa e a lideran\xE7a antes de inclu\xED-las no plano.",
      items: [...recommendations.values()].map(({ course, capabilities }) => ({
        id: capabilities.length > 1 ? `${capabilities[0].id} +${capabilities.length - 1}` : capabilities[0].id,
        title: course.title,
        value: course.level || "N\xEDvel n\xE3o informado",
        detail: [
          `Por que apareceu: o curso est\xE1 relacionado a ${capabilities.map((item) => `${item.id} \xB7 ${item.name}`).join("; ")}.`,
          `Trilha: ${course.trackName || "N\xE3o informada"}`,
          course.objective ? `Objetivo: ${course.objective}` : null,
          course.expectedOutcome ? `Resultado esperado: ${course.expectedOutcome}` : null,
          course.url ? `Link: ${course.url}` : null,
          "Situa\xE7\xE3o: sugest\xE3o autom\xE1tica ainda n\xE3o aceita como a\xE7\xE3o."
        ].filter(Boolean).join("\n")
      }))
    };
  }
  function priorityLabel(priority) {
    if (priority === "high") return "Alta";
    if (priority === "low") return "Baixa";
    return "M\xE9dia";
  }
  function dueDateLabel(value) {
    if (!value) return "Prazo n\xE3o informado";
    const [year, month, day] = value.split("-");
    return year && month && day ? `Prazo: ${day}/${month}/${year}` : `Prazo: ${value}`;
  }
  function manualDataDecisionSection(analysis) {
    const items = analysis.capabilities.flatMap(
      (capability) => capability.levels.flatMap((level) => {
        const resolution = level.manualResolution;
        if (!resolution) return [];
        return [{
          id: `${capability.capabilityId} \xB7 ${level.level}`,
          title: capability.capabilityName,
          value: resolution.decision === "confirmed_zero" ? "Zero confirmado" : "Mantido ausente",
          detail: [
            `Decis\xE3o de ${resolution.decidedBy} em ${formatReportDate(resolution.decidedAt)}.`,
            `Justificativa: ${resolution.reason}`,
            "Origem preservada: o CSV informou N/A; esta interpreta\xE7\xE3o foi aplicada manualmente e pode ser desfeita no plugin."
          ].join("\n")
        }];
      })
    );
    if (items.length === 0) return null;
    return {
      title: "Decis\xF5es humanas sobre os dados",
      description: "Interpreta\xE7\xF5es expl\xEDcitas registradas no plugin. Elas n\xE3o foram inferidas nem aplicadas automaticamente.",
      items
    };
  }
  function buildIndividualReportModel(analysis, options = {}) {
    const composition = options.composition ?? DEFAULT_REPORT_COMPOSITION;
    const metrics = [
      { label: "Resultado geral da avalia\xE7\xE3o", value: formatReportPercentage(analysis.overallPercentage) },
      { label: "M\xE9dia t\xE9cnica do book", value: formatReportPercentage(analysis.hardAveragePercentage) },
      { label: "M\xE9dia comportamental do book", value: formatReportPercentage(analysis.softAveragePercentage) },
      { label: "Capacidades para desenvolver", value: String(analysis.counts.develop + analysis.counts.prioritize) },
      { label: "Capacidades sem dados", value: String(analysis.counts.investigate_data) },
      { label: "Forma de c\xE1lculo", value: analysis.calculationBasis === "weighted_scores" ? "Pontos e m\xE1ximos" : "Percentuais do arquivo" }
    ];
    const narratives = analysis.opportunities.map((capability) => ({ capability, narrative: buildCapabilityNarrative(capability) }));
    const developmentItems = narratives.filter((item) => item.narrative.category === "development");
    const dataItems = narratives.filter((item) => item.narrative.category === "data");
    const frameworkItems = narratives.filter((item) => item.narrative.category === "framework");
    const outsideBook = analysis.capabilities.filter((item) => item.applicable === false || item.alignmentStatus === "not_expected_for_role").map((capability) => ({ capability, narrative: buildCapabilityNarrative(capability) }));
    const recommendationSection = developmentRecommendations(analysis);
    const decisionSection = manualDataDecisionSection(analysis);
    const planActions = (options.developmentActions ?? []).filter(
      (action) => action.personId === analysis.personId && action.status !== "dismissed"
    );
    const sections = [
      ...decisionSection ? [decisionSection] : [],
      ...composition.sections.opportunities && developmentItems.length > 0 ? [{
        title: "Capacidades com sinal de desenvolvimento",
        description: "Sinais observados nesta avalia\xE7\xE3o que devem ser confirmados em conversa e no contexto do trabalho.",
        items: developmentItems.map(({ capability, narrative }) => ({
          id: capability.capabilityId,
          title: capability.capabilityName,
          value: formatReportPercentage(capability.aggregatePercentage),
          detail: narrative.plainSummary
        }))
      }] : [],
      ...composition.sections.opportunities && dataItems.length > 0 ? [{
        title: "Dados que precisam de revis\xE3o",
        description: "Estes itens n\xE3o s\xE3o resultados de 0% e n\xE3o devem orientar desenvolvimento antes da corre\xE7\xE3o dos dados.",
        items: dataItems.map(({ capability, narrative }) => ({
          id: capability.capabilityId,
          title: capability.capabilityName,
          value: "Sem dados",
          detail: narrative.plainSummary
        }))
      }] : [],
      ...composition.sections.opportunities && frameworkItems.length > 0 ? [{
        title: "Configura\xE7\xF5es que precisam de revis\xE3o",
        description: "Pend\xEAncias do framework ou do contexto profissional, n\xE3o da pessoa avaliada.",
        items: frameworkItems.map(({ capability, narrative }) => ({
          id: capability.capabilityId,
          title: capability.capabilityName,
          value: "Framework",
          detail: narrative.plainSummary
        }))
      }] : [],
      ...composition.sections.outsideBook && outsideBook.length > 0 ? [{
        title: "Resultados fora do book profissional",
        description: "O assessment pode registrar capacidades que n\xE3o pertencem ao cargo ou \xE0 especializa\xE7\xE3o atual. Elas ficam vis\xEDveis como contexto, sem compor gaps ou recomenda\xE7\xF5es autom\xE1ticas.",
        items: outsideBook.map(({ capability, narrative }) => ({
          id: capability.capabilityId,
          title: capability.capabilityName,
          value: formatReportPercentage(capability.aggregatePercentage),
          detail: narrative.plainSummary
        }))
      }] : [],
      ...composition.sections.recommendations && recommendationSection ? [recommendationSection] : [],
      ...composition.sections.developmentPlan && planActions.length > 0 ? [{
        title: "Plano de desenvolvimento acordado",
        description: "A\xE7\xF5es aceitas, adaptadas ou criadas por decis\xE3o humana.",
        items: planActions.map((action) => ({
          id: action.capabilityIds.join(" \xB7 "),
          title: action.title,
          value: action.status === "completed" ? "Conclu\xEDda" : action.status === "in_progress" ? "Em andamento" : "Planejada",
          detail: [
            action.description,
            `Respons\xE1vel: ${action.owner || "N\xE3o informado"}`,
            `Prioridade: ${priorityLabel(action.priority)}`,
            dueDateLabel(action.dueDate)
          ].filter(Boolean).join("\n")
        }))
      }] : [],
      ...composition.sections.strengths ? [{
        title: "Resultados relativamente mais altos",
        description: "Os cinco maiores resultados desta avalia\xE7\xE3o. A posi\xE7\xE3o \xE9 relativa ao pr\xF3prio conjunto e n\xE3o confirma uma for\xE7a profissional isoladamente.",
        items: analysis.strengths.slice(0, 5).map((item) => ({
          id: item.capabilityId,
          title: item.capabilityName,
          value: formatReportPercentage(item.aggregatePercentage),
          detail: `Faixa observada na avalia\xE7\xE3o: ${item.evidenceLabel}.`
        }))
      }] : [],
      ...composition.sections.technicalAppendix ? [{
        title: "Ap\xEAndice t\xE9cnico \u2014 todas as capacidades",
        description: "Detalhes audit\xE1veis da avalia\xE7\xE3o. Termos metodol\xF3gicos permanecem aqui para n\xE3o sobrecarregar a leitura principal.",
        items: analysis.capabilities.map((item) => ({
          id: item.capabilityId,
          title: item.capabilityName,
          value: formatReportPercentage(item.aggregatePercentage),
          detail: buildCapabilityNarrative(item).technicalDetail
        }))
      }] : []
    ];
    return finalize({
      templateVersion: 12,
      kind: "individual",
      entityId: analysis.assessmentId,
      pageName: "Skill Mapping \xB7 Pessoas",
      frameName: `Skill Mapping \xB7 ${analysis.personName}`,
      title: analysis.personName,
      subtitle: "Relat\xF3rio individual para conversa de desenvolvimento",
      contextLines: [
        [
          composition.privacy.includeFunctionalId && analysis.personFunctionalId ? `Matr\xEDcula funcional: ${analysis.personFunctionalId}` : "Matr\xEDcula funcional omitida",
          composition.privacy.includeEmail && analysis.personEmail ? analysis.personEmail : "E-mail omitido"
        ].join("  \xB7  "),
        `${analysis.role?.name ?? "Cargo pendente"} \xB7 ${analysis.specialization?.name ?? "Especializa\xE7\xE3o pendente"}`,
        `Avalia\xE7\xE3o: ${analysis.testName} \xB7 Conclus\xE3o: ${formatReportDate(analysis.completedAt)}`,
        [
          analysis.additionalRoles.length > 0 ? `Pap\xE9is adicionais: ${analysis.additionalRoles.join(" \xB7 ")}` : null,
          analysis.cycle ? `Ciclo: ${analysis.cycle}` : null
        ].filter(Boolean).join("  \xB7  ") || "Pap\xE9is adicionais e ciclo n\xE3o informados"
      ],
      summary: buildIndividualSummary(analysis),
      metrics: composition.sections.metrics ? metrics : [],
      radars: composition.sections.radars ? radarsFromIndividual(analysis) : [],
      sections,
      disclaimer: INDIVIDUAL_DISCLAIMER
    });
  }
  function buildCollectiveReportModel(analysis, groupName, composition = DEFAULT_REPORT_COMPOSITION) {
    const hasRecut = Object.values(analysis.filters).some(Boolean);
    const kind = hasRecut ? "group" : "dashboard";
    const label = groupName ?? (hasRecut ? "Recorte coletivo" : "Todo o workspace");
    const metrics = [
      { label: "Avalia\xE7\xF5es no recorte", value: String(analysis.totalAssessments) },
      { label: "Pessoas no recorte", value: String(analysis.uniquePeople) },
      { label: "Avalia\xE7\xF5es com contexto", value: String(analysis.contextualizedAssessments) },
      { label: "Resultado m\xE9dio", value: formatReportPercentage(analysis.averageAssessmentPercentage) },
      { label: "M\xE9dia t\xE9cnica do book", value: formatReportPercentage(analysis.averageHardPercentage) },
      { label: "M\xE9dia comportamental do book", value: formatReportPercentage(analysis.averageSoftPercentage) }
    ];
    const development = analysis.capabilities.filter((item) => item.developingCount > 0);
    const dataReview = analysis.capabilities.filter((item) => item.dataReviewCount > 0);
    const frameworkReview = analysis.capabilities.filter((item) => item.frameworkReviewCount > 0);
    const outsideBook = analysis.capabilities.filter((item) => item.outsideScopeCount > 0);
    const sections = [
      ...composition.sections.opportunities && development.length > 0 ? [{
        title: "Capacidades com sinais de desenvolvimento",
        description: "As contagens abaixo representam avalia\xE7\xF5es, n\xE3o pessoas \xFAnicas.",
        items: development.map((item) => ({
          id: item.capabilityId,
          title: item.capabilityName,
          value: formatReportPercentage(item.averagePercentage),
          detail: `${countLabel2(item.developingCount, "avalia\xE7\xE3o apresentou", "avalia\xE7\xF5es apresentaram")} sinal de desenvolvimento entre ${countLabel2(analysis.totalAssessments, "avalia\xE7\xE3o analisada", "avalia\xE7\xF5es analisadas")}. Dados utiliz\xE1veis em ${item.assessmentCount} de ${analysis.totalAssessments} avalia\xE7\xF5es (${formatReportPercentage(item.dataCoveragePercentage)}).`
        }))
      }] : [],
      ...composition.sections.opportunities && dataReview.length > 0 ? [{
        title: "Dados que precisam de revis\xE3o",
        description: "Aus\xEAncias e inconsist\xEAncias de dados n\xE3o representam resultado de 0%.",
        items: dataReview.map((item) => ({
          id: item.capabilityId,
          title: item.capabilityName,
          value: countLabel2(item.dataReviewCount, "avalia\xE7\xE3o", "avalia\xE7\xF5es"),
          detail: `${countLabel2(item.dataReviewCount, "avalia\xE7\xE3o n\xE3o possui", "avalia\xE7\xF5es n\xE3o possuem")} base suficiente para interpretar esta capacidade, em um recorte de ${analysis.totalAssessments}.`
        }))
      }] : [],
      ...composition.sections.opportunities && frameworkReview.length > 0 ? [{
        title: "Configura\xE7\xF5es que precisam de revis\xE3o",
        description: "Pend\xEAncias de expectativa, aplicabilidade ou contexto; n\xE3o s\xE3o defici\xEAncias das pessoas.",
        items: frameworkReview.map((item) => ({
          id: item.capabilityId,
          title: item.capabilityName,
          value: countLabel2(item.frameworkReviewCount, "avalia\xE7\xE3o", "avalia\xE7\xF5es"),
          detail: `${countLabel2(item.frameworkReviewCount, "avalia\xE7\xE3o depende", "avalia\xE7\xF5es dependem")} de configura\xE7\xE3o antes de uma interpreta\xE7\xE3o de desenvolvimento, em um recorte de ${analysis.totalAssessments}.`
        }))
      }] : [],
      ...composition.sections.outsideBook && outsideBook.length > 0 ? [{
        title: "Resultados fora do book profissional",
        description: "As contagens indicam avalia\xE7\xF5es em que a capacidade estava fora do cargo ou da especializa\xE7\xE3o. Esses resultados ficam separados de gaps e recomenda\xE7\xF5es.",
        items: outsideBook.map((item) => ({
          id: item.capabilityId,
          title: item.capabilityName,
          value: countLabel2(item.outsideScopeCount, "avalia\xE7\xE3o", "avalia\xE7\xF5es"),
          detail: `${countLabel2(item.outsideScopeObservedCount, "avalia\xE7\xE3o preserva", "avalia\xE7\xF5es preservam")} resultado observado fora do book, em um recorte de ${analysis.totalAssessments}.`
        }))
      }] : [],
      ...composition.sections.strengths ? [{
        title: "Resultados relativamente mais altos",
        description: "As cinco maiores m\xE9dias deste recorte; isso n\xE3o constitui ranking de pessoas nem valida uma for\xE7a organizacional isoladamente.",
        items: analysis.strengths.slice(0, 5).map((item) => ({
          id: item.capabilityId,
          title: item.capabilityName,
          value: formatReportPercentage(item.averagePercentage),
          detail: `Dados utiliz\xE1veis em ${item.assessmentCount} de ${analysis.totalAssessments} avalia\xE7\xF5es.`
        }))
      }] : [],
      ...composition.sections.people ? [{
        title: "Pessoas inclu\xEDdas",
        description: "Lista em ordem alfab\xE9tica. As contagens representam capacidades por avalia\xE7\xE3o e n\xE3o formam um ranking.",
        items: [...analysis.people].sort((left, right) => left.personName.localeCompare(right.personName, "pt-BR")).map((item) => ({
          id: item.assessmentId,
          title: item.personName,
          value: formatReportPercentage(item.overallPercentage),
          detail: `${countLabel2(item.developmentCount, "capacidade com sinal", "capacidades com sinal")} de desenvolvimento \xB7 ${countLabel2(item.investigateCount, "capacidade precisa", "capacidades precisam")} de revis\xE3o de dados ou configura\xE7\xE3o.`
        }))
      }] : [],
      ...composition.sections.technicalAppendix ? [{
        title: "Ap\xEAndice t\xE9cnico \u2014 todas as capacidades",
        description: "M\xE9dias observadas, m\xE9dias alinhadas ao book, disponibilidade e contagens completas do recorte.",
        items: analysis.capabilities.map((item) => ({
          id: item.capabilityId,
          title: item.capabilityName,
          value: formatReportPercentage(item.observedAveragePercentage),
          detail: `Resultado observado em ${item.observedAssessmentCount} de ${analysis.totalAssessments} avalia\xE7\xF5es (${formatReportPercentage(item.observedDataCoveragePercentage)}); m\xE9dia observada ${formatReportPercentage(item.observedAveragePercentage)} \xB7 Dados alinhados ao book em ${item.assessmentCount} de ${analysis.totalAssessments} avalia\xE7\xF5es (${formatReportPercentage(item.dataCoveragePercentage)}); m\xE9dia do book ${formatReportPercentage(item.averagePercentage)} \xB7 ${countLabel2(item.developingCount, "sinal", "sinais")} de desenvolvimento \xB7 ${countLabel2(item.dataReviewCount, "revis\xE3o", "revis\xF5es")} de dados \xB7 ${countLabel2(item.frameworkReviewCount, "revis\xE3o", "revis\xF5es")} do framework \xB7 ${countLabel2(item.outsideScopeCount, "resultado fora", "resultados fora")} do book.`
        }))
      }] : []
    ];
    return finalize({
      templateVersion: 12,
      kind,
      entityId: kind === "dashboard" ? "workspace" : `filters-${filtersKey(analysis.filters)}`,
      pageName: kind === "dashboard" ? "Skill Mapping \xB7 Dashboard" : "Skill Mapping \xB7 Grupos",
      frameName: kind === "dashboard" ? "Skill Mapping \xB7 Panorama do time" : `Skill Mapping \xB7 ${label}`,
      title: kind === "dashboard" ? "Panorama dos resultados do time" : label,
      subtitle: kind === "dashboard" ? "Vis\xE3o coletiva das avalia\xE7\xF5es do workspace" : "Vis\xE3o coletiva por grupo ou recorte",
      contextLines: collectiveContext(analysis, groupName),
      summary: buildCollectiveSummary(analysis),
      metrics: composition.sections.metrics ? metrics : [],
      radars: composition.sections.radars ? radarsFromCollective(analysis) : [],
      sections,
      disclaimer: COLLECTIVE_DISCLAIMER
    });
  }
  function rangeLabel(value) {
    if (value === null) return "Sem compara\xE7\xE3o";
    if (value === 0) return "Sem diferen\xE7a";
    return `${value.toFixed(1).replace(".", ",")} p.p. de amplitude`;
  }
  function buildGroupComparisonReportModel(comparison, composition = DEFAULT_REPORT_COMPOSITION) {
    const comparable = comparison.capabilities.filter(
      (item) => item.observedRangePercentagePoints !== null
    );
    const developmentSignals = comparison.capabilities.filter(
      (item) => item.groupValues.some((value) => value.developingCount > 0)
    );
    const groupNames = comparison.groups.map((group) => group.groupName);
    const assessmentEntries = comparison.groups.reduce((total, group) => total + group.totalAssessments, 0);
    const peopleEntries = comparison.groups.reduce((total, group) => total + group.uniquePeople, 0);
    const visualization = comparison.groups.length === 2 ? "Teia sobreposta" : comparison.groups.length <= 4 ? "Pequenas teias" : "Matriz comparativa";
    const comparisonLabel = comparison.groups.length === 2 ? `${groupNames[0]} \xD7 ${groupNames[1]}` : comparison.groups.length <= 4 ? `${comparison.groups.length} grupos \xB7 ${groupNames.join(" \xB7 ")}` : `${comparison.groups.length} grupos \xB7 ${groupNames.slice(0, 2).join(" \xB7 ")} +${comparison.groups.length - 2}`;
    const summary = [
      `A compara\xE7\xE3o re\xFAne ${countLabel2(comparison.groups.length, "grupo", "grupos")}: ${groupNames.join(" \xB7 ")}.`,
      `${countLabel2(peopleEntries, "entrada de pessoa", "entradas de pessoas")} e ${countLabel2(assessmentEntries, "entrada de avalia\xE7\xE3o", "entradas de avalia\xE7\xF5es")} somadas entre os recortes; participantes repetidos permanecem contabilizados em cada grupo.`,
      `${visualization} compara m\xE9dias de resultados observados no assessment. Sinais de desenvolvimento permanecem restritos ao book profissional de cada avalia\xE7\xE3o.`,
      `${countLabel2(comparison.overlaps.length, "par de grupos possui", "pares de grupos possuem")} sobreposi\xE7\xE3o registrada.`,
      ...comparison.warnings
    ];
    const metrics = [
      { label: "Grupos comparados", value: String(comparison.groups.length) },
      { label: "Entradas de pessoas", value: String(peopleEntries) },
      { label: "Entradas de avalia\xE7\xF5es", value: String(assessmentEntries) },
      { label: "Pares sobrepostos", value: String(comparison.overlaps.length) },
      { label: "Capabilities compar\xE1veis", value: String(comparable.length) },
      { label: "Visualiza\xE7\xE3o", value: visualization }
    ];
    const sections = [
      ...comparison.groups.length > 4 && composition.sections.radars ? [{
        title: "Matriz comparativa de resultados observados",
        description: "A matriz substitui a sobreposi\xE7\xE3o de muitas linhas em uma \xFAnica teia. Cada valor informa m\xE9dia e cobertura do grupo.",
        items: comparison.capabilities.map((item) => ({
          id: item.capabilityId,
          title: item.capabilityName,
          value: rangeLabel(item.observedRangePercentagePoints),
          detail: item.groupValues.map(
            (value) => `${value.groupName}: ${formatReportPercentage(value.observedAveragePercentage)} (${value.observedAssessmentCount}/${value.totalAssessments})`
          ).join(" \xB7 ")
        }))
      }] : [],
      ...composition.sections.strengths && comparable.length > 0 ? [{
        title: "Maiores diferen\xE7as observadas",
        description: "Ordena\xE7\xE3o pela amplitude entre a maior e a menor m\xE9dia observada. N\xE3o \xE9 ranking de qualidade nem indica causa.",
        items: comparable.map((item) => ({
          id: item.capabilityId,
          title: item.capabilityName,
          value: rangeLabel(item.observedRangePercentagePoints),
          detail: item.groupValues.map(
            (value) => `${value.groupName}: ${formatReportPercentage(value.observedAveragePercentage)} em ${value.observedAssessmentCount} avalia\xE7\xE3o(\xF5es)`
          ).join(" \xB7 ")
        }))
      }] : [],
      ...composition.sections.opportunities && developmentSignals.length > 0 ? [{
        title: "Sinais de desenvolvimento pelo book",
        description: "Contagens alinhadas ao cargo e \xE0 especializa\xE7\xE3o. A compara\xE7\xE3o n\xE3o transforma diferen\xE7a entre grupos em recomenda\xE7\xE3o autom\xE1tica.",
        items: developmentSignals.map((item) => ({
          id: item.capabilityId,
          title: item.capabilityName,
          value: `${item.groupValues.reduce((total, value) => total + value.developingCount, 0)} sinal(is)`,
          detail: item.groupValues.map(
            (value) => `${value.groupName}: ${value.developingCount} sinal(is); m\xE9dia do book ${formatReportPercentage(value.averagePercentage)}`
          ).join(" \xB7 ")
        }))
      }] : [],
      ...composition.sections.technicalAppendix ? [{
        title: "Ap\xEAndice t\xE9cnico \u2014 compara\xE7\xE3o completa",
        description: "Resultados observados, amplitude e cobertura das vinte capabilities em todos os grupos selecionados.",
        items: comparison.capabilities.map((item) => ({
          id: item.capabilityId,
          title: item.capabilityName,
          value: rangeLabel(item.observedRangePercentagePoints),
          detail: item.groupValues.map(
            (value) => `${value.groupName}: observado ${formatReportPercentage(value.observedAveragePercentage)} (${value.observedAssessmentCount}/${value.totalAssessments}); book ${formatReportPercentage(value.averagePercentage)}`
          ).join(" \xB7 ")
        }))
      }] : []
    ];
    return finalize({
      templateVersion: 12,
      kind: "comparison",
      entityId: `groups-${checksum(JSON.stringify(comparison.groups.map((group) => group.groupId).sort()))}`,
      pageName: "Skill Mapping \xB7 Compara\xE7\xF5es",
      frameName: `Skill Mapping \xB7 ${comparisonLabel}`,
      title: comparison.groups.length === 2 ? comparisonLabel : `Compara\xE7\xE3o de ${comparison.groups.length} grupos`,
      subtitle: "Compara\xE7\xE3o coletiva din\xE2mica de resultados observados",
      contextLines: [`Grupos: ${groupNames.join(" \xB7 ")}`],
      summary,
      metrics: composition.sections.metrics ? metrics : [],
      radars: composition.sections.radars ? radarsFromComparison(comparison) : [],
      sections,
      disclaimer: COMPARISON_DISCLAIMER
    });
  }

  // src/reports/reportInventory.ts
  function buildReportModelForRequest(snapshot, request) {
    if (request.target === "individual") {
      return buildIndividualReportModel(
        buildIndividualAnalysis(snapshot, request.assessmentId),
        {
          composition: request.composition,
          developmentActions: snapshot.developmentActions ?? []
        }
      );
    }
    if (request.target === "comparison") {
      return buildGroupComparisonReportModel(
        "groupIds" in request ? buildMultiGroupComparison(snapshot, request.groupIds) : buildGroupComparison(snapshot, request.leftGroupId, request.rightGroupId),
        request.composition
      );
    }
    return buildCollectiveReportModel(
      buildCollectiveAnalysis(snapshot, request.filters),
      snapshot.groups.find((group) => group.id === request.filters.groupId)?.name,
      request.composition
    );
  }
  function buildReportInventory(snapshot) {
    return (snapshot.reportRecords ?? []).map((record) => {
      if (record.manualEditsPreserved) return { ...record, status: "preserved" };
      try {
        const model = buildReportModelForRequest(snapshot, record.request);
        return {
          ...record,
          status: model.dataHash === record.dataHash ? "current" : "outdated"
        };
      } catch {
        return { ...record, status: "unavailable" };
      }
    }).sort((left, right) => right.generatedAt.localeCompare(left.generatedAt));
  }
  function recordReportGeneration(snapshot, request, model, result, now = /* @__PURE__ */ new Date()) {
    const records = snapshot.reportRecords ?? [];
    const id = `report-${model.kind}-${model.entityId}`;
    const record = {
      id,
      request,
      reportKind: model.kind,
      entityId: model.entityId,
      frameId: result.frameId,
      frameName: result.frameName,
      pageName: result.pageName,
      dataHash: result.dataHash,
      templateVersion: model.templateVersion,
      lastAction: result.action,
      manualEditsPreserved: result.manualEditsDetected,
      generatedAt: now.toISOString()
    };
    return { ...snapshot, reportRecords: [...records.filter((item) => item.id !== id), record] };
  }

  // src/context/assessmentContext.ts
  function toOperationalState(snapshot) {
    if (!snapshot) return null;
    const people = new Map(snapshot.people.map((person) => [person.id, person]));
    const peopleWorkspaceView = buildPeopleWorkspaceView(snapshot);
    return {
      people: peopleWorkspaceView.people,
      dataQuality: peopleWorkspaceView.quality,
      managerialDashboard: buildManagerialDashboard(snapshot, peopleWorkspaceView.quality),
      assessments: snapshot.assessments.map((assessment) => {
        const person = people.get(assessment.personId);
        const context = assessment.context;
        return {
          id: assessment.id,
          personId: assessment.personId,
          personName: person?.name ?? "Pessoa n\xE3o encontrada",
          personSourceName: person?.sourceName ?? null,
          personFunctionalId: person?.functionalId ?? null,
          personEmail: person?.email ?? null,
          testName: assessment.testName,
          percentage: assessment.percentage,
          context: {
            roleId: context ? context.roleId : person?.roleId ?? null,
            specializationId: context ? context.specializationId : person?.specializationId ?? null,
            additionalRoles: readAdditionalRoles(
              context ? context.additionalRoles : person?.additionalRoles,
              context ? context.seniority : person?.seniority
            ),
            cycle: context?.cycle ?? null,
            cycleId: context?.cycleId ?? null
          }
        };
      }),
      roles: (snapshot.framework.roles ?? []).filter((role) => role.expectations.some(
        (expectation) => expectation.referencedLevels.length > 0
      )).map((role) => ({
        id: role.id,
        name: role.name
      })),
      specializations: (snapshot.framework.specializations ?? []).map(
        (specialization) => ({
          id: specialization.id,
          name: specialization.name,
          group: specialization.group
        })
      ),
      groups: snapshot.groups.map((group) => hydrateStoredGroup({
        ...group,
        assessmentIds: group.assessmentIds ?? snapshot.assessments.filter((assessment) => group.personIds.includes(assessment.personId)).map((assessment) => assessment.id)
      })),
      framework: snapshot.framework,
      catalog: snapshot.catalog,
      cycles: summarizeCycles(snapshot),
      developmentActions: snapshot.developmentActions ?? [],
      reportInventory: buildReportInventory(snapshot)
    };
  }
  function applyAssessmentContext(snapshot, input) {
    const assessmentIds = new Set(input.assessmentIds);
    if (assessmentIds.size === 0) {
      throw new Error("Selecione ao menos um assessment para atribuir contexto.");
    }
    const selectedRole = (snapshot.framework.roles ?? []).find(
      (role) => role.id === input.roleId
    );
    if (!selectedRole) {
      throw new Error("O cargo selecionado n\xE3o existe no framework ativo.");
    }
    if (!selectedRole.expectations.some(
      (expectation) => expectation.referencedLevels.length > 0
    )) {
      throw new Error(
        "O cargo selecionado n\xE3o possui expectativas avali\xE1veis com refer\xEAncias N1\u2013N5."
      );
    }
    if (!(snapshot.framework.specializations ?? []).some(
      (specialization) => specialization.id === input.specializationId
    )) {
      throw new Error("A especializa\xE7\xE3o selecionada n\xE3o existe no framework ativo.");
    }
    const availableAssessmentIds = new Set(
      snapshot.assessments.map((assessment) => assessment.id)
    );
    const unknownIds = [...assessmentIds].filter(
      (assessmentId) => !availableAssessmentIds.has(assessmentId)
    );
    if (unknownIds.length > 0) {
      throw new Error(
        `${unknownIds.length} assessment(s) selecionado(s) n\xE3o existem mais no workspace.`
      );
    }
    const affectedPeople = /* @__PURE__ */ new Set();
    const cycleName = input.cycle?.trim() || null;
    const existingCycle = cycleName ? findCycleByName(snapshot, cycleName) : null;
    if (existingCycle?.frameworkSnapshot && (existingCycle.frameworkSnapshot.id !== snapshot.framework.id || existingCycle.frameworkSnapshot.version !== snapshot.framework.version)) {
      throw new Error(
        `O ciclo \u201C${existingCycle.name}\u201D usa ${existingCycle.frameworkSnapshot.name} v${existingCycle.frameworkSnapshot.version}. Crie um novo ciclo para contextualizar com o framework atual v${snapshot.framework.version}.`
      );
    }
    const now = /* @__PURE__ */ new Date();
    const cycleId = cycleName ? existingCycle?.id ?? `cycle-${now.getTime().toString(36)}-${cycleName.normalize("NFD").replace(/[\u0300-\u036f]/gu, "").toLocaleLowerCase("pt-BR").replace(/[^a-z0-9]+/gu, "-").replace(/^-|-$/gu, "")}` : null;
    const assessments = snapshot.assessments.map((assessment) => {
      if (!assessmentIds.has(assessment.id)) return assessment;
      affectedPeople.add(assessment.personId);
      return {
        ...assessment,
        context: {
          roleId: input.roleId,
          specializationId: input.specializationId,
          additionalRoles: normalizeAdditionalRoles(input.additionalRoles),
          seniority: null,
          cycle: cycleName,
          cycleId
        },
        methodologyBasis: {
          frameworkId: snapshot.framework.id,
          frameworkVersion: snapshot.framework.version,
          roleId: input.roleId,
          specializationId: input.specializationId,
          capturedAt: now.toISOString(),
          source: "context_assignment"
        }
      };
    });
    const people = snapshot.people.map(
      (person) => affectedPeople.has(person.id) ? {
        ...person,
        roleId: input.roleId,
        specializationId: input.specializationId,
        additionalRoles: normalizeAdditionalRoles(input.additionalRoles),
        seniority: null
      } : person
    );
    const hydratedCycles = hydrateCycles(snapshot);
    const cycles = cycleName && cycleId ? existingCycle ? hydratedCycles.map((cycle) => cycle.id === existingCycle.id ? { ...cycle, frameworkSnapshot: cycle.frameworkSnapshot ?? snapshot.framework } : cycle) : [...hydratedCycles, {
      id: cycleId,
      name: cycleName,
      status: "active",
      createdAt: now.toISOString(),
      updatedAt: now.toISOString(),
      frameworkSnapshot: snapshot.framework
    }] : hydratedCycles;
    return {
      snapshot: recomputeDynamicGroups({
        ...snapshot,
        people,
        assessments,
        cycles
      }),
      updatedAssessments: assessmentIds.size
    };
  }

  // src/reports/radarGeometry.ts
  function normalizeRadarValue(value) {
    if (value === null || !Number.isFinite(value)) {
      return { state: "missing", ratio: null };
    }
    return {
      state: "observed",
      ratio: Math.max(0, Math.min(100, value)) / 100
    };
  }
  function buildClosedRadarGeometry(points) {
    if (points.length < 3) {
      throw new Error("Um radar precisa de pelo menos tr\xEAs pontos.");
    }
    const x = Math.min(...points.map((point) => point.x));
    const y = Math.min(...points.map((point) => point.y));
    const vertices = points.map((point) => ({
      x: point.x - x,
      y: point.y - y
    }));
    const segments = vertices.map((_, index) => ({
      start: index,
      end: (index + 1) % vertices.length
    }));
    return {
      x,
      y,
      vertices,
      segments,
      loop: segments.map((_, index) => index)
    };
  }
  function buildObservedRadarGeometry(points) {
    if (points.length < 2) {
      throw new Error("Um radar parcial precisa de pelo menos dois pontos.");
    }
    const x = Math.min(...points.map((point) => point.x));
    const y = Math.min(...points.map((point) => point.y));
    const vertices = points.map((point) => ({
      x: point.x - x,
      y: point.y - y
    }));
    const segments = points.flatMap((point, index) => {
      const nextIndex = (index + 1) % points.length;
      return point.state === "observed" && points[nextIndex].state === "observed" ? [{ start: index, end: nextIndex }] : [];
    });
    return { x, y, vertices, segments };
  }

  // src/reports/reportLayout.ts
  function buildRankingRowGeometry(rowY, titleHeight, detailHeight) {
    const titleY = rowY + 14;
    const detailY = titleY + titleHeight + 8;
    const contentBottom = detailY + detailHeight;
    return {
      titleY,
      detailY,
      height: Math.max(72, Math.ceil(contentBottom - rowY + 18))
    };
  }

  // src/reports/updatePolicy.ts
  function decideReportUpdate(existing, nextDataHash, strategy) {
    if (!existing) {
      return {
        action: "created",
        manualEditsDetected: false,
        reuseExistingFrame: false,
        renderRequired: true
      };
    }
    const manualEditsDetected = Boolean(
      existing.storedRenderHash && existing.currentRenderHash !== existing.storedRenderHash
    );
    if (strategy === "safe-update" && existing.dataHash === nextDataHash) {
      return {
        action: "unchanged",
        manualEditsDetected,
        reuseExistingFrame: true,
        renderRequired: false
      };
    }
    if (strategy === "duplicate") {
      return {
        action: "duplicated",
        manualEditsDetected,
        reuseExistingFrame: false,
        renderRequired: true
      };
    }
    if (manualEditsDetected) {
      return {
        action: "duplicated-to-preserve-edits",
        manualEditsDetected: true,
        reuseExistingFrame: false,
        renderRequired: true
      };
    }
    return {
      action: "updated",
      manualEditsDetected: false,
      reuseExistingFrame: true,
      renderRequired: true
    };
  }

  // src/reports/canvasRenderer.ts
  var META_PREFIX = "skill-mapping:report:";
  var FRAME_WIDTH = 1440;
  var CONTENT_WIDTH = 1312;
  var COLORS = {
    canvas: { r: 0.965, g: 0.973, b: 0.988 },
    surface: { r: 1, g: 1, b: 1 },
    border: { r: 0.855, g: 0.875, b: 0.91 },
    text: { r: 0.075, g: 0.09, b: 0.13 },
    secondary: { r: 0.34, g: 0.38, b: 0.47 },
    brand: { r: 0.055, g: 0.345, b: 0.82 },
    comparison: { r: 0.86, g: 0.32, b: 0.08 },
    brandSoft: { r: 0.89, g: 0.93, b: 1 },
    positive: { r: 0.05, g: 0.51, b: 0.29 }
  };
  var FONT_REGULAR = { family: "Inter", style: "Regular" };
  var FONT_MEDIUM = { family: "Inter", style: "Medium" };
  var FONT_BOLD = { family: "Inter", style: "Bold" };
  function solid(color, opacity = 1) {
    return { type: "SOLID", color, opacity };
  }
  function addText(parent, text, x, y, width, options = {}) {
    const node = figma.createText();
    node.name = options.name ?? "Texto";
    node.fontName = options.font ?? FONT_REGULAR;
    node.fontSize = options.size ?? 16;
    node.fills = [solid(options.color ?? COLORS.text)];
    node.lineHeight = { unit: "PIXELS", value: options.lineHeight ?? (options.size ?? 16) * 1.4 };
    node.characters = text;
    node.textAutoResize = "HEIGHT";
    node.resize(width, Math.max(1, node.height));
    node.x = x;
    node.y = y;
    parent.appendChild(node);
    return node;
  }
  function addCard(parent, name, x, y, width, height) {
    const card = figma.createFrame();
    card.name = name;
    card.resize(width, height);
    card.x = x;
    card.y = y;
    card.cornerRadius = 16;
    card.fills = [solid(COLORS.surface)];
    card.strokes = [solid(COLORS.border)];
    card.strokeWeight = 1;
    card.clipsContent = false;
    parent.appendChild(card);
    return card;
  }
  function addLine(parent, x1, y1, x2, y2, color, weight = 1, opacity = 1) {
    const line = figma.createLine();
    const dx = x2 - x1;
    const dy = y2 - y1;
    line.resize(Math.max(0.01, Math.hypot(dx, dy)), 0);
    line.x = x1;
    line.y = y1;
    line.rotation = Math.atan2(dy, dx) * 180 / Math.PI;
    line.strokes = [solid(color, opacity)];
    line.strokeWeight = weight;
    parent.appendChild(line);
    return line;
  }
  async function addRadar(parent, radar, x, y) {
    const { title, values } = radar;
    const series = radar.series?.length ? radar.series.slice(0, 2) : [{ id: "observed", label: "Resultado observado", values }];
    const seriesColors = [COLORS.brand, COLORS.comparison];
    const width = 640;
    const height = 500;
    const card = addCard(parent, `Radar \xB7 ${title}`, x, y, width, height);
    addText(card, title, 24, 22, width - 48, { size: 18, font: FONT_BOLD });
    if (values.length < 3) {
      addText(card, "Dados insuficientes para o radar.", 24, 84, width - 48, {
        size: 14,
        color: COLORS.secondary
      });
      return;
    }
    const centerX = width / 2;
    const centerY = 273;
    const radius = 160;
    for (const ratio of [0.25, 0.5, 0.75, 1]) {
      const ring = figma.createEllipse();
      ring.name = `Refer\xEAncia ${ratio * 100}%`;
      ring.resize(radius * ratio * 2, radius * ratio * 2);
      ring.x = centerX - radius * ratio;
      ring.y = centerY - radius * ratio;
      ring.fills = [];
      ring.strokes = [solid(COLORS.border)];
      ring.strokeWeight = 1;
      card.appendChild(ring);
    }
    values.forEach((item, index) => {
      const angle = -Math.PI / 2 + index * Math.PI * 2 / values.length;
      const outerX = centerX + Math.cos(angle) * radius;
      const outerY = centerY + Math.sin(angle) * radius;
      addLine(card, centerX, centerY, outerX, outerY, COLORS.border);
      const labelX = centerX + Math.cos(angle) * (radius + 25) - 28;
      const labelY = centerY + Math.sin(angle) * (radius + 25) - 8;
      addText(card, item.id, labelX, labelY, 56, {
        size: 11,
        font: FONT_BOLD,
        color: COLORS.secondary,
        lineHeight: 14,
        name: `${item.id} \xB7 ${item.label}`
      });
    });
    for (const [seriesIndex, currentSeries] of series.entries()) {
      const color = seriesColors[seriesIndex] ?? COLORS.brand;
      const valuesById = new Map(currentSeries.values.map((item) => [item.id, item]));
      const dataPoints = values.map((item, index) => {
        const angle = -Math.PI / 2 + index * Math.PI * 2 / values.length;
        const normalized = normalizeRadarValue(valuesById.get(item.id)?.value ?? null);
        const ratio = normalized.ratio ?? 1;
        return {
          x: centerX + Math.cos(angle) * radius * ratio,
          y: centerY + Math.sin(angle) * radius * ratio,
          id: item.id,
          state: normalized.state
        };
      });
      if (dataPoints.every((point) => point.state === "observed")) {
        const geometry = buildClosedRadarGeometry(dataPoints);
        const dataShape = figma.createVector();
        dataShape.name = `${currentSeries.label} \xB7 ${title}`;
        await dataShape.setVectorNetworkAsync({
          vertices: geometry.vertices,
          segments: geometry.segments,
          regions: [{
            windingRule: "NONZERO",
            loops: [geometry.loop]
          }]
        });
        dataShape.x = geometry.x;
        dataShape.y = geometry.y;
        dataShape.fills = [solid(color, series.length > 1 ? 0.08 : 0.12)];
        dataShape.strokes = [solid(color)];
        dataShape.strokeWeight = 3;
        dataShape.strokeJoin = "ROUND";
        card.appendChild(dataShape);
      } else {
        const geometry = buildObservedRadarGeometry(dataPoints);
        if (geometry.segments.length > 0) {
          const dataShape = figma.createVector();
          dataShape.name = `Resultados dispon\xEDveis \xB7 ${currentSeries.label} \xB7 ${title}`;
          await dataShape.setVectorNetworkAsync({
            vertices: geometry.vertices,
            segments: geometry.segments
          });
          dataShape.x = geometry.x;
          dataShape.y = geometry.y;
          dataShape.fills = [];
          dataShape.strokes = [solid(color)];
          dataShape.strokeWeight = 3;
          dataShape.strokeJoin = "ROUND";
          card.appendChild(dataShape);
        }
      }
      dataPoints.forEach((point) => {
        const dot = figma.createEllipse();
        dot.name = point.state === "observed" ? `${currentSeries.label} \xB7 ${point.id}` : `Sem dados \xB7 ${currentSeries.label} \xB7 ${point.id}`;
        dot.resize(point.state === "observed" ? 8 : 12, point.state === "observed" ? 8 : 12);
        dot.x = point.x - dot.width / 2;
        dot.y = point.y - dot.height / 2;
        dot.fills = point.state === "observed" ? [solid(color)] : [];
        if (point.state === "missing") {
          dot.strokes = [solid(color)];
          dot.strokeWeight = 2;
        }
        card.appendChild(dot);
      });
      addText(card, `\u25CF ${currentSeries.label}`, 24 + seriesIndex * 260, height - 32, 240, {
        size: 10,
        color,
        lineHeight: 12
      });
    }
    addText(card, "\u25CB sem dados", width - 112, height - 32, 88, {
      size: 10,
      color: COLORS.secondary,
      lineHeight: 12
    });
  }
  function addSection(parent, section, y) {
    const card = addCard(parent, section.title, 64, y, CONTENT_WIDTH, 160);
    addText(card, section.title, 24, 22, CONTENT_WIDTH - 48, { size: 20, font: FONT_BOLD });
    let rowY = 68;
    if (section.description) {
      const description = addText(card, section.description, 24, 54, CONTENT_WIDTH - 48, {
        size: 13,
        color: COLORS.secondary
      });
      rowY = Math.max(92, description.y + description.height + 20);
    }
    if (section.items.length === 0) {
      addText(card, "Nenhum resultado dispon\xEDvel neste recorte.", 24, rowY + 14, CONTENT_WIDTH - 48, {
        size: 14,
        color: COLORS.secondary
      });
      rowY += 80;
    }
    section.items.forEach((item) => {
      addLine(card, 24, rowY, CONTENT_WIDTH - 24, rowY, COLORS.border);
      addText(card, item.id, 24, rowY + 17, 90, { size: 13, font: FONT_BOLD, color: COLORS.brand });
      const title = addText(card, item.title, 124, rowY + 14, 930, { size: 15, font: FONT_BOLD });
      const detail = addText(card, item.detail, 124, 0, 930, { size: 12, color: COLORS.secondary, lineHeight: 18 });
      const row = buildRankingRowGeometry(rowY, title.height, detail.height);
      title.y = row.titleY;
      detail.y = row.detailY;
      addText(card, item.value, CONTENT_WIDTH - 174, rowY + 14, 150, { size: 17, font: FONT_BOLD, color: COLORS.positive });
      rowY += row.height;
    });
    const height = rowY + 24;
    card.resize(CONTENT_WIDTH, height);
    return height;
  }
  async function renderModel(frame, model) {
    frame.name = model.frameName;
    frame.resize(FRAME_WIDTH, 1200);
    frame.fills = [solid(COLORS.canvas)];
    frame.clipsContent = false;
    addText(frame, "SKILL MAPPING", 64, 54, CONTENT_WIDTH, { size: 13, font: FONT_BOLD, color: COLORS.brand });
    addText(frame, model.title, 64, 86, CONTENT_WIDTH, { size: 40, font: FONT_BOLD, lineHeight: 48 });
    addText(frame, model.subtitle, 64, 142, CONTENT_WIDTH, { size: 18, color: COLORS.secondary });
    let y = 192;
    if (model.contextLines.length > 0) {
      const context = addText(frame, model.contextLines.join("  \xB7  "), 64, y, CONTENT_WIDTH, { size: 13, color: COLORS.secondary });
      y += context.height + 24;
    }
    if (model.summary.length > 0) {
      const summaryCard = addCard(frame, "Como ler este relat\xF3rio", 64, y, CONTENT_WIDTH, 140);
      addText(summaryCard, "Como ler este relat\xF3rio", 20, 16, CONTENT_WIDTH - 40, {
        size: 14,
        font: FONT_BOLD,
        color: COLORS.brand
      });
      const summary = addText(
        summaryCard,
        model.summary.map((item) => `\u2022 ${item}`).join("\n"),
        20,
        46,
        CONTENT_WIDTH - 40,
        { size: 13, color: COLORS.secondary, lineHeight: 20 }
      );
      const summaryHeight = summary.y + summary.height + 20;
      summaryCard.resize(CONTENT_WIDTH, summaryHeight);
      y += summaryHeight + 24;
    }
    if (model.metrics.length > 0) {
      const visibleMetrics = model.metrics.slice(0, 6);
      const metricWidth = (CONTENT_WIDTH - (visibleMetrics.length - 1) * 16) / visibleMetrics.length;
      visibleMetrics.forEach((metric, index) => {
        const card = addCard(frame, `M\xE9trica \xB7 ${metric.label}`, 64 + index * (metricWidth + 16), y, metricWidth, 128);
        const label = addText(card, metric.label, 16, 16, metricWidth - 32, { size: 11, font: FONT_MEDIUM, color: COLORS.secondary });
        addText(card, metric.value, 16, Math.max(52, label.y + label.height + 10), metricWidth - 32, { size: 23, font: FONT_BOLD });
      });
      y += 160;
    }
    if (model.radars.length > 0) {
      for (const [index, radar] of model.radars.entries()) {
        const column = index % 2;
        const row = Math.floor(index / 2);
        await addRadar(frame, radar, 64 + column * 672, y + row * 532);
      }
      y += Math.ceil(model.radars.length / 2) * 532;
    }
    model.sections.forEach((section) => {
      y += addSection(frame, section, y) + 24;
    });
    const disclaimer = addCard(frame, "Nota de uso", 64, y, CONTENT_WIDTH, 92);
    addText(disclaimer, "Como interpretar", 20, 16, CONTENT_WIDTH - 40, { size: 13, font: FONT_BOLD, color: COLORS.brand });
    const disclaimerText = addText(disclaimer, model.disclaimer, 20, 43, CONTENT_WIDTH - 40, { size: 12, color: COLORS.secondary, lineHeight: 18 });
    const disclaimerHeight = disclaimerText.y + disclaimerText.height + 20;
    disclaimer.resize(CONTENT_WIDTH, disclaimerHeight);
    y += disclaimerHeight + 40;
    frame.resize(FRAME_WIDTH, Math.max(1200, y));
  }
  function serializablePaints(node, property) {
    if (property === "fills") {
      if (!("fills" in node)) return null;
      return node.fills === figma.mixed ? "mixed" : node.fills;
    }
    if (!("strokes" in node)) return null;
    return node.strokes;
  }
  function nodeSignature(node, includePosition = true) {
    return {
      type: node.type,
      name: node.name,
      x: includePosition ? node.x : void 0,
      y: includePosition ? node.y : void 0,
      width: node.width,
      height: node.height,
      rotation: "rotation" in node ? node.rotation : void 0,
      opacity: "opacity" in node ? node.opacity : void 0,
      visible: node.visible,
      characters: node.type === "TEXT" ? node.characters : void 0,
      fills: serializablePaints(node, "fills"),
      strokes: serializablePaints(node, "strokes"),
      children: "children" in node ? node.children.map((child) => nodeSignature(child, true)) : void 0
    };
  }
  function renderedContentHash(frame) {
    return checksum(JSON.stringify(nodeSignature(frame, false)));
  }
  async function findOrCreatePage(name) {
    await figma.loadAllPagesAsync();
    const existing = figma.root.children.find((page2) => page2.name === name);
    if (existing) return existing;
    const page = figma.createPage();
    page.name = name;
    return page;
  }
  function findExistingFrame(page, model) {
    const candidates = page.children.filter(
      (node) => node.type === "FRAME" && node.getPluginData(`${META_PREFIX}kind`) === model.kind && node.getPluginData(`${META_PREFIX}entity-id`) === model.entityId
    );
    return candidates.find((node) => node.getPluginData(`${META_PREFIX}canonical`) === "true") ?? candidates.find((node) => node.getPluginData(`${META_PREFIX}canonical`) !== "false") ?? null;
  }
  function nextFrameX(page) {
    return page.children.reduce((right, node) => Math.max(right, node.x + node.width), -160) + 160;
  }
  function stampFrame(frame, model, canonical) {
    frame.setPluginData(`${META_PREFIX}kind`, model.kind);
    frame.setPluginData(`${META_PREFIX}entity-id`, model.entityId);
    frame.setPluginData(`${META_PREFIX}template-version`, String(model.templateVersion));
    frame.setPluginData(`${META_PREFIX}data-hash`, model.dataHash);
    frame.setPluginData(`${META_PREFIX}generated-at`, (/* @__PURE__ */ new Date()).toISOString());
    frame.setPluginData(`${META_PREFIX}canonical`, String(canonical));
    frame.setPluginData(`${META_PREFIX}render-hash`, renderedContentHash(frame));
  }
  async function renderReportToCanvas(model, strategy) {
    await Promise.all([
      figma.loadFontAsync(FONT_REGULAR),
      figma.loadFontAsync(FONT_MEDIUM),
      figma.loadFontAsync(FONT_BOLD)
    ]);
    const page = await findOrCreatePage(model.pageName);
    await figma.setCurrentPageAsync(page);
    const existing = findExistingFrame(page, model);
    const decision = decideReportUpdate(
      existing ? {
        dataHash: existing.getPluginData(`${META_PREFIX}data-hash`),
        storedRenderHash: existing.getPluginData(`${META_PREFIX}render-hash`),
        currentRenderHash: renderedContentHash(existing)
      } : null,
      model.dataHash,
      strategy
    );
    if (existing && !decision.renderRequired) {
      figma.currentPage.selection = [existing];
      figma.viewport.scrollAndZoomIntoView([existing]);
      return {
        action: decision.action,
        pageName: page.name,
        frameId: existing.id,
        frameName: existing.name,
        reportKind: model.kind,
        manualEditsDetected: decision.manualEditsDetected,
        dataHash: model.dataHash
      };
    }
    const newFrameX = nextFrameX(page);
    const frame = existing && decision.reuseExistingFrame ? existing : figma.createFrame();
    if (!existing || !decision.reuseExistingFrame) {
      frame.x = newFrameX;
      frame.y = 0;
      page.appendChild(frame);
    } else {
      [...frame.children].forEach((child) => child.remove());
    }
    await renderModel(frame, model);
    if (existing && decision.action === "duplicated-to-preserve-edits") {
      existing.setPluginData(`${META_PREFIX}canonical`, "false");
    }
    stampFrame(frame, model, decision.action !== "duplicated");
    figma.currentPage.selection = [frame];
    figma.viewport.scrollAndZoomIntoView([frame]);
    return {
      action: decision.action,
      pageName: page.name,
      frameId: frame.id,
      frameName: frame.name,
      reportKind: model.kind,
      manualEditsDetected: decision.manualEditsDetected,
      dataHash: model.dataHash
    };
  }

  // raw-text:/Users/renatosilvestre/Desktop/Report_Skill/Skill Mapping/src/data/capabilities.csv
  var capabilities_default = 'Descritivo Psicom\xE9trico das Capabilities \u2014 Framework de Design Bradesco;;;;;;;;;\r\n"Este documento detalha a justificativa psicom\xE9trica, defini\xE7\xE3o operacional e crit\xE9rios comportamentais de cada capability utilizada no diagn\xF3stico de Product Designers. O framework \xE9 baseado em taxonomias de compet\xEAncias profissionais (Spencer & Spencer, 1993; Campion et al., 2011) e adaptado ao contexto de design digital em institui\xE7\xE3o financeira.";;;;;;;;;\r\n;;;;;;;;;\r\n#;ID;Nome da Capability;Defini\xE7\xE3o Operacional;Objetivo Diagn\xF3stico;Justificativa Psicom\xE9trica;Construto Avaliado;Comportamentos Observ\xE1veis (\xE2ncoras);Escala de Progress\xE3o (1\u21925);Conex\xE3o Carreira Bradesco\r\nHARD SKILLS \u2014 Compet\xEAncias T\xE9cnicas de Design (H1\u2013H10);;;;;;;;;\r\n1;H1;Discovery e framing de problema;Capacidade de investigar contextos de uso, identificar problemas reais, formular hip\xF3teses e estruturar problem statements que orientem o trabalho de design. Inclui conhecimento de t\xE9cnicas de discovery, an\xE1lise de dados e s\xEDntese em artefatos acion\xE1veis (jobs-to-be-done, opportunity maps, problem briefs).;Medir a profici\xEAncia do designer em transformar ambiguidade em clareza. Designers que dominam discovery evitam o risco de resolver o problema errado \u2014 um dos maiores desperd\xEDcios em produto digital. \xC9 o ponto de partida da cadeia de valor do design.;"Baseado no construto de ""problem structuring"" (Jonassen, 2000) e na compet\xEAncia de ""inquiry-based reasoning"" (Kolb, 1984). Mapeia a capacidade anal\xEDtica-explorat\xF3ria que diferencia designers operacionais de designers estrat\xE9gicos. A escala progressiva mede autonomia, profundidade e impacto do framing na tomada de decis\xE3o do time.";"Pensamento anal\xEDtico-explorat\xF3rio; Racioc\xEDnio abdutivo; Resolu\xE7\xE3o de problemas complexos";N\xEDvel 1: Observa e documenta sess\xF5es de discovery com apoio. N\xEDvel 3: Conduz discovery com autonomia, formula hip\xF3teses e conecta achados a decis\xF5es. N\xEDvel 5: Orquestra discovery cross-squad, define frameworks de investiga\xE7\xE3o e influencia roadmap.;1 \u2014 Observa e aprende m\xE9todos | 2 \u2014 Participa e formula hip\xF3teses | 3 \u2014 Conduz com autonomia e estrutura achados | 4 \u2014 Lidera discovery complexo e sist\xEAmico | 5 \u2014 Define m\xE9todo organizacional de discovery;Diferenciador cr\xEDtico entre J\xFAnior (executa partes) e S\xEAnior+ (conduz ponta a ponta). Especialistas definem m\xE9todo e influenciam estrat\xE9gia de produto.\r\n2;H2;Estrat\xE9gia de experi\xEAncia e fluxos;Capacidade de desenhar, manter e evoluir fluxos de experi\xEAncia end-to-end, garantindo coer\xEAncia entre touchpoints, consist\xEAncia de jornada, antecipa\xE7\xE3o de edge cases e defini\xE7\xE3o dos recortes de MVP e evolu\xE7\xF5es. Inclui arquitetura de informa\xE7\xE3o, service blueprints e journey maps.;Avaliar a capacidade de pensar sistemicamente sobre experi\xEAncia, al\xE9m da tela individual. Designers com forte vis\xE3o de fluxos reduzem fric\xE7\xE3o, retrabalho e inconsist\xEAncias que impactam m\xE9tricas de convers\xE3o e satisfa\xE7\xE3o em produtos financeiros.;"Alinhado ao construto de ""systems thinking"" (Senge, 1990) aplicado a design. Mede a capacidade de operar em m\xFAltiplos n\xEDveis de abstra\xE7\xE3o simultaneamente \u2014 do componente ao ecossistema. Correlaciona-se com maturidade de design (Nielsen Norman Group, 2006).";"Pensamento sist\xEAmico; Arquitetura de experi\xEAncia; Vis\xE3o hol\xEDstica de produto";N\xEDvel 1: Apoia mapeamento e organiza\xE7\xE3o de fluxos com supervis\xE3o. N\xEDvel 3: Desenha fluxos ponta a ponta com edge cases. N\xEDvel 5: Define estrat\xE9gia de experi\xEAncia cross-produto com governan\xE7a.;1 \u2014 Apoia mapeamento com supervis\xE3o | 2 \u2014 Desenha partes do fluxo | 3 \u2014 Fluxos ponta a ponta com edge cases | 4 \u2014 Estrat\xE9gia multi-fluxo e multi-canal | 5 \u2014 Governan\xE7a de experi\xEAncia organizacional;Plenos ganham autonomia em fluxos de m\xE9dia complexidade. Seniores e acima definem estrat\xE9gias de experi\xEAncia que cruzam squads e canais.\r\n3;H3;UI e craft (qualidade visual e intera\xE7\xE3o);Dom\xEDnio da qualidade visual e de intera\xE7\xE3o \u2014 grid, hierarquia tipogr\xE1fica, sistema de cores, motion design, micro-intera\xE7\xF5es e polimento final de interface. Inclui precis\xE3o de design, aten\xE7\xE3o ao detalhe e capacidade de elevar a barra de craft.;Medir a excel\xEAncia de execu\xE7\xE3o visual que impacta diretamente a percep\xE7\xE3o de qualidade e confian\xE7a do usu\xE1rio \u2014 especialmente cr\xEDtico em produtos banc\xE1rios onde confian\xE7a visual \xE9 proxy de seguran\xE7a. Craft distingue produtos bons de excelentes.;"Baseado na teoria da est\xE9tica computacional e na rela\xE7\xE3o documentada entre qualidade visual percebida e confian\xE7a do usu\xE1rio (Tractinsky et al., 2000; Lindgaard et al., 2006). Em contexto banc\xE1rio, a qualidade visual funciona como heur\xEDstica de credibilidade. A escala mede precis\xE3o, consist\xEAncia e capacidade de elevar padr\xE3o.";"Compet\xEAncia t\xE9cnico-visual; Aten\xE7\xE3o ao detalhe; Sensibilidade est\xE9tica aplicada";N\xEDvel 1: Ajustes simples de UI com orienta\xE7\xE3o. N\xEDvel 3: Entrega UI com refinamento e consist\xEAncia sist\xEAmica. N\xEDvel 5: Define e governa padr\xE3o visual da organiza\xE7\xE3o.;1 \u2014 Ajustes simples com orienta\xE7\xE3o | 2 \u2014 UI em escopo definido com revis\xE3o | 3 \u2014 Craft consistente e aut\xF4nomo | 4 \u2014 Refer\xEAncia de craft e mentoria visual | 5 \u2014 Define padr\xE3o visual organizacional;Skill t\xE9cnico diferenciador na trilha IC (Especialista). Excel\xEAncia em craft \xE9 requisito para elevar barra do time e ganhar influ\xEAncia t\xE9cnica.\r\n4;H4;UX Writing e conte\xFAdo de interface;Capacidade de escrever textos de interface claros, \xFAteis e consistentes \u2014 microcopy, textos conversacionais, mensagens de erro, textos de onboarding, tooltips, CTAs e tom de voz. Inclui governan\xE7a de linguagem e padr\xF5es de escrita escal\xE1veis garantindo consist\xEAncia de linguagem.;Medir a compet\xEAncia de comunica\xE7\xE3o textual que impacta diretamente usabilidade, compreens\xE3o e confian\xE7a. Em produtos financeiros, um texto amb\xEDguo pode gerar erro transacional, perda financeira ou quebra de conformidade regulat\xF3ria.;"Baseado em pesquisas de legibilidade e compreens\xE3o (Flesch, 1948; Plain Language standards) e na evid\xEAncia de que microcopy \xE9 o fator de usabilidade com maior impacto em taxas de conclus\xE3o de tarefas (Redish, 2012). Mede clareza, consist\xEAncia e governan\xE7a textual.";"Comunica\xE7\xE3o escrita funcional; Clareza instrucional; Governan\xE7a de linguagem";N\xEDvel 1: Aprende conceitos b\xE1sicos de microcopy com apoio. N\xEDvel 3: Garante consist\xEAncia de linguagem em fluxos ponta a ponta. N\xEDvel 5: Define padr\xE3o de voz e tom organizacional com governan\xE7a.;1 \u2014 Aprende microcopy b\xE1sico | 2 \u2014 Escreve textos simples com revis\xE3o | 3 \u2014 Consist\xEAncia em fluxos completos | 4 \u2014 Refer\xEAncia de writing no time | 5 \u2014 Governan\xE7a de linguagem organizacional;"Habilidade transversal que matura com senioridade. Seniores integram writing ao craft; Especialistas definem padr\xF5es de voz e tom."\r\n5;H5;Valida\xE7\xE3o para decis\xE3o;Capacidade de transformar hip\xF3teses em artefatos test\xE1veis (prot\xF3tipo naveg\xE1vel) e usar valida\xE7\xE3o (testes de usabilidade, A/B tests, concept tests) para reduzir risco e informar decis\xF5es de produto. Inclui escolha de fidelidade adequada ao objetivo.;Medir a capacidade de reduzir incerteza antes de investir em desenvolvimento. Prototipar bem \xE9 prototipar o suficiente \u2014 nem mais, nem menos. Validar \xE9 gerar evid\xEAncia que muda a dire\xE7\xE3o ou confirma a aposta.;"Baseado no ciclo build-measure-learn (Ries, 2011) e na teoria de ""inquiry through making"" (Sch\xF6n, 1983). Mede a capacidade de converter ambiguidade em aprendizado acion\xE1vel. A escala progressiva vai de participa\xE7\xE3o assistida a desenho de programa de valida\xE7\xE3o.";"Experimenta\xE7\xE3o controlada; Valida\xE7\xE3o emp\xEDrica; Aprendizado iterativo";N\xEDvel 1: Apoia prepara\xE7\xE3o de prot\xF3tipos e observa testes. N\xEDvel 3: Prototipa e valida com m\xE9todo s\xF3lido. Interpreta resultados. N\xEDvel 5: Define programa de valida\xE7\xE3o e cultura de experimenta\xE7\xE3o.;1 \u2014 Apoia e observa | 2 \u2014 Prototipa partes simples | 3 \u2014 Valida com m\xE9todo e interpreta | 4 \u2014 Desenha programas de valida\xE7\xE3o | 5 \u2014 Cultura de experimenta\xE7\xE3o organizacional;"Juniores aprendem o m\xE9todo; Plenos executam com autonomia; Seniores definem o que e como validar; Principals criam frameworks de valida\xE7\xE3o."\r\n6;H6;Design System e escalabilidade;Capacidade de usar, contribuir e governar o Design System \u2014 componentes, tokens, patterns, documenta\xE7\xE3o e processos de ado\xE7\xE3o. Inclui pensamento de escalabilidade, cria\xE7\xE3o de team componentes e reutiliza\xE7\xE3o para garantir consist\xEAncia cross-produto.;"Medir a capacidade de operar dentro de um sistema de design e contribuir para sua evolu\xE7\xE3o. Design System \xE9 infraestrutura de qualidade \u2014 designers que o ignoram geram d\xE9bito de consist\xEAncia; designers que o dominam multiplicam impacto.";"Baseado na teoria de ""design infrastructure"" (Star & Ruhleder, 1996) e em evid\xEAncias de que sistemas de design reduzem tempo de entrega em 30-50% quando bem adotados (Sparkbox Design Systems Survey, 2022). Mede uso, contribui\xE7\xE3o e governan\xE7a.";"Pensamento sist\xEAmico; Escalabilidade; Governan\xE7a t\xE9cnica de design";N\xEDvel 1: Aplica componentes com orienta\xE7\xE3o direta. N\xEDvel 3: Contribui ativamente com sugest\xF5es replic\xE1veis. N\xEDvel 5: Governa o Design System e define roadmap de evolu\xE7\xE3o.;1 \u2014 Usa com orienta\xE7\xE3o | 2 \u2014 Usa com consist\xEAncia | 3 \u2014 Contribui com padr\xF5es | 4 \u2014 Refer\xEAncia e mentoria | 5 \u2014 Governan\xE7a organizacional do DS;Skill t\xE9cnico estrat\xE9gico para a trilha IC. Especialistas s\xE3o refer\xEAncia de DS e podem governar DS cross-BU.\r\n7;H7;Handoff, implementa\xE7\xE3o e qualidade em produ\xE7\xE3o;Capacidade de especificar, comunicar e acompanhar a implementa\xE7\xE3o de design at\xE9 a produ\xE7\xE3o com qualidade. Inclui specs detalhadas, regras de aplica\xE7\xE3o, QA de design, resolu\xE7\xE3o de gaps implementa\xE7\xE3o-design e crit\xE9rios de aceite visual.;Medir a capacidade do designer de garantir que o que foi projetado chegue ao usu\xE1rio com fidelidade. O gap design-implementa\xE7\xE3o \xE9 a maior fonte de d\xE9bito de experi\xEAncia \u2014 esta skill mede a ponte entre Figma e produ\xE7\xE3o.;"Baseado na teoria de ""design-development handoff effectiveness"" (Maudet et al., 2017). Mede a capacidade de comunica\xE7\xE3o t\xE9cnica cross-funcional e controle de qualidade. Correlaciona-se com satisfa\xE7\xE3o de engenharia e velocidade de entrega.";"Comunica\xE7\xE3o t\xE9cnica; Controle de qualidade; Colabora\xE7\xE3o cross-funcional";N\xEDvel 1: Apoia organiza\xE7\xE3o de specs com checklist. N\xEDvel 3: Handoff completo com antecipa\xE7\xE3o de d\xFAvidas. Conduz QA. N\xEDvel 5: Define padr\xE3o de handoff e QA organizacional.;1 \u2014 Organiza specs com apoio | 2 \u2014 Handoff b\xE1sico com checklist | 3 \u2014 Handoff completo + QA ativo | 4 \u2014 Processo de handoff do time | 5 \u2014 Padr\xE3o organizacional de qualidade;"Skill pragm\xE1tico que matura com experi\xEAncia de entrega real. Seniores dominam QA; Especialistas definem processo."\r\n8;H8;IA aplicada ao design;Capacidade de usar intelig\xEAncia artificial como ferramenta de acelera\xE7\xE3o do processo de design e conte\xFAdo (prompting, s\xEDntese, gera\xE7\xE3o de varia\xE7\xF5es) e de projetar experi\xEAncias que integram IA como capability do produto.;Medir a flu\xEAncia em IA como compet\xEAncia emergente e diferenciadora. A velocidade de ado\xE7\xE3o de IA no processo de design e no produto \xE9 um indicador de adaptabilidade e relev\xE2ncia futura do designer.;"Baseado na teoria de ""augmented intelligence"" e na evid\xEAncia de que profissionais que integram IA ao workflow aumentam produtividade em 20-40% (McKinsey, 2023). Compet\xEAncia emergente com alta vari\xE2ncia de ado\xE7\xE3o \u2014 ideal para diagn\xF3stico.";"Flu\xEAncia tecnol\xF3gica; Adaptabilidade ferramental; Design com IA";N\xEDvel 1: Aprende ferramentas b\xE1sicas de IA e aplica com orienta\xE7\xE3o. N\xEDvel 3: Usa IA como acelerador sistem\xE1tico. Avalia outputs criticamente. N\xEDvel 5: Define estrat\xE9gia de IA para design e produto na organiza\xE7\xE3o.;1 \u2014 Aprende ferramentas e aplica com apoio | 2 \u2014 Experimenta IA no processo | 3 \u2014 Acelerador sistem\xE1tico + avalia\xE7\xE3o cr\xEDtica | 4 \u2014 IA em problemas de produto | 5 \u2014 Estrat\xE9gia de IA para design organizacional;Skill emergente que diferencia designers adapt\xE1veis. Plenos+ que dominam IA ganham vantagem significativa em velocidade e escopo.\r\n9;H9;Acessibilidade digital e design inclusivo;Capacidade de projetar interfaces acess\xEDveis conforme WCAG 2.1+, testar com tecnologias assistivas e garantir que produtos financeiros sejam utiliz\xE1veis por pessoas com defici\xEAncia. Inclui conformidade regulat\xF3ria (Lei 13.146/2015).;Medir a compet\xEAncia em design inclusivo \u2014 obriga\xE7\xE3o legal em servi\xE7os financeiros e indicador de maturidade \xE9tica do designer. Acessibilidade \xE9 constraint, n\xE3o feature. Avalia profundidade t\xE9cnica e compromisso com inclus\xE3o.;"Baseado nas WCAG (W3C), na legisla\xE7\xE3o brasileira de acessibilidade digital e em evid\xEAncias de que design acess\xEDvel beneficia todos os usu\xE1rios (""curb-cut effect"", Blackwell, 2006). Mede conhecimento t\xE9cnico, pr\xE1tica de testes e governan\xE7a de a11y.";"Compet\xEAncia t\xE9cnica de acessibilidade; \xC9tica aplicada; Conformidade regulat\xF3ria";N\xEDvel 1: Conhece contraste e tamanho m\xEDnimo de fonte. N\xEDvel 3: Acessibilidade como crit\xE9rio padr\xE3o. Testa com assistivas. N\xEDvel 5: Define programa de acessibilidade organizacional.;1 \u2014 No\xE7\xF5es b\xE1sicas (contraste, fonte) | 2 \u2014 Aplica WCAG AA com checklist | 3 \u2014 Crit\xE9rio padr\xE3o + testes assistivos | 4 \u2014 Refer\xEAncia e auditor de a11y | 5 \u2014 Programa organizacional de acessibilidade;"Expectativa crescente com senioridade. Seniores garantem a11y no squad; Especialistas lideram compliance e definem pol\xEDtica."\r\n10;H10;Design seguro e privacidade by design;Capacidade de projetar fluxos com seguran\xE7a e privacidade integradas \u2014 autentica\xE7\xE3o, exposi\xE7\xE3o m\xEDnima de dados, microcopys LGPD, preven\xE7\xE3o de dark patterns e alinhamento com Seguran\xE7a Corporativa e Compliance.;Medir compet\xEAncia em um dom\xEDnio cr\xEDtico para produtos banc\xE1rios. Design seguro previne fraude, protege o cliente e garante conformidade regulat\xF3ria \u2014 erros aqui t\xEAm impacto financeiro e reputacional direto.;"Baseado nos princ\xEDpios de ""Privacy by Design"" (Cavoukian, 2009), LGPD e regulamenta\xE7\xE3o BACEN. Em contexto banc\xE1rio, o designer \xE9 co-respons\xE1vel pela seguran\xE7a percebida e real do produto. Compet\xEAncia cr\xEDtica com alta especificidade setorial.";"Seguran\xE7a aplicada a UX; Privacidade by design; \xC9tica digital";N\xEDvel 1: Conhece conceitos b\xE1sicos de privacidade e LGPD. N\xEDvel 3: Refer\xEAncia de design seguro no squad. Garante conformidade. N\xEDvel 5: Define padr\xE3o de seguran\xE7a de UX organizacional.;1 \u2014 Conceitos b\xE1sicos de LGPD | 2 \u2014 Aplica princ\xEDpios com apoio | 3 \u2014 Refer\xEAncia no squad + conformidade | 4 \u2014 Auditor de seguran\xE7a de UX | 5 \u2014 Pol\xEDtica organizacional de design seguro;"Skill setorial cr\xEDtico para Bradesco. Seniores garantem conformidade; Especialistas auditam e definem padr\xE3o regulat\xF3rio-design."\r\nSOFT SKILLS \u2014 Compet\xEAncias Comportamentais e de Lideran\xE7a (S1\u2013S10);;;;;;;;;\r\n11;S1;Decis\xE3o orientada a dados e impacto;Capacidade de explicitar trade-offs, usar dados quantitativos e qualitativos para fundamentar decis\xF5es de design e conectar escolhas a m\xE9tricas de impacto no produto e no neg\xF3cio.;Medir a maturidade de tomada de decis\xE3o baseada em evid\xEAncia. Designers que decidem com dados reduzem vi\xE9s, aumentam previsibilidade e ganham credibilidade com stakeholders de produto e neg\xF3cio.;"Baseado na teoria de ""evidence-based decision making"" (Pfeffer & Sutton, 2006) e no construto de ""analytical thinking"" (Spencer & Spencer, 1993). Mede a progress\xE3o de decis\xE3o intuitiva para decis\xE3o estruturada e baseada em impacto.";"Tomada de decis\xE3o anal\xEDtica; Orienta\xE7\xE3o a impacto; Pensamento cr\xEDtico";N\xEDvel 1: Aprende crit\xE9rios antes de decidir. Valida entendimento. N\xEDvel 3: Explicita trade-offs com base em impacto, risco e esfor\xE7o. N\xEDvel 5: Define frameworks de decis\xE3o e cultura data-driven na organiza\xE7\xE3o.;1 \u2014 Aprende crit\xE9rios | 2 \u2014 Decide em escopo pequeno | 3 \u2014 Trade-offs expl\xEDcitos com impacto | 4 \u2014 Decis\xE3o estrat\xE9gica multi-squad | 5 \u2014 Fomenta cultura data-driven ;#ObstinadosPorResultados \u2014 conecta design a resultados mensur\xE1veis. Diferenciador para transi\xE7\xE3o Pleno\u2192S\xEAnior.\r\n12;S2;Colabora\xE7\xE3o no grupo com vis\xE3o do todo;Capacidade de colaborar efetivamente no grupo (Design, PM, Eng e quem mais tiver no grupo), negociar escopo, alinhar prioridades e manter vis\xE3o do cliente final enquanto respeita restri\xE7\xF5es t\xE9cnicas e de neg\xF3cio.;Medir a capacidade de operar em contexto multidisciplinar \u2014 a unidade fundamental de entrega em produto. Colabora\xE7\xE3o no grupo \xE9 a skill que mais prediz velocidade e qualidade de entrega do squad.;"Baseado na teoria de equipes multidisciplinares de alto desempenho (Hackman, 2002) e no modelo de ""shared mental models"" (Cannon-Bowers et al., 1993). Mede integra\xE7\xE3o, negocia\xE7\xE3o e capacidade de influenciar sem autoridade formal.";"Colabora\xE7\xE3o multidisciplinar; Negocia\xE7\xE3o; Influ\xEAncia lateral";N\xEDvel 1: Participa como apoio. Observa din\xE2mica do grupo. N\xEDvel 3: Parceiro forte no grupo. Antecipa depend\xEAncias e influencia roadmap. N\xEDvel 5: Cria modelo de colabora\xE7\xE3o Design-PM-Eng organizacional.;1 \u2014 Observa e participa | 2 \u2014 Colabora em rotinas | 3 \u2014 Parceiro forte + influ\xEAncia no roadmap | 4 \u2014 Facilitador de alinhamento cross-squad | 5 \u2014 Modelo organizacional de grupo;#UnidosEvolu\xEDmos \u2014 trabalho em parceria como princ\xEDpio. Skill cr\xEDtica para Pleno+ e especialmente para trilha TL/Gest\xE3o.\r\n13;S3;Comunica\xE7\xE3o, narrativa e influ\xEAncia;Capacidade de comunicar racional de design, construir narrativas persuasivas e influenciar stakeholders em diferentes n\xEDveis hier\xE1rquicos. Inclui apresenta\xE7\xF5es, documenta\xE7\xE3o de decis\xE3o e advocacy de design.;"Medir a capacidade de converter compet\xEAncia t\xE9cnica em influ\xEAncia organizacional. Designers que comunicam bem multiplicam o impacto do seu trabalho; designers que n\xE3o, ficam limitados ao escopo do seu squad.";"Baseado no construto de ""strategic communication"" e em estudos sobre impacto de design advocacy na maturidade organizacional de design (InVision Design Maturity Model, 2019). Mede clareza, persuas\xE3o e alcance da comunica\xE7\xE3o.";"Comunica\xE7\xE3o estrat\xE9gica; Storytelling; Influ\xEAncia organizacional";N\xEDvel 1: Comunica progresso e bloqueios com clareza. N\xEDvel 3: Apresenta racional com clareza para stakeholders. Influencia sem confrontar. N\xEDvel 5: Narrativa de design como ferramenta estrat\xE9gica. Influencia C-level.;1 \u2014 Comunica progresso/bloqueios | 2 \u2014 Objetivo e claro no time | 3 \u2014 Influencia stakeholders | 4 \u2014 Narrativa para lideran\xE7a | 5 \u2014 Influ\xEAncia em n\xEDvel executivo;#SomosPelasPessoas \u2014 comunica\xE7\xE3o emp\xE1tica e construtiva. Skill diferenciadora para cargos de lideran\xE7a (Coordenador+).\r\n14;S4;Senso de dono e responsabilidade por outcomes;Capacidade de assumir responsabilidade por resultados, n\xE3o apenas entregas. Inclui acompanhar m\xE9tricas p\xF3s-launch, fechar ciclos de feedback, e garantir que o design entregue valor real ao usu\xE1rio e ao neg\xF3cio.;Medir a orienta\xE7\xE3o a resultado vs. orienta\xE7\xE3o a tarefa. Designers com senso de dono n\xE3o terminam no handoff \u2014 acompanham, medem e ajustam. \xC9 o indicador mais forte de maturidade profissional no modelo de carreira.;"Baseado no construto de ""ownership orientation"" e ""outcome accountability"" (Hackman & Oldham, 1976). Correlaciona-se com autonomia, motiva\xE7\xE3o intr\xEDnseca e impacto percebido pela organiza\xE7\xE3o. Forte preditor de progress\xE3o de carreira.";"Accountability; Orienta\xE7\xE3o a resultados; Autonomia com responsabilidade";N\xEDvel 1: Assume tarefas bem definidas e conclui no prazo. N\xEDvel 3: Assume problemas complexos. Acompanha impacto e fecha ciclos. N\xEDvel 5: Define cultura de ownership e accountability na organiza\xE7\xE3o.;1 \u2014 Assume tarefas definidas | 2 \u2014 Assume entregas com suporte | 3 \u2014 Ownership de problemas + impacto | 4 \u2014 Ownership cross-squad | 5 \u2014 Cultura de accountability organizacional;#ObstinadosPorResultados \u2014 resultado acima de entrega. Requisito para transi\xE7\xE3o Pleno \u2192S\xEAnior .\r\n15;S5;Planejamento, prioriza\xE7\xE3o e previsibilidade;Capacidade de organizar trabalho, estimar esfor\xE7o, priorizar com crit\xE9rio e criar previsibilidade para o time e stakeholders. Inclui gest\xE3o de tempo, comunica\xE7\xE3o de status e adapta\xE7\xE3o a mudan\xE7as de escopo.;Medir a maturidade operacional do designer como profissional. Previsibilidade \xE9 a base da confian\xE7a \u2014 designers que entregam quando prometem ganham autonomia e escopo progressivamente maiores.;"Baseado no construto de ""self-regulation"" (Zimmerman, 2000) e na teoria de ""planning behavior"" em contexto profissional. Mede organiza\xE7\xE3o, estimativa e capacidade de criar previsibilidade \u2014 atributo que escala com responsabilidade.";"Autogest\xE3o; Planejamento; Previsibilidade operacional";N\xEDvel 1: Trabalha com lista curta e orienta\xE7\xE3o di\xE1ria. N\xEDvel 3: Planeja trabalho e organiza fluxo do squad. Cria previsibilidade. N\xEDvel 5: Define processos e cad\xEAncia de planejamento organizacional.;1 \u2014 Lista curta com orienta\xE7\xE3o | 2 \u2014 Estimativas com rotinas | 3 \u2014 Planejamento + previsibilidade do squad | 4 \u2014 Planejamento cross-squad | 5 \u2014 Processos de planejamento organizacional;#OrientadosADesafios \u2014 operar com consist\xEAncia sob press\xE3o. Skill operacional que habilita confian\xE7a para escopo maior.\r\n16;S6;Lideran\xE7a e eleva\xE7\xE3o de barra;Capacidade de elevar o padr\xE3o de qualidade do time atrav\xE9s do exemplo, cria\xE7\xE3o de padr\xF5es, rituais de cr\xEDtica, revis\xE3o de entregas e influ\xEAncia pela excel\xEAncia t\xE9cnica \u2014 sem necessidade de gest\xE3o formal.;Medir a capacidade de multiplica\xE7\xE3o de impacto via influ\xEAncia t\xE9cnica. L\xEDderes de craft criam efeito multiplicador \u2014 quando um designer sobe a barra, todo o time entrega melhor. \xC9 o indicador principal da trilha IC.;"Baseado no construto de ""technical leadership"" e ""expert influence"" (Dreyfus & Dreyfus, 1986). Mede a transi\xE7\xE3o de compet\xEAncia individual para impacto coletivo \u2014 o ponto de inflex\xE3o entre contribuidor e multiplicador.";"Lideran\xE7a t\xE9cnica; Influ\xEAncia pelo exemplo; Multiplica\xE7\xE3o de qualidade";N\xEDvel 1: Absorve feedback e aplica com abertura. N\xEDvel 3: Mentor consistente. Revisa trabalho e compartilha m\xE9todo. N\xEDvel 5: Define padr\xE3o de excel\xEAncia e cultura de craft organizacional.;1 \u2014 Absorve feedback | 2 \u2014 Aplica e ajuda pontualmente | 3 \u2014 Mentor e revisor consistente | 4 \u2014 Refer\xEAncia de craft cross-squad | 5 \u2014 Cultura de craft organizacional;#UmTimeEmpoderado \u2014 elevar o time pelo exemplo. Skill principal da trilha IC (Especialista).\r\n17;S7;Desenvolvimento de pessoas e gest\xE3o de crescimento;Capacidade de desenvolver pessoas \u2014 feedback estruturado, suporte a PDI, cria\xE7\xE3o de condi\xE7\xF5es para crescimento e gest\xE3o intencional de carreiras. Inclui mentoria formal, 1:1s e acompanhamento de evolu\xE7\xE3o.;"Medir a capacidade de investimento em capital humano. L\xEDderes que desenvolvem pessoas criam times sustent\xE1veis; os que n\xE3o, criam depend\xEAncia de indiv\xEDduos. Skill principal da trilha TL/Gest\xE3o.";"Baseado na teoria de ""transformational leadership"" (Bass, 1985) e no construto de ""developmental orientation"" (London & Smither, 1999). Mede investimento intencional no crescimento de outros \u2014 forte preditor de lideran\xE7a efetiva.";"Lideran\xE7a transformacional; Mentoria; Gest\xE3o de desenvolvimento";N\xEDvel 1-2: N\xE3o se aplica \u2014 foco em desenvolvimento pessoal. N\xEDvel 3: Feedback estruturado. Acompanha desenvolvimento com intencionalidade. N\xEDvel 5: Define programa de desenvolvimento de designers na organiza\xE7\xE3o.;1-2 \u2014 Foco em desenvolvimento pr\xF3prio | 3 \u2014 Feedback estruturado + acompanhamento | 4 \u2014 Mentoria formal + gest\xE3o de PDI | 5 \u2014 Programa de desenvolvimento organizacional;#SomosPelasPessoas \xB7 #UnidosEvolu\xEDmos \u2014 investir em pessoas. Skill principal da trilha TL (Coordenador/Gerente). Ativa a partir de S\xEAnior.\r\n18;S8;Empatia com usu\xE1rio e centragem no cliente;Capacidade de entender contextos reais de uso, identificar necessidades latentes e usar insights humanos para orientar decis\xF5es de design. Vai al\xE9m de pesquisa \u2014 \xE9 postura e pr\xE1tica cont\xEDnua de centralidade no cliente.;Medir a profundidade da conex\xE3o designer-usu\xE1rio. Empatia aplicada ao design n\xE3o \xE9 sentimento \u2014 \xE9 pr\xE1tica de investiga\xE7\xE3o e s\xEDntese que garante que o produto resolve problemas reais de pessoas reais em contextos reais.;"Baseado na teoria de ""empathic design"" (Leonard & Rayport, 1997) e no construto de ""user-centered mindset"" (Norman, 1988). Mede a capacidade de manter o usu\xE1rio como norte decis\xF3rio \u2014 especialmente quando press\xF5es de neg\xF3cio puxam em outra dire\xE7\xE3o.";"Empatia aplicada; Centragem no cliente; Advocacia do usu\xE1rio";N\xEDvel 1: Observa usu\xE1rios e documenta com apoio. N\xEDvel 3: Garante centralidade no usu\xE1rio em decis\xF5es de produto. N\xEDvel 5: Define cultura customer-centric na organiza\xE7\xE3o de design.;1 \u2014 Observa com apoio | 2 \u2014 Pesquisa e s\xEDntese b\xE1sica | 3 \u2014 Centralidade no usu\xE1rio como crit\xE9rio | 4 \u2014 Advocacia cross-squad do usu\xE1rio | 5 \u2014 Cultura customer-centric organizacional;#SomosPelosClientes \u2014 o cliente no centro de tudo. Skill transversal que matura com exposi\xE7\xE3o e experi\xEAncia.\r\n19;S9;Vis\xE3o de neg\xF3cio e conex\xE3o com impacto;Capacidade de conectar decis\xF5es de design a m\xE9tricas de produto, OKRs e resultados financeiros. Inclui entender modelo de neg\xF3cio, funnel, unit economics e como design contribui para o resultado da organiza\xE7\xE3o.;Medir a flu\xEAncia de neg\xF3cio do designer. Designers com vis\xE3o de neg\xF3cio falam a l\xEDngua dos stakeholders, justificam investimento em design e s\xE3o percebidos como parceiros estrat\xE9gicos, n\xE3o prestadores de servi\xE7o.;"Baseado no construto de ""business acumen"" (Charan, 2001) e na evid\xEAncia de que designers com flu\xEAncia de neg\xF3cio ocupam posi\xE7\xF5es de maior influ\xEAncia e impacto (McKinsey Design Index, 2018). Mede a capacidade de traduzir design em valor.";"Flu\xEAncia de neg\xF3cio; Orienta\xE7\xE3o estrat\xE9gica; Conex\xE3o design-neg\xF3cio";N\xEDvel 1: Aprende m\xE9tricas b\xE1sicas do produto. N\xEDvel 3: Conecta decis\xF5es de design a OKRs e m\xE9tricas. N\xEDvel 5: Design como alavanca de resultado financeiro. Influencia estrat\xE9gia.;1 \u2014 Aprende m\xE9tricas | 2 \u2014 Conecta design a m\xE9tricas simples | 3 \u2014 Design conectado a OKRs | 4 \u2014 Vis\xE3o de neg\xF3cio cross-squad | 5 \u2014 Design como estrat\xE9gia de neg\xF3cio;#ObstinadosPorResultados \xB7 #SomosPelosClientes \u2014 impacto real. Requisito para S\xEAnior+ e para trilha Gest\xE3o.\r\n20;S10;Adaptabilidade, aprendizado cont\xEDnuo e gest\xE3o da incerteza;Capacidade de operar bem em ambientes de mudan\xE7a, aprender novas ferramentas e m\xE9todos com velocidade, e manter consist\xEAncia de entrega mesmo quando contexto, prioridades ou requisitos mudam.;Medir a resili\xEAncia e flexibilidade profissional. Em um setor em transforma\xE7\xE3o digital acelerada, a capacidade de aprender e se adaptar \xE9 t\xE3o importante quanto qualquer skill t\xE9cnica individual.;"Baseado no construto de ""learning agility"" (Lombardo & Eichinger, 2000) \u2014 um dos melhores preditores de sucesso em cargos de crescente complexidade. Mede a meta-compet\xEAncia de aprender a aprender, essencial em ambiente VUCA.";"Learning agility; Resili\xEAncia; Gest\xE3o da ambiguidade";N\xEDvel 1: Adapta-se com apoio. Aprende ferramentas novas com orienta\xE7\xE3o. N\xEDvel 3: Opera bem em mudan\xE7a. Aprende por conta pr\xF3pria. Mant\xE9m entrega. N\xEDvel 5: Cria cultura de aprendizado cont\xEDnuo e adaptabilidade na organiza\xE7\xE3o.;1 \u2014 Adapta-se com apoio | 2 \u2014 Flex\xEDvel em mudan\xE7as previs\xEDveis | 3 \u2014 Consistente em incerteza | 4 \u2014 Facilita adapta\xE7\xE3o do time | 5 \u2014 Cultura de learning agility organizacional;#OrientadosADesafios \u2014 abra\xE7ar a incerteza como oportunidade. Meta-compet\xEAncia transversal que habilita crescimento em todas as trilhas.\r\n;;;;;;;;;\r\nNOTAS METODOL\xD3GICAS;;;;;;;;;\r\n;Escala Likert 1-5;;Cada skill \xE9 avaliada em escala de 1 a 5, onde cada ponto corresponde a um n\xEDvel de profici\xEAncia descrito em termos comportamentais observ\xE1veis (behavioral anchoring). A escala \xE9 ordinal e monot\xF4nicamente crescente, com cada n\xEDvel pressupondo dom\xEDnio dos anteriores.;;;;;;\r\n;Dupla avalia\xE7\xE3o;;O modelo usa autoavalia\xE7\xE3o + avalia\xE7\xE3o do gestor para cada skill, permitindo an\xE1lise de gap de percep\xE7\xE3o (Delta = |Gestor - Auto|). Diverg\xEAncias significativas (>1 ponto) s\xE3o sinalizadas como oportunidade de calibra\xE7\xE3o no 1:1.;;;;;;\r\n;Pondera\xE7\xE3o Hard/Soft;;O peso relativo de Hard vs Soft skills varia com senioridade: J\xFAnior (65H/35S), Pleno (55H/45S), S\xEAnior (50H/50S), Especialista (45H/55S), Principal (35H/65S). Reflete a transi\xE7\xE3o natural de execu\xE7\xE3o t\xE9cnica para impacto organizacional.;;;;;;\r\n;Piso de prote\xE7\xE3o;;O Nivel_final usa MIN(Nivel_Media, Nivel_Piso) onde Piso = 3\xAA menor nota entre as 20 skills. Isso impede que um Overall alto mascare gaps cr\xEDticos \u2014 um designer com m\xE9dia 4 mas tr\xEAs skills em n\xEDvel 1 ter\xE1 seu n\xEDvel final rebaixado.;;;;;;\r\n;Base te\xF3rica;;O framework integra elementos de: Taxonomia de compet\xEAncias (Spencer & Spencer, 1993), Modelo de expertise (Dreyfus & Dreyfus, 1986), Design maturity (Nielsen Norman Group), Learning agility (Lombardo & Eichinger, 2000), e regulamenta\xE7\xE3o setorial (LGPD, WCAG, BACEN).;;;;;;\r\n;Limita\xE7\xF5es;;Autoavalia\xE7\xE3o \xE9 suscet\xEDvel a vi\xE9s (Dunning-Kruger, desejabilidade social). A avalia\xE7\xE3o do gestor mitiga parcialmente esse risco. O diagn\xF3stico \xE9 orientador, n\xE3o determin\xEDstico \u2014 deve ser complementado por evid\xEAncias de entrega e portf\xF3lio.;;;;;;';

  // raw-text:/Users/renatosilvestre/Desktop/Report_Skill/Skill Mapping/src/data/capability-expectations.csv
  var capability_expectations_default = "Cargo;H1. Discovery e framing de problema;H2. Estrat\xE9gia de experi\xEAncia e fluxos;H3. UI e craft (qualidade visual e intera\xE7\xE3o);H4. UX Writing e conte\xFAdo de interface;H5. Prototipa\xE7\xE3o e valida\xE7\xE3o para decis\xE3o;H6. Design System e escalabilidade;H7. Handoff, implementa\xE7\xE3o e qualidade em produ\xE7\xE3o;H8. IA aplicada ao design;H9. Acessibilidade digital e design inclusivo;H10. Design seguro e privacidade by design;S1. Decis\xE3o orientada a dados e impacto;S2. Colabora\xE7\xE3o no grupo com vis\xE3o do todo;S3. Comunica\xE7\xE3o, narrativa e influ\xEAncia;S4. Senso de dono e responsabilidade por outcomes;S5. Planejamento, prioriza\xE7\xE3o e previsibilidade;S6. Lideran\xE7a e eleva\xE7\xE3o de barra;S7. Desenvolvimento de pessoas e gest\xE3o de crescimento;S8. Empatia com usu\xE1rio e centragem no cliente;S9. Vis\xE3o de neg\xF3cio e conex\xE3o com impacto;S10. Adaptabilidade, aprendizado cont\xEDnuo e gest\xE3o da incerteza\nDiretor(a) Design;Respons\xE1vel pela maturidade de discovery da disciplina. Influencia estrat\xE9gia organizacional.;Respons\xE1vel pela vis\xE3o de experi\xEAncia da organiza\xE7\xE3o. Define dire\xE7\xE3o estrat\xE9gica de longo prazo.;Define cultura de craft da organiza\xE7\xE3o. Respons\xE1vel pela excel\xEAncia da disciplina de design.;Respons\xE1vel pela maturidade de UX Writing da disciplina. Influ\xEAncia organizacional em conte\xFAdo.;Define filosofia de aprendizado e valida\xE7\xE3o. Conecta com cultura de produto da organiza\xE7\xE3o.;Define arquitetura de DS da organiza\xE7\xE3o. Respons\xE1vel por escala e sustentabilidade.;Respons\xE1vel pela qualidade de design em produ\xE7\xE3o na organiza\xE7\xE3o. Influencia toda a engenharia.;Respons\xE1vel pela estrat\xE9gia de IA da disciplina. Define pol\xEDticas, capacita\xE7\xE3o e governan\xE7a.;Respons\xE1vel pela maturidade de acessibilidade da disciplina. Influ\xEAncia organizacional.;Respons\xE1vel pela maturidade de design seguro da disciplina. Influ\xEAncia organizacional.;Decis\xE3o com vis\xE3o de longo prazo e impacto organizacional. Resolve tens\xF5es estrat\xE9gicas.;Refer\xEAncia de colabora\xE7\xE3o cross-organiza\xE7\xE3o. Define como Design se integra ao neg\xF3cio.;Influ\xEAncia executiva m\xE1xima. Traduz a vis\xE3o de design em estrat\xE9gia de neg\xF3cio.;Respons\xE1vel pelo resultado da disciplina na organiza\xE7\xE3o. Define OKRs estrat\xE9gicos.;Define estrat\xE9gia de crescimento da disciplina. Cria previsibilidade organizacional.;Respons\xE1vel pelo desenvolvimento da lideran\xE7a de design. Cria cultura de excel\xEAncia.;Respons\xE1vel pela maturidade e pipeline de talentos da disciplina. Influ\xEAncia organizacional.;Respons\xE1vel pela cultura de empatia da disciplina. Influ\xEAncia executiva.;Respons\xE1vel pela estrat\xE9gia de valor da disciplina. Influ\xEAncia C-level.;Respons\xE1vel pela maturidade de adaptabilidade da disciplina. Influ\xEAncia organizacional.\nSuperintendente SR Design;Respons\xE1vel pela maturidade de discovery da disciplina. Influencia estrat\xE9gia organizacional.;Respons\xE1vel pela vis\xE3o de experi\xEAncia da organiza\xE7\xE3o. Define dire\xE7\xE3o estrat\xE9gica de longo prazo.;Define cultura de craft da organiza\xE7\xE3o. Respons\xE1vel pela excel\xEAncia da disciplina de design.;Respons\xE1vel pela maturidade de UX Writing da disciplina. Influ\xEAncia organizacional em conte\xFAdo.;Define filosofia de aprendizado e valida\xE7\xE3o. Conecta com cultura de produto da organiza\xE7\xE3o.;Define arquitetura de DS da organiza\xE7\xE3o. Respons\xE1vel por escala e sustentabilidade.;Respons\xE1vel pela qualidade de design em produ\xE7\xE3o na organiza\xE7\xE3o. Influencia toda a engenharia.;Respons\xE1vel pela estrat\xE9gia de IA da disciplina. Define pol\xEDticas, capacita\xE7\xE3o e governan\xE7a.;Respons\xE1vel pela maturidade de acessibilidade da disciplina. Influ\xEAncia organizacional.;Respons\xE1vel pela maturidade de design seguro da disciplina. Influ\xEAncia organizacional.;Decis\xE3o com vis\xE3o de longo prazo e impacto organizacional. Resolve tens\xF5es estrat\xE9gicas.;Refer\xEAncia de colabora\xE7\xE3o cross-organiza\xE7\xE3o. Define como Design se integra ao neg\xF3cio.;Influ\xEAncia executiva m\xE1xima. Traduz a vis\xE3o de design em estrat\xE9gia de neg\xF3cio. Remove bloqueios gerenciais.;Respons\xE1vel pelo resultado da disciplina na organiza\xE7\xE3o. Define OKRs estrat\xE9gicos.;Define estrat\xE9gia de crescimento da disciplina. Cria previsibilidade organizacional.;Respons\xE1vel pelo desenvolvimento da lideran\xE7a de design. Cria cultura de excel\xEAncia.;Respons\xE1vel pela maturidade e pipeline de talentos da disciplina. Influ\xEAncia organizacional.;Respons\xE1vel pela cultura de empatia da disciplina. Influ\xEAncia executiva.;Respons\xE1vel pela estrat\xE9gia de valor da disciplina. Influ\xEAncia C-level.;Respons\xE1vel pela maturidade de adaptabilidade da disciplina. Influ\xEAncia organizacional.\nSuperintendente Design;Define pol\xEDtica de discovery. Conecta com objetivos de produto e m\xE9tricas da organiza\xE7\xE3o.;Define vis\xE3o de experi\xEAncia alinhada \xE0 estrat\xE9gia do produto. Garante coer\xEAncia de longo prazo.;Define cultura de craft e qualidade. Garante que excel\xEAncia \xE9 expectativa, n\xE3o exce\xE7\xE3o.;Define pol\xEDtica de UX Writing. Conecta estrat\xE9gia de produto com experi\xEAncia do cliente.;Define pol\xEDtica de valida\xE7\xE3o. Conecta aprendizado com OKRs e estrat\xE9gia de produto.;Define estrat\xE9gia de DS alinhada \xE0 tecnologia e produto. Influencia roadmap de plataforma.;Define padr\xE3o de qualidade em produ\xE7\xE3o alinhado \xE0 estrat\xE9gia. Influencia roadmap t\xE9cnico.;Define estrat\xE9gia de IA para a \xE1rea. Garante desenvolvimento de compet\xEAncia e uso \xE9tico.;Define pol\xEDtica. Conecta com estrat\xE9gia de produto, regula\xE7\xE3o e inclus\xE3o financeira.;Define pol\xEDtica de design seguro. Conecta com estrat\xE9gia de seguran\xE7a e regula\xE7\xE3o.;Decide com vis\xE3o estrat\xE9gica. Garante alinhamento entre objetivos da \xE1rea e da organiza\xE7\xE3o.;Coordena colabora\xE7\xE3o cross-\xE1rea em n\xEDvel estrat\xE9gico. Cria estruturas de parceria.;Influ\xEAncia executiva consistente. Negocia prioridades e defende o time com dados. Remove bloqueios gerenciais.;Respons\xE1vel pelo resultado e maturidade da \xE1rea. Conecta desempenho com estrat\xE9gia.;Define prioridades estrat\xE9gicas da \xE1rea. Cria previsibilidade e planejamento de longo prazo.;Desenvolve lideran\xE7as intermedi\xE1rias. Cria pipeline de talentos e cultura de alta performance.;Define pol\xEDtica de desenvolvimento da \xE1rea. Cria lideran\xE7as intermedi\xE1rias com intencionalidade.;Define pol\xEDtica de centralidade no cliente. Conecta com estrat\xE9gia de produto.;Define pol\xEDtica de conex\xE3o design-neg\xF3cio. Influ\xEAncia executiva consistente.;Define pol\xEDtica de aprendizado cont\xEDnuo. Conecta com transforma\xE7\xE3o digital.\nGerente SR Design;Define pol\xEDtica de discovery. Conecta com objetivos de produto e m\xE9tricas da organiza\xE7\xE3o. (N5);Define vis\xE3o de experi\xEAncia alinhada \xE0 estrat\xE9gia do produto. Garante coer\xEAncia de longo prazo. (N5);Define cultura de craft e qualidade. Garante que excel\xEAncia \xE9 expectativa, n\xE3o exce\xE7\xE3o. (N5);Define pol\xEDtica de UX Writing. Conecta estrat\xE9gia de produto com experi\xEAncia do cliente. (N5);Define pol\xEDtica de valida\xE7\xE3o. Conecta aprendizado com OKRs e estrat\xE9gia de produto. (N5);Define estrat\xE9gia de DS alinhada \xE0 tecnologia e produto. Influencia roadmap de plataforma. (N2 - N3);Define padr\xE3o de qualidade em produ\xE7\xE3o alinhado \xE0 estrat\xE9gia. Influencia roadmap t\xE9cnico. (N2 - N3);Define estrat\xE9gia de IA para a \xE1rea. Garante desenvolvimento de compet\xEAncia e uso \xE9tico. (N5);Define pol\xEDtica. Conecta com estrat\xE9gia de produto, regula\xE7\xE3o e inclus\xE3o financeira. (N4 - N5);Define pol\xEDtica de design seguro. Conecta com estrat\xE9gia de seguran\xE7a e regula\xE7\xE3o. (N4 - N5);Decide com vis\xE3o estrat\xE9gica. Garante alinhamento entre objetivos da \xE1rea e da organiza\xE7\xE3o. (N5);Coordena colabora\xE7\xE3o cross-\xE1rea em n\xEDvel estrat\xE9gico. Cria estruturas de parceria. (N5);Influ\xEAncia executiva consistente. Negocia prioridades do time com dados. Remove bloqueios gerenciais. (N5);Respons\xE1vel pelo resultado e maturidade da \xE1rea. Conecta desempenho com estrat\xE9gia. (N5);Define prioridades estrat\xE9gicas da \xE1rea. Cria previsibilidade e planejamento de longo prazo. (N5);Desenvolve lideran\xE7as intermedi\xE1rias. Cria pipeline de talentos e cultura de alta performance. (N4 - N5);Fortalece a cultura de aprendizado cont\xEDnuo, defende budget de forma\xE7\xE3o espec\xEDfico da \xE1rea e promove sucess\xE3o em n\xEDveis de lideran\xE7a mais seniores. (N5);Garante que o time tem acesso a insights de usu\xE1rio. Remove barreiras de pesquisa. (N4 e N5);Define pol\xEDtica de conex\xE3o design-neg\xF3cio. Influ\xEAncia executiva consistente. (N4 - N5);Define pol\xEDtica de aprendizado cont\xEDnuo. Conecta com transforma\xE7\xE3o digital. (N5)\nGerente Design;Garante que o time tem condi\xE7\xF5es de fazer discovery de qualidade. Remove fric\xE7\xF5es estruturais. (N4 - N5);Garante vis\xE3o consistente de experi\xEAncia no time. Alinha com PM e Eng em n\xEDvel gerencial. (N5);Garante barra de craft no time. Cria ambiente de excel\xEAncia e aprendizado cont\xEDnuo. (N3 - N4);Garante que o time tem pr\xE1ticas de writing s\xF3lidas. (N3 - N4);Garante cultura de valida\xE7\xE3o e aprendizado no time. (N3 - N4);Garante ado\xE7\xE3o e evolu\xE7\xE3o do DS no time. Alinha com lideran\xE7a de produto e tecnologia. (N2 - N3);Garante qualidade em produ\xE7\xE3o como meta do time. Define crit\xE9rios e acompanha resultados. (N2 - N3);Garante desenvolvimento de compet\xEAncia em IA no time. Define pol\xEDtica de uso respons\xE1vel. (N4 - N5);Garante que o time tem pr\xE1ticas s\xF3lidas de acessibilidade. Remove bloqueios estruturais. (N4 - N5);Garante que o time opera com seguran\xE7a e privacidade. Remove fric\xE7\xF5es estruturais. (N4 - N5);Apoia o time em decis\xF5es estrat\xE9gicas. Define crit\xE9rios gerenciais e remove ambiguidade. (N5);Coordena colabora\xE7\xE3o do time com outras \xE1reas. Resolve conflitos em n\xEDvel gerencial. (N5);Comunica resultados e vis\xE3o com lideran\xE7a executiva. Representa o time estrategicamente. Remove bloqueios gerenciais. (N5);Respons\xE1vel pelo resultado do time. Define metas, acompanha m\xE9tricas e ajusta rota. (N5);Planeja capacidade e crescimento do time. Cria previsibilidade de m\xE9dio e longo prazo. (N4 - N5);Desenvolve pessoas e l\xEDderes no time. Cria cultura de aprendizado e alta performance. (N3 - N4);Fomenta um ambiente de desenvolvimento das pessoas, identifica talentos, constr\xF3i um pipeline de sucess\xE3o, impulsiona o crescimento da equipe e forma novas lideran\xE7as. (N4 - N5);Garante que o time tem acesso a insights de usu\xE1rio. Remove barreiras de pesquisa. (N4 e N5);Garante que o time entende e conecta com metas de neg\xF3cio cross-squad mesmo produto. Remove fric\xE7\xF5es. (N3 - N4);Garante que o time tenha estrutura e desenvolve as pessoas para aprenderem e se adaptarem a contextos de mudan\xE7a. Remove fric\xE7\xF5es. (N4 - N5)\nCoordenador Design;Define estrat\xE9gia de discovery do time. Alinha com lideran\xE7a sobre prioridades e escopo. (N4 - N5);Define vis\xE3o de experi\xEAncia do time. Garante coer\xEAncia estrat\xE9gica ponta a ponta. (N4 - N5);Define barra de qualidade de craft do time. Garante excel\xEAncia e consist\xEAncia em escala. (N3 - N4);Define estrat\xE9gia de UX Writing do time. Garante coer\xEAncia de linguagem em escala. (N3 - N4);Define filosofia de valida\xE7\xE3o do time. Conecta experimentos com estrat\xE9gia de produto. (N3 - N4);Define estrat\xE9gia de DS para o time. Garante sustentabilidade e governan\xE7a m\xEDnima. (N2 - N3);Define padr\xE3o de qualidade em produ\xE7\xE3o para o time. Influencia roadmap t\xE9cnico. (N2 - N3);Define estrat\xE9gia de IA para o time. Garante ado\xE7\xE3o respons\xE1vel e desenvolvimento de compet\xEAncia. (N4 - N5);Define estrat\xE9gia de acessibilidade do time. Garante conformidade regulat\xF3ria. (N4 - N5);Define estrat\xE9gia de privacidade by design do time. (N4 - N5);Decide com vis\xE3o de longo prazo. Garante alinhamento entre objetivos do time e da organiza\xE7\xE3o. (N4 - N5);Define din\xE2mica de colabora\xE7\xE3o do time com outras \xE1reas. Remove fric\xE7\xF5es estruturais. (N4 - N5);Influ\xEAncia executiva. Negocia prioridades do time com dados. Representa o time com narrativa clara e orientada a resultados. (N4 - N5);Respons\xE1vel pelo resultado e maturidade do time. Acompanha e ajusta rota com lideran\xE7a s\xEAnior. (N4 - N5);Organiza de forma estrat\xE9gica a capacidade do time e aponta a necessidade de crescimento. Define prioridades de longo prazo. (N3 - N4);Desenvolve o time de acordo com as necessidades individuais e perspectivas de carreira. Cria uma cultura de desenvolvimento e excel\xEAncia t\xE9cnica. (N2 - N3);Desenvolve a equipe por meio de feedbacks estruturados, estrutura e acompanha PDI e identifica oportunidades de crescimento. (N3 - N4);Garante que o time tem acesso a insights de usu\xE1rio. Remove barreiras de pesquisa. (N4 e N5);Define estrat\xE9gia de impacto do cross-squad do mesmo produto. Parceiro de lideran\xE7a executiva. (N3 - N4);Desenvolve a adapta\xE7\xE3o e garante a consist\xEAncia do time em cen\xE1rios de incerteza e situa\xE7\xF5es adversas. (N3 - N4)\nDesigner Especialista V;Refer\xEAncia m\xE1xima de discovery da organiza\xE7\xE3o. Define o que entra na agenda e por qu\xEA.;Refer\xEAncia m\xE1xima de experi\xEAncia. Define vis\xE3o de produto de longo prazo pela perspectiva de design.;Refer\xEAncia m\xE1xima de craft. Define o que \xE9 excel\xEAncia na organiza\xE7\xE3o. Cria cultura de qualidade.;Refer\xEAncia m\xE1xima de conte\xFAdo. Define o que \xE9 excel\xEAncia de writing na organiza\xE7\xE3o.;Refer\xEAncia m\xE1xima de valida\xE7\xE3o. Define como a organiza\xE7\xE3o aprende e toma decis\xF5es.;Refer\xEAncia m\xE1xima de Design System. Define arquitetura e governan\xE7a que escalam com o neg\xF3cio.;Refer\xEAncia m\xE1xima de qualidade em produ\xE7\xE3o. Garante que design e engenharia compartilham padr\xE3o.;Refer\xEAncia m\xE1xima de IA aplicada ao design. Define estrat\xE9gia, \xE9tica e desenvolvimento de compet\xEAncia.;Define pol\xEDtica de acessibilidade da organiza\xE7\xE3o. Cria cultura de design inclusivo.;Define cultura de design seguro da organiza\xE7\xE3o. Influ\xEAncia executiva em privacidade.;Decis\xE3o com vis\xE3o de longo prazo e impacto m\xE1ximo. Resolve tens\xF5es estrat\xE9gicas da organiza\xE7\xE3o.;Refer\xEAncia de colabora\xE7\xE3o. Define como Design se integra \xE0 estrat\xE9gia e opera\xE7\xE3o do neg\xF3cio.;Influ\xEAncia executiva m\xE1xima. Traduz excel\xEAncia de design em vantagem competitiva.;Respons\xE1vel pela maturidade m\xE1xima da disciplina. Define padr\xE3o de resultado organizacional.;Define estrat\xE9gia de disciplina de longo prazo. Cria previsibilidade e sustentabilidade.;Topo de desenvolvimento de pessoas no IC. Cria lideran\xE7as t\xE9cnicas e cultura de excel\xEAncia.;Define cultura de desenvolvimento da organiza\xE7\xE3o. Refer\xEAncia m\xE1xima de como crescer na disciplina.;Define cultura de centralidade no usu\xE1rio da organiza\xE7\xE3o.;Define como o design cria e captura valor na organiza\xE7\xE3o.;Define cultura de aprendizado e adapta\xE7\xE3o da organiza\xE7\xE3o.\nDesigner Especialista IV;Refer\xEAncia organizacional em discovery. Orienta agenda e padr\xE3o de qualidade da disciplina.;Define vis\xE3o de experi\xEAncia da organiza\xE7\xE3o. Garante coer\xEAncia estrat\xE9gica ponta a ponta.;Define barra de qualidade de craft da organiza\xE7\xE3o. Influencia padr\xE3o de toda a disciplina.;Refer\xEAncia organizacional de UX Writing. Define pol\xEDtica de conte\xFAdo de interface da disciplina.;Define filosofia de valida\xE7\xE3o da organiza\xE7\xE3o. Conecta aprendizado com estrat\xE9gia de produto.;Define arquitetura de uso do DS na organiza\xE7\xE3o. Garante escala e sustentabilidade.;Define padr\xE3o de qualidade em produ\xE7\xE3o para toda a disciplina. Influencia Engenharia.;Define pol\xEDtica de IA para a disciplina. Cria diretrizes de ado\xE7\xE3o e desenvolvimento de compet\xEAncia.;Refer\xEAncia organizacional. Influencia DS, pol\xEDticas de produto e estrat\xE9gia regulat\xF3ria.;Refer\xEAncia organizacional de design seguro. Influencia pol\xEDticas de produto e SI.;Decis\xE3o com vis\xE3o estrat\xE9gica de longo prazo. Resolve tens\xF5es organizacionais com crit\xE9rio.;Refer\xEAncia de colabora\xE7\xE3o cross-\xE1rea. Define como Design se relaciona com Produto e Eng.;Influ\xEAncia organizacional via craft. Traduz a vis\xE3o de design em resultados de neg\xF3cio.;Respons\xE1vel pelo resultado de qualidade da disciplina. Define OKRs de excel\xEAncia.;Define prioridades estrat\xE9gicas da disciplina. Cria previsibilidade de longo prazo.;Desenvolve lideran\xE7as t\xE9cnicas. Cria cultura de aprendizado e excel\xEAncia na disciplina.;Respons\xE1vel pelo desenvolvimento da disciplina. Cria pipeline de talentos de longo prazo.;Influencia estrat\xE9gia de produto com profundidade de entendimento do usu\xE1rio.;Refer\xEAncia organizacional de conex\xE3o design-neg\xF3cio. Influ\xEAncia executiva.;Refer\xEAncia organizacional de adaptabilidade. Orienta a disciplina em momentos de mudan\xE7a.\nDesigner Especialista III;Refer\xEAncia cross-squad em discovery. Garante consist\xEAncia sist\xEAmica e orienta decis\xF5es de framing. (N5);Garante vis\xE3o de experi\xEAncia coerente entre squads e produtos. Cria padr\xF5es que escalam. (N5);Define padr\xF5es de craft cross-squad. Garante que excel\xEAncia \xE9 expectativa, n\xE3o exce\xE7\xE3o. (N3 - N4);Refer\xEAncia cross-squad em UX Writing. Garante excel\xEAncia sist\xEAmica de linguagem. (N3 - N4);Coordena cultura de valida\xE7\xE3o cross-squad. Conecta experimentos com estrat\xE9gia de produto. (N3 - N4);Garante ades\xE3o e evolu\xE7\xE3o do DS em escala. Prop\xF5e arquitetura de padr\xF5es sustent\xE1vel. (N2 - N3);Garante qualidade em produ\xE7\xE3o como padr\xE3o cross-squad. Influencia roadmap t\xE9cnico. (N4 - N5);Sistematiza uso de IA cross-squad. Define pr\xE1ticas, avalia ferramentas e garante uso respons\xE1vel. (N4 - N5);Refer\xEAncia cross-squad. Garante excel\xEAncia sist\xEAmica e conformidade de longo prazo. (N4 - N5);Refer\xEAncia cross-squad. Garante cultura de design seguro e conformidade sist\xEAmica. (N4 - N5);Decide com vis\xE3o de m\xE9dio e longo prazo. Resolve tens\xF5es entre squads com crit\xE9rio claro. (N5);Refer\xEAncia de colabora\xE7\xE3o cross-squad. Define como o time de design se relaciona com outras \xE1reas. (N5);Influ\xEAncia executiva cross-\xE1rea. Traduz craft em valor de neg\xF3cio com clareza. (N5);Respons\xE1vel pelo resultado de qualidade de m\xFAltiplos squads. Conecta desempenho com estrat\xE9gia. (N5);Define capacidade e prioridades t\xE9cnicas de m\xE9dio prazo. Cria previsibilidade cross-squad. (N4 - N5);Refer\xEAncia de desenvolvimento de pessoas pela sua especialidade. Cria cultura de excel\xEAncia e aprendizado. (N5);Atua como refer\xEAncia t\xE9cnica estrat\xE9gica, influencia a evolu\xE7\xE3o de compet\xEAncias da \xE1rea e promove uma cultura de aprendizado para o pr\xF3prio time e para outros times. (N5);Refer\xEAncia cross-tribo. Cria cultura de design orientado ao usu\xE1rio real. (N4 e N5);Refer\xEAncia cross-produtos de vis\xE3o de neg\xF3cio. Influencia agenda de produto. (N4 - N5);Refer\xEAncia cross-tribo em adaptabilidade. Cria cultura de evolu\xE7\xE3o cont\xEDnua. (N5)\nDesigner Especialista II;Define padr\xE3o de discovery para m\xFAltiplos squads. Garante consist\xEAncia e qualidade sist\xEAmica. (N4 - N5);Coordena consist\xEAncia de fluxos entre squads. Cria princ\xEDpios de experi\xEAncia cross-produto. (N4 - N5);Mant\xE9m barra de qualidade de UI cross-squad. Cria rituais e formatos de cr\xEDtica. (N3 - N4);Mant\xE9m a barra de qualidade de writing. Garante coer\xEAncia de voz e tom do produto. (N3 - N4);Mant\xE9m a barra de qualidade de fluxos naveg\xE1veis. Garante os padr\xF5es necess\xE1rios para valida\xE7\xE3o. (N3 - N4);Garante ades\xE3o ao DS em escala. Prop\xF5e evolu\xE7\xE3o baseada em padr\xF5es de uso real. (N2 - N3);Sistematiza handoff e QA em escala. Reduz incidentes de qualidade em produ\xE7\xE3o. (N3 - N4);Define estrat\xE9gia de ado\xE7\xE3o de IA para a disciplina. Orienta uso \xE9tico e eficaz. (N4 - N5);Define padr\xE3o cross-squad. Conecta acessibilidade com Design System e regula\xE7\xE3o. (N3 - N4);Define padr\xE3o cross-squad de privacidade. Conecta design com pol\xEDticas de seguran\xE7a. (N3 - N4);Define crit\xE9rios de decis\xE3o organizacionais. Resolve conflitos de prioridade entre times. (N4 - N5);Coordena alinhamento cross-squad. Remove fric\xE7\xE3o sist\xEAmica entre \xE1reas e disciplinas. (N4 - N5);Influ\xEAncia executiva consistente. Negocia prioridades e defende qualidade com dados. (N4 - N5);Acompanha resultados de m\xFAltiplos squads. Identifica padr\xF5es de sucesso e fracasso. (N4 - N5);Organiza capacidade e prioridades da disciplina. Planeja com vis\xE3o de m\xE9dio prazo. (N3 - N4);Desenvolve pessoas em escala. Cria programas de mentoria e padr\xF5es de feedback estruturado. (N4 - N5);Atua como mentor t\xE9cnico, desenvolve especialistas e dissemina boas pr\xE1ticas. Eleva o n\xEDvel de excel\xEAncia t\xE9cnica do time. (N3 - N4);Refer\xEAncia cross-squad. Cria cultura de design orientado ao usu\xE1rio real. (N3 - N4);Define como medir impacto cross-squad mesmo produto. Conecta design com estrat\xE9gia de neg\xF3cio. (N3 - N4);Define abordagem de adaptabilidade cross-squad. Conecta aprendizado com escala. (N4 - N5)\nDesigner Especialista I;Estrutura abordagem de discovery do time. Orienta framing em problemas cr\xEDticos e amb\xEDguos. (N4 - N5);Garante coer\xEAncia em fluxos cr\xEDticos do produto. Desenha fluxos ponta a ponta, define padr\xF5es de jornada e cria crit\xE9rios de qualidade para fluxos do time. (N3 - N4);Estabelece crit\xE9rios de qualidade de UI para o time. Revisa e eleva o padr\xE3o. (N3 - N4);Estabelece crit\xE9rios de qualidade de UX Writing. Garante consist\xEAncia de linguagem em escala. (N3 - N4);Estabelece crit\xE9rios de qualidade de fluxos naveg\xE1veis. Garante consist\xEAncia na valida\xE7\xE3o das jornadas. (N3 - N4);Coordena uso do DS no time. Define crit\xE9rios de ades\xE3o e prop\xF5e padr\xF5es replic\xE1veis. (N2 - N3);Define padr\xE3o de handoff e QA. Sistematiza pr\xE1ticas que reduzem retrabalho com Eng. (N2 - N3);Refer\xEAncia em IA no time. Avalia ferramentas, define pr\xE1ticas e orienta ado\xE7\xE3o respons\xE1vel. (N3 - N4);Estrutura pr\xE1ticas de acessibilidade do time. Garante conformidade regulat\xF3ria sist\xEAmica. (N2 - N3);Estrutura pr\xE1ticas de design seguro do time. Garante conformidade com SI e regula\xE7\xE3o. (N2 - N3);Decide com clareza em cen\xE1rios cr\xEDticos. Explicita crit\xE9rios e reduz incerteza para o time. (N3 - N4);Parceiro estrat\xE9gico do grupo. Influencia estrutura e din\xE2mica de colabora\xE7\xE3o no time. (N3 - N4);Influencia decis\xF5es executivas com craft e qualidade. Traduz complexidade t\xE9cnica para lideran\xE7a. (N3 - N4);Respons\xE1vel por resultados de qualidade do time/squad. Acompanha impacto e garante fechamento. (N3 - N4);Organiza capacidade t\xE9cnica do time. Prioriza com base em impacto e risco. (N2 - N3);Desenvolve pessoas pela sua especialidade. Revisa trabalho, d\xE1 feedback espec\xEDfico e cria padr\xF5es de refer\xEAncia. (N3 - N4);Compartilha conhecimento t\xE9cnico, orienta colegas em sua atua\xE7\xE3o e contribui para o desenvolvimento t\xE9cnico do time. (N2 - N3);Refer\xEAncia cross-squad. Cria cultura de design orientado ao usu\xE1rio real. (N3 - N4);Define abordagem de valor de design cross-squad no mesmo produto. Estrutura m\xE9tricas de impacto. (N3 - N4);Administra a adapta\xE7\xE3o e garante a consist\xEAncia do time em cen\xE1rios de incerteza e situa\xE7\xF5es adversas. (N3 - N4)\nDesigner S\xEAnior;Define o padr\xE3o de discovery do squad. Garante a qualidade das perguntas. Orienta e revisa o framing. (N3 - N4);Desenha fluxos ponta a ponta, define padr\xF5es de jornada e cria crit\xE9rios de qualidade para fluxos do time. (N3 - N4);Entrega UI com refinamento, consist\xEAncia sist\xEAmica mantendo a barra de qualidade de UI. Cria rotinas de cr\xEDtica e revis\xE3o. (N3 - N4);Estabelece e mant\xE9m o padr\xE3o de UX Writing do squad. Cria rotinas de cr\xEDtica e revis\xE3o de conte\xFAdo. (N3 - N4);Prototipa fluxos naveg\xE1veis e define abordagem de valida\xE7\xE3o do time. Garante que valida\xE7\xE3o vira decis\xE3o. (N3 - N4);Coordena uso e evolu\xE7\xE3o do DS no time. Garante ades\xE3o e define padr\xF5es com governan\xE7a m\xEDnima. (N2 - N3);Define padr\xE3o de handoff e QA. Coordena alinhamento com Eng. Reduz retrabalho estrutural. (N2 - N3);Refer\xEAncia em IA aplicada ao design. Orienta o time em ado\xE7\xE3o e uso cr\xEDtico das 3 dimens\xF5es. (N2 - N3);Define barra de acessibilidade. Garante conformidade BACEN/WCAG. Orienta arquitetura acess\xEDvel. (N2 - N3);Define barra de design seguro. Garante conformidade LGPD sist\xEAmica e alinha com jur\xEDdico. (N2 - N3);Decide com clareza e d\xE1 contexto para o time decidir melhor. Resolve conflitos de crit\xE9rio. (N3 - N4);Influencia e orquestra o grupo em n\xEDvel de time. Define cad\xEAncia e alinhamento. Remove fric\xE7\xE3o entre \xE1reas. (N3 - N4);Sustenta alinhamento executivo. Traduz complexidade em decis\xF5es e defende padr\xF5es. (N3 - N4);Assume problemas complexos e a responsabilidade pelo resultado do time. Acompanha m\xE9tricas e ajusta a rota com a lideran\xE7a. (N3 - N4);Planeja o trabalho e come\xE7a a organiz\xE1-lo. Cria previsibilidade das suas entregas. (N2 - N3);Desenvolve pessoas de forma intencional. D\xE1 feedback, cria rotinas de crescimento e eleva barra. (N2 - N3);Atua como refer\xEAncia t\xE9cnica, apoia o desenvolvimento dos colegas e promove o aprendizado cont\xEDnuo dentro da equipe. (N1 - N2);Usa ideias e hip\xF3teses geradas por pesquisas com clientes e usu\xE1rios, al\xE9m de dados comportamentais em contextos reais, para justificar decis\xF5es. Refer\xEAncia de empatia. (N1 - N3);Garante que o squad conecte design a resultados de neg\xF3cio de forma consistente. (N2 - N3);Garante que o squad aprenda e evolua mesmo diante da diversidade de temas e incertezas. (N2 - N3)\nDesigner Pleno;Conduz discovery com consist\xEAncia e profundidade. Antecipa gaps e conecta achados a decis\xF5es. (N2 - N3);Desenha fluxos ponta a ponta. Antecipa impactos e inconsist\xEAncias antes de acontecerem. (N2 - N3);Entrega UI com refinamento e consist\xEAncia sist\xEAmica. Com autonomia (N2 - N3);Garante consist\xEAncia de linguagem em fluxos ponta a ponta. Com autonomia (N2 - N3);Prototipa fluxos naveg\xE1veis e valida com m\xE9todo s\xF3lido e autonomia. Interpreta resultados e os transforma em ajustes de dire\xE7\xE3o. (N2 - N3);Usa DS com profici\xEAncia total. Contribui ativamente com sugest\xF5es de padr\xE3o replic\xE1veis. (N1 - N2);Faz handoff completo com antecipa\xE7\xE3o de d\xFAvidas. Conduz QA com crit\xE9rio. (N1 - N2);Usa IA com profici\xEAncia em processo e prompting. Come\xE7a a aplicar IA em problemas de produto. (N1 - N2);Acessibilidade como crit\xE9rio padr\xE3o. Resolve edge cases e exce\xE7\xF5es. Refer\xEAncia no squad. (N1 - N2);Refer\xEAncia de design seguro no squad. Garante conformidade LGPD em escopos cr\xEDticos. (N1 - N2);Explicita trade-offs e escolhe caminhos com base em impacto, risco e esfor\xE7o. (N2 - N3);Opera como parceiro forte no grupo. Antecipa depend\xEAncias e influencia roadmap do squad. (N2 - N3);Apresenta racional com clareza para stakeholders. Influencia sem confrontar. (N2 - N3);Acompanha impacto e garante fechamento de ciclos. (N2 - N3);Planeja o trabalho e come\xE7a a organiz\xE1-lo. Cria previsibilidade das suas entregas. (N1 - N2);Revisa trabalho, compartilha aprendizados, m\xE9todo e d\xE1 feedback \xFAtil no time. (N1 - N2);- N\xE3o observado;Usa ideias e hip\xF3teses geradas por pesquisas com clientes e usu\xE1rios, al\xE9m de dados comportamentais em contextos reais, para justificar decis\xF5es. Refer\xEAncia de empatia. (N1 - N3);Conecta a solu\xE7\xE3o de design com o resultado de neg\xF3cio. Colabora na prioriza\xE7\xE3o com dados. (N2 - N3);Adapta abordagem conforme contexto muda. Gerencia incerteza e mant\xE9m qualidade. (N2 - N3)\nDesigner Junior;Executa partes do discovery com suporte reduzido. Organiza problem statements e hip\xF3teses com revis\xE3o. (N1 - N2);Desenha fluxos b\xE1sicos com mais autonomia. Cobre os casos principais e alguns casos simples. (N1 - N2);Entrega UI consistente com suporte em escopos definidos. Reduz retrabalho. (N1 - N2);Escreve microcopy com consist\xEAncia crescente em escopos definidos. Aplica padr\xF5es com menos retrabalho. (N1 - N2);Prototipa fluxos naveg\xE1veis simples com autonomia. Valida com apoio e ajusta com base em feedback. (N1 - N2);Usa DS com consist\xEAncia em escopos rotineiros. Documenta d\xFAvidas sobre padr\xF5es. (N1 - N2);Faz handoff com menos revis\xE3o. Cobre estados principais com orienta\xE7\xE3o. (N1);Usa ferramentas de IA com autonomia b\xE1sica no fluxo de trabalho. Escreve prompts funcionais. (N1 - N2);Verifica acessibilidade em entregas com autonomia. Testa com ferramentas b\xE1sicas (axe, Figma a11y). (N1);Projeta fluxos com exposi\xE7\xE3o m\xEDnima de dados. Implementa microcopies de consentimento com apoio. (N1 - N2);Decide com mais seguran\xE7a em escopo pequeno. Pede apoio em cen\xE1rios novos. (N1 - N2);Colabora bem em tarefas rotineiras. Come\xE7a a negociar escopo com suporte. (N1 - N2);Comunica progresso e bloqueios com clareza. Evolui em apresenta\xE7\xF5es simples. (N1 - N2);Assume entregas com suporte. Acompanha resultado de forma b\xE1sica. (N1 - N2);Organiza tarefas com consist\xEAncia. Ajusta quando h\xE1 mudan\xE7a de contexto. (N1 - N2);Tem abertura para aprender, busca feedback e assume protagonismo no seu autodesenvolvimento. (N1 - N2);- N\xE3o observado;Usa ideias e hip\xF3teses geradas por pesquisas com clientes e usu\xE1rios, al\xE9m de dados comportamentais em contextos reais, para justificar decis\xF5es. Refer\xEAncia de empatia. (N1 - N3);Usa m\xE9tricas para justificar decis\xF5es simples. Entende OKRs do squad com apoio. (N1 - N2);Opera em mudan\xE7as pequenas com autonomia. Mant\xE9m entregas em escopos predeterminados. (N1 - N2)\n";

  // raw-text:/Users/renatosilvestre/Desktop/Report_Skill/Skill Mapping/src/data/specialization-designops.csv
  var specialization_designops_default = "HARD SKILLS \u2014 Compet\xEAncias T\xE9cnicas de Design (H1\u2013H10);;;;;\r\nContentOps;Visual;DesignOps;ID;Nome da Capability;Defini\xE7\xE3o Operacional\r\n;;X;H1;Discovery e framing de problema;Capacidade de investigar contextos de uso, identificar problemas reais, formular hip\xF3teses e estruturar problem statements que orientem o trabalho de design. Inclui conhecimento de t\xE9cnicas de discovery, an\xE1lise de dados e s\xEDntese em artefatos acion\xE1veis (jobs-to-be-done, opportunity maps, problem briefs).\r\n;;;H2;Estrat\xE9gia de experi\xEAncia e fluxos;Capacidade de desenhar, manter e evoluir fluxos de experi\xEAncia end-to-end, garantindo coer\xEAncia entre touchpoints, consist\xEAncia de jornada, antecipa\xE7\xE3o de edge cases e defini\xE7\xE3o dos recortes de MVP e evolu\xE7\xF5es. Inclui arquitetura de informa\xE7\xE3o, service blueprints e journey maps.\r\n;X;;H3;UI e craft (qualidade visual e intera\xE7\xE3o);Dom\xEDnio da qualidade visual e de intera\xE7\xE3o \u2014 grid, hierarquia tipogr\xE1fica, sistema de cores, motion design, micro-intera\xE7\xF5es e polimento final de interface. Inclui precis\xE3o de design, aten\xE7\xE3o ao detalhe e capacidade de elevar a barra de craft.\r\nX;;X;H4;UX Writing e conte\xFAdo de interface;Capacidade de escrever textos de interface claros, \xFAteis e consistentes \u2014 microcopy, textos conversacionais, mensagens de erro, textos de onboarding, tooltips, CTAs e tom de voz. Inclui governan\xE7a de linguagem e padr\xF5es de escrita escal\xE1veis garantindo consist\xEAncia de linguagem.\r\nX;X;X;H5;Valida\xE7\xE3o para decis\xE3o;Capacidade de transformar hip\xF3teses em artefatos test\xE1veis (prot\xF3tipo naveg\xE1vel) e usar valida\xE7\xE3o (testes de usabilidade, A/B tests, concept tests) para reduzir risco e informar decis\xF5es de produto. Inclui escolha de fidelidade adequada ao objetivo.\r\nX;X;X;H6;Design System e escalabilidade;Capacidade de usar, contribuir e governar o Design System \u2014 componentes, tokens, patterns, documenta\xE7\xE3o e processos de ado\xE7\xE3o. Inclui pensamento de escalabilidade, cria\xE7\xE3o de team componentes e reutiliza\xE7\xE3o para garantir consist\xEAncia cross-produto.\r\n;X;X;H7;Handoff, implementa\xE7\xE3o e qualidade em produ\xE7\xE3o;Capacidade de especificar, comunicar e acompanhar a implementa\xE7\xE3o de design at\xE9 a produ\xE7\xE3o com qualidade. Inclui specs detalhadas, regras de aplica\xE7\xE3o, QA de design, resolu\xE7\xE3o de gaps implementa\xE7\xE3o-design e crit\xE9rios de aceite visual.\r\nX;X;X;H8;IA aplicada ao design;Capacidade de usar intelig\xEAncia artificial como ferramenta de acelera\xE7\xE3o do processo de design e conte\xFAdo (prompting, s\xEDntese, gera\xE7\xE3o de varia\xE7\xF5es) e de projetar experi\xEAncias que integram IA como capability do produto.\r\nX;;X;H9;Acessibilidade digital e design inclusivo;Capacidade de projetar interfaces acess\xEDveis conforme WCAG 2.1+, testar com tecnologias assistivas e garantir que produtos financeiros sejam utiliz\xE1veis por pessoas com defici\xEAncia. Inclui conformidade regulat\xF3ria (Lei 13.146/2015).\r\nX;;X;H10;Design seguro e privacidade by design;Capacidade de projetar fluxos com seguran\xE7a e privacidade integradas \u2014 autentica\xE7\xE3o, exposi\xE7\xE3o m\xEDnima de dados, microcopys LGPD, preven\xE7\xE3o de dark patterns e alinhamento com Seguran\xE7a Corporativa e Compliance.\r\n;;;;;\r\n;;;;;\r\n;;;;;\r\n;;;;;\r\n;;;;;\r\n;;;;;\r\n;;;;;\r\n;;;;;\r\n;;;;;\r\n;;;;;\r\n;;;;;\r\n;;;;;";

  // raw-text:/Users/renatosilvestre/Desktop/Report_Skill/Skill Mapping/src/data/specialization-ux.csv
  var specialization_ux_default = "HARD SKILLS \u2014 Compet\xEAncias T\xE9cnicas de Design (H1\u2013H10);;;;;\r\nPD;CD2;SD;ID;Nome da Capability;Defini\xE7\xE3o Operacional\r\nX;X;X;H1;Discovery e framing de problema;Capacidade de investigar contextos de uso, identificar problemas reais, formular hip\xF3teses e estruturar problem statements que orientem o trabalho de design. Inclui conhecimento de t\xE9cnicas de discovery, an\xE1lise de dados e s\xEDntese em artefatos acion\xE1veis (jobs-to-be-done, opportunity maps, problem briefs).\r\nX;;X;H2;Estrat\xE9gia de experi\xEAncia e fluxos;Capacidade de desenhar, manter e evoluir fluxos de experi\xEAncia end-to-end, garantindo coer\xEAncia entre touchpoints, consist\xEAncia de jornada, antecipa\xE7\xE3o de edge cases e defini\xE7\xE3o dos recortes de MVP e evolu\xE7\xF5es. Inclui arquitetura de informa\xE7\xE3o, service blueprints e journey maps.\r\nX;;;H3;UI e craft (qualidade visual e intera\xE7\xE3o);Dom\xEDnio da qualidade visual e de intera\xE7\xE3o \u2014 grid, hierarquia tipogr\xE1fica, sistema de cores, motion design, micro-intera\xE7\xF5es e polimento final de interface. Inclui precis\xE3o de design, aten\xE7\xE3o ao detalhe e capacidade de elevar a barra de craft.\r\nX;X;;H4;UX Writing e conte\xFAdo de interface;Capacidade de escrever textos de interface claros, \xFAteis e consistentes \u2014 microcopy, textos conversacionais, mensagens de erro, textos de onboarding, tooltips, CTAs e tom de voz. Inclui governan\xE7a de linguagem e padr\xF5es de escrita escal\xE1veis garantindo consist\xEAncia de linguagem.\r\nX;X;X;H5;Valida\xE7\xE3o para decis\xE3o;Capacidade de transformar hip\xF3teses em artefatos test\xE1veis (prot\xF3tipo naveg\xE1vel) e usar valida\xE7\xE3o (testes de usabilidade, A/B tests, concept tests) para reduzir risco e informar decis\xF5es de produto. Inclui escolha de fidelidade adequada ao objetivo.\r\nX;X;;H6;Design System e escalabilidade;Capacidade de usar, contribuir e governar o Design System \u2014 componentes, tokens, patterns, documenta\xE7\xE3o e processos de ado\xE7\xE3o. Inclui pensamento de escalabilidade, cria\xE7\xE3o de team componentes e reutiliza\xE7\xE3o para garantir consist\xEAncia cross-produto.\r\nX;;X;H7;Handoff, implementa\xE7\xE3o e qualidade em produ\xE7\xE3o;Capacidade de especificar, comunicar e acompanhar a implementa\xE7\xE3o de design at\xE9 a produ\xE7\xE3o com qualidade. Inclui specs detalhadas, regras de aplica\xE7\xE3o, QA de design, resolu\xE7\xE3o de gaps implementa\xE7\xE3o-design e crit\xE9rios de aceite visual.\r\nX;X;X;H8;IA aplicada ao design;Capacidade de usar intelig\xEAncia artificial como ferramenta de acelera\xE7\xE3o do processo de design e conte\xFAdo (prompting, s\xEDntese, gera\xE7\xE3o de varia\xE7\xF5es) e de projetar experi\xEAncias que integram IA como capability do produto.\r\n;;;H9;Acessibilidade digital e design inclusivo;Capacidade de projetar interfaces acess\xEDveis conforme WCAG 2.1+, testar com tecnologias assistivas e garantir que produtos financeiros sejam utiliz\xE1veis por pessoas com defici\xEAncia. Inclui conformidade regulat\xF3ria (Lei 13.146/2015).\r\n;;;H10;Design seguro e privacidade by design;Capacidade de projetar fluxos com seguran\xE7a e privacidade integradas \u2014 autentica\xE7\xE3o, exposi\xE7\xE3o m\xEDnima de dados, microcopys LGPD, preven\xE7\xE3o de dark patterns e alinhamento com Seguran\xE7a Corporativa e Compliance.\r\n;;;;;\r\n;;;;;\r\n;;;;;\r\n;;;;;\r\n;;;;;\r\n;;;;;\r\n;;;;;\r\n;;;;;\r\n;;;;;\r\n;;;;;\r\n;;;;;\r\n;;;;;\r\n;;;;;";

  // raw-text:/Users/renatosilvestre/Desktop/Report_Skill/Skill Mapping/public/data/cursos.csv
  var cursos_default = 'ID;Capabilidade / Trilha;Objetivo da trilha;Resultado esperado ao concluir;N\xEDvel recomendado;Conex\xE3o Sou Bradesco e Carreira;Curso (Op\xE7\xE3o 1);Link 1;Curso (Op\xE7\xE3o 2);Link 2;Curso (Op\xE7\xE3o 3);Link 3\r\nH1;H1 - Discovery e framing de problema;Desenvolver a capacidade de investigar contextos de uso, identificar problemas relevantes dos usu\xE1rios e do neg\xF3cio, formular hip\xF3teses e estruturar problem statements que orientem decis\xF5es de design e produto com clareza e foco.;Investiga contextos de uso, identifica problemas relevantes, formula hip\xF3teses e transforma descobertas em oportunidades claras para direcionar decis\xF5es de design e produto.;J\xFAnior+;Diferenciador cr\xEDtico entre J\xFAnior (executa partes) e S\xEAnior+ (conduz ponta a ponta). Especialistas definem m\xE9todo e influenciam estrat\xE9gia de produto.;Forma\xE7\xE3o completa de Gest\xE3o de Produtos ;https://cursos.alura.com.br/formacao-gestao-produtos;Product Design: realizando o processo de Product Discovery;https://www.alura.com.br/curso-online-product-design-processo-product-discovery;;\r\nH2;H2 - Estrat\xE9gia de experi\xEAncia e fluxos;Capacitar profissionais a desenhar e evoluir experi\xEAncias end-to-end, estruturando jornadas, fluxos e arquiteturas de informa\xE7\xE3o que garantam consist\xEAncia, efici\xEAncia e alinhamento entre necessidades do cliente e objetivos do neg\xF3cio.;Estrutura jornadas, fluxos e arquiteturas de informa\xE7\xE3o de forma consistente, considerando necessidades do usu\xE1rio, objetivos do neg\xF3cio e restri\xE7\xF5es do contexto.;J\xFAnior+;Plenos ganham autonomia em fluxos de m\xE9dia complexidade. Seniores e acima definem estrat\xE9gias de experi\xEAncia que cruzam squads e canais.;Forma\xE7\xE3o completa de Arquitetura da Informa\xE7\xE3o;https://cursos.alura.com.br/formacao-arquitetura-informacao;Arquitetura da Informa\xE7\xE3o: t\xE9cnicas de pesquisa para projetar experi\xEAncias digitais;https://www.alura.com.br/curso-online-arquitetura-informacao-tecnicas-pesquisa-experiencias-digitais/;Service Design: criando o Blueprint de servi\xE7o digital;https://www.alura.com.br/curso-online-service-design-blueprint-servico-digital/\r\nH3;H3 - UI e craft (qualidade visual e intera\xE7\xE3o);Aprimorar a qualidade visual e de intera\xE7\xE3o das interfaces, desenvolvendo dom\xEDnio sobre princ\xEDpios de design visual, sistemas de interface, microintera\xE7\xF5es e refinamento de experi\xEAncias digitais de alta qualidade.;Produz interfaces visualmente consistentes, acess\xEDveis e bem refinadas, aplicando boas pr\xE1ticas de design visual, intera\xE7\xE3o e aten\xE7\xE3o aos detalhes.;J\xFAnior+;Skill t\xE9cnico diferenciador na trilha IC (Especialista). Excel\xEAncia em craft \xE9 requisito para elevar barra do time e ganhar influ\xEAncia t\xE9cnica.;Design Visual na Pr\xE1tica;https://cursos.alura.com.br/formacao-design-visual-pratica;UX/UI Design: Estrat\xE9gia, cria\xE7\xE3o e prototipa\xE7\xE3o com IA;https://cursos.alura.com.br/course/estrategia-criacao-prototipacao-ia;Masterclass Figma: do zero \xE0 cria\xE7\xE3o de uma Landing Page;https://cursos.alura.com.br/course/masterclass-figma-criacao-landing-page\r\nH4;H4 - UX Writing e conte\xFAdo de interface;Desenvolver a capacidade de criar conte\xFAdos de interface claros, consistentes e \xFAteis, estabelecendo padr\xF5es de linguagem que melhorem a experi\xEAncia do usu\xE1rio e fortale\xE7am a comunica\xE7\xE3o dos produtos digitais.;Cria conte\xFAdos claros, objetivos e alinhados ao contexto de uso, contribuindo para experi\xEAncias mais intuitivas e compreens\xEDveis para os usu\xE1rios.;J\xFAnior+;"Habilidade transversal que matura com senioridade. Seniores integram writing ao craft; Especialistas definem padr\xF5es de voz e tom.";Forma\xE7\xE3o UX Writing;https://www.alura.com.br/formacao-ux-writing;;;;\r\nH5;H5 - Prototipa\xE7\xE3o e valida\xE7\xE3o para decis\xE3o;Capacitar profissionais a transformar hip\xF3teses em experimentos e prot\xF3tipos test\xE1veis, utilizando m\xE9todos de valida\xE7\xE3o para reduzir riscos, gerar evid\xEAncias e apoiar decis\xF5es de design e produto.;Planeja e executa atividades de valida\xE7\xE3o adequadas ao contexto, utilizando evid\xEAncias para reduzir riscos e apoiar decis\xF5es de produto e design.;J\xFAnior+;"Juniores aprendem o m\xE9todo; Plenos executam com autonomia; Seniores definem o que e como validar; Principals criam frameworks de valida\xE7\xE3o.";Figma: Interatividade e prototipa\xE7\xE3o;https://www.alura.com.br/curso-online-figma-interatividade-prototipacao;forma\xE7\xE3o completa de Figma;https://cursos.alura.com.br/formacao-figma;;\r\nH6;H6 - Consist\xEAncia e padr\xF5es de interface (uso do Design System);Desenvolver compet\xEAncias para utilizar, contribuir e evoluir Design Systems, promovendo consist\xEAncia, reutiliza\xE7\xE3o e escalabilidade nas experi\xEAncias digitais da organiza\xE7\xE3o.;Utiliza e contribui para Design Systems de forma eficiente, promovendo consist\xEAncia, reutiliza\xE7\xE3o e escalabilidade das solu\xE7\xF5es digitais.;Pleno+;Skill t\xE9cnico estrat\xE9gico para a trilha IC. Especialistas s\xE3o refer\xEAncia de DS e podem governar DS cross-BU.;Design System: definindo estilos e tokens;https://www.alura.com.br/curso-online-design-system-definindo-estilos-tokens;Figma: cria\xE7\xE3o de componentes;https://www.alura.com.br/curso-online-figma-criacao-componentes;Praticando Figma: Design System;https://cursos.alura.com.br/course/praticando-figma-design-system\r\nH7;H7 - Handoff, implementa\xE7\xE3o e qualidade em produ\xE7\xE3o;Fortalecer a capacidade de especificar, comunicar e acompanhar implementa\xE7\xF5es, garantindo alinhamento entre design e desenvolvimento e assegurando qualidade da experi\xEAncia entregue em produ\xE7\xE3o.;Documenta solu\xE7\xF5es, colabora com equipes de desenvolvimento e acompanha implementa\xE7\xF5es para garantir ader\xEAncia ao design proposto e qualidade na entrega.;Pleno+;"Skill pragm\xE1tico que matura com experi\xEAncia de entrega real. Seniores dominam QA; Especialistas definem processo."; Curso Praticando Figma: Handoff;https://cursos.alura.com.br/course/praticando-figma-handoff;Figma: Cria\xE7\xE3o de componentes;https://www.alura.com.br/curso-online-figma-criacao-componentes;;\r\nH8;H8 - IA aplicada ao design;Capacitar profissionais a utilizar intelig\xEAncia artificial para acelerar atividades de design, pesquisa e conte\xFAdo, al\xE9m de compreender como projetar experi\xEAncias digitais que incorporem recursos de IA de forma estrat\xE9gica.;Utiliza recursos de intelig\xEAncia artificial para potencializar atividades de design, pesquisa, conte\xFAdo e experimenta\xE7\xE3o, ampliando produtividade e qualidade das entregas.;Pleno+;Skill emergente que diferencia designers adapt\xE1veis. Plenos+ que dominam IA ganham vantagem significativa em velocidade e escopo.;UX/UI Design: Estrat\xE9gia, cria\xE7\xE3o e prototipa\xE7\xE3o com IA;https://cursos.alura.com.br/course/estrategia-criacao-prototipacao-ia;;;;\r\nH9;H9 - Acessibilidade digital e design inclusivo;Desenvolver a capacidade de projetar experi\xEAncias digitais acess\xEDveis e inclusivas, aplicando padr\xF5es reconhecidos de acessibilidade e promovendo a participa\xE7\xE3o de diferentes perfis de usu\xE1rios.;Projeta solu\xE7\xF5es digitais mais inclusivas e acess\xEDveis, aplicando diretrizes e pr\xE1ticas que ampliam o acesso e a equidade de uso.;Pleno+;"Expectativa crescente com senioridade. Seniores garantem a11y no squad; Especialistas lideram compliance e definem pol\xEDtica.";Acessibilidade Digital;https://www.alura.com.br/formacao-acessibilidade-digital;;;;\r\nH10;H10 - Design seguro e privacidade by design;Capacitar profissionais a incorporar princ\xEDpios de seguran\xE7a, privacidade e conformidade regulat\xF3ria no processo de design, criando experi\xEAncias que protejam usu\xE1rios e dados desde sua concep\xE7\xE3o.;Considera requisitos de privacidade, seguran\xE7a e conformidade desde a concep\xE7\xE3o das experi\xEAncias, minimizando riscos para usu\xE1rios e organiza\xE7\xE3o.;Pleno+;"Skill setorial cr\xEDtico para Bradesco. Seniores garantem conformidade; Especialistas auditam e definem padr\xE3o regulat\xF3rio-design.";LGPD: conhecendo a legisla\xE7\xE3o para proteger dados pessoais;https://www.alura.com.br/curso-online-lgpd-conhecendo-legislacao-proteger-dados-pessoais;Ciberseguran\xE7a: Fundamentos e pr\xE1ticas integradas;https://www.alura.com.br/curso-online-ciberseguranca-fundamentos-praticas-integradas;;\r\nS1;S1 - Tomada de decis\xE3o e trade-offs;Desenvolver a capacidade de utilizar dados qualitativos e quantitativos para fundamentar decis\xF5es, avaliar trade-offs e conectar solu\xE7\xF5es de design a resultados concretos para usu\xE1rios e neg\xF3cio.;Utiliza dados e evid\xEAncias para embasar decis\xF5es, avaliar resultados e demonstrar o impacto das iniciativas realizadas.;Pleno+;#ObstinadosPorResultados \u2014 conecta design a resultados mensur\xE1veis. Diferenciador para transi\xE7\xE3o Pleno\u2192S\xEAnior.;Product Manager: uma jornada em gest\xE3o de produto;https://www.alura.com.br/curso-online-product-manager-jornada-gestao-produto;;;;\r\nS2;S2 - Colabora\xE7\xE3o no Grupo com Vis\xE3o do Todo;Fortalecer a capacidade de atuar de forma colaborativa em equipes multidisciplinares, promovendo alinhamento entre diferentes \xE1reas e equilibrando necessidades dos usu\xE1rios, do neg\xF3cio e da tecnologia.;Atua de forma colaborativa em equipes multidisciplinares, promovendo alinhamento entre diferentes perspectivas e objetivos comuns.;J\xFAnior+;#UnidosEvolu\xEDmos \u2014 trabalho em parceria como princ\xEDpio. Skill cr\xEDtica para Pleno+ e especialmente para trilha TL/Gest\xE3o.;Gest\xE3o de Stakeholders e Influ\xEAncia na Comunica\xE7\xE3o;https://www.alura.com.br/curso-online-gestao-stakeholders-influencia-comunicacao;;;;\r\nS3;S3 - Comunica\xE7\xE3o e influ\xEAncia com stakeholders;Desenvolver habilidades de comunica\xE7\xE3o estrat\xE9gica, storytelling e influ\xEAncia, permitindo defender decis\xF5es de design e engajar stakeholders em diferentes contextos organizacionais.;Comunica ideias, decis\xF5es e recomenda\xE7\xF5es com clareza, adaptando a mensagem para diferentes p\xFAblicos e contextos organizacionais.;J\xFAnior+;#SomosPelasPessoas \u2014 comunica\xE7\xE3o emp\xE1tica e construtiva. Skill diferenciadora para cargos de lideran\xE7a (Coordenador+).;Gest\xE3o de Stakeholders e Influ\xEAncia na Comunica\xE7\xE3o;https://www.alura.com.br/curso-online-gestao-stakeholders-influencia-comunicacao;;;;\r\nS4;S4 - Senso de Dono e Responsabilidade por Outcomes;Estimular a responsabiliza\xE7\xE3o por resultados gerados pelas solu\xE7\xF5es entregues, promovendo acompanhamento cont\xEDnuo de impacto, aprendizado e evolu\xE7\xE3o dos produtos.;Assume responsabilidade pelos resultados gerados, acompanhando indicadores e promovendo melhorias cont\xEDnuas ap\xF3s as entregas.;Pleno+;#ObstinadosPorResultados \u2014 resultado acima de entrega. Requisito para transi\xE7\xE3o Pleno \u2192S\xEAnior.;Gest\xE3o de produtos digitais: Produto vs. Projeto;https://cursos.alura.com.br/course/gestao-produtos-digitais-produto-vs-projeto;Gest\xE3o de produtos digitais: acelera\xE7\xE3o;https://cursos.alura.com.br/course/gestao-produtos-aceleracao;Gest\xE3o de produtos digitais: valida\xE7\xE3o;https://cursos.alura.com.br/course/gestao-produtos-digitais-validacao\r\nS5;S5 - Planejamento. prioriza\xE7\xE3o. previsibilidade;Capacitar profissionais a organizar demandas, priorizar iniciativas e gerir expectativas, aumentando previsibilidade e efici\xEAncia na execu\xE7\xE3o do trabalho.;Organiza demandas, define prioridades e gerencia expectativas de forma estruturada, contribuindo para maior previsibilidade das entregas.;Pleno+;#OrientadosADesafios \u2014 operar com consist\xEAncia sob press\xE3o. Skill operacional que habilita confian\xE7a para escopo maior.;OKR: construindo metas \xE1geis;https://cursos.alura.com.br/course/okr-construindo-metas-ageis;OKR: direcionando seu neg\xF3cio para resultados;https://cursos.alura.com.br/course/okr-direcionando-negocio-resultados;;\r\nS6;S6 - Lideran\xE7a e Eleva\xE7\xE3o de Barra;Desenvolver a capacidade de influenciar positivamente o ambiente de trabalho por meio do exemplo, compartilhamento de conhecimento e promo\xE7\xE3o cont\xEDnua da excel\xEAncia em design.;Influencia positivamente a qualidade das entregas e das pr\xE1ticas do time, compartilhando conhecimento e incentivando a excel\xEAncia profissional.;S\xEAnior+;#UmTimeEmpoderado \u2014 elevar o time pelo exemplo. Skill principal da trilha IC (Especialista).;Tech Lead: desenvolvendo habilidades de comunica\xE7\xE3o;https://cursos.alura.com.br/course/tech-lead-desenvolvendo-habilidades-comunicacao;Tech Lead: lideran\xE7a t\xE9cnica e alinhamento entre engenharia e neg\xF3cio;https://cursos.alura.com.br/course/techlead-lideranca-tecnica;;\r\nS7;S7 - Desenvolvimento de pessoas e gest\xE3o de crescimento;Preparar profissionais para apoiar o desenvolvimento de outras pessoas por meio de feedbacks, mentorias e pr\xE1ticas estruturadas de acompanhamento de carreira e evolu\xE7\xE3o profissional.;Apoia o desenvolvimento de outras pessoas por meio de feedbacks, orienta\xE7\xF5es e pr\xE1ticas que incentivam aprendizado e evolu\xE7\xE3o profissional.;S\xEAnior+;#SomosPelasPessoas \xB7 #UnidosEvolu\xEDmos \u2014 investir em pessoas. Skill principal da trilha TL (Coordenador/Gerente). Ativa a partir de S\xEAnior.;Feedback efetivo: utilizando ferramentas para comunica\xE7\xE3o transformadora;https://cursos.alura.com.br/course/feedback-efetivo-ferramentas-comunicacao-transformadora;A pr\xE1tica do aprendizado;https://cursos.alura.com.br/course/pratica-aprendizado;;\r\nS8;S8 - Empatia com usu\xE1rio e centragem no cliente;Fortalecer a capacidade de compreender profundamente os contextos, necessidades e comportamentos dos usu\xE1rios, promovendo uma cultura genuinamente centrada no cliente.;Demonstra compreens\xE3o consistente das necessidades, comportamentos e expectativas dos usu\xE1rios ao orientar decis\xF5es e solu\xE7\xF5es.;J\xFAnior+;#SomosPelosClientes \u2014 o cliente no centro de tudo. Skill transversal que matura com exposi\xE7\xE3o e experi\xEAncia.;Customer Success: cultura centrada em cliente;https://cursos.alura.com.br/course/customer-success-cultura-centrada-cliente;UX Design: Cria\xE7\xE3o de personas;https://cursos.alura.com.br/course/ux-design-construir-persona;User Research MethodsDesign Thinking: resolva problemas com inova\xE7\xE3o e colabora\xE7\xE3o;https://www.alura.com.br/curso-online-design-thinking-resolva-problemas-inovacao-colaboracao\r\nS9;S9 - Vis\xE3o de neg\xF3cio e conex\xE3o com impacto;Desenvolver entendimento sobre estrat\xE9gia, m\xE9tricas e modelos de neg\xF3cio, conectando decis\xF5es de design aos objetivos organizacionais e \xE0 gera\xE7\xE3o de valor.;Relaciona decis\xF5es de design aos objetivos estrat\xE9gicos, indicadores e resultados do neg\xF3cio, ampliando a gera\xE7\xE3o de valor para a organiza\xE7\xE3o.;Pleno+;#ObstinadosPorResultados \xB7 #SomosPelosClientes \u2014 impacto real. Requisito para S\xEAnior+ e para trilha Gest\xE3o.;Product Design: m\xE9tricas e ciclo de vida do produto;https://cursos.alura.com.br/course/product-design-metricas-ciclo-vida-produto;;;;\r\nS10;S10 - Adaptabilidade, aprendizado cont\xEDnuo e gest\xE3o da incerteza;Capacitar profissionais a responder de forma eficaz a mudan\xE7as, aprender continuamente e atuar com confian\xE7a em cen\xE1rios complexos e de alta incerteza.;Adapta-se a novas demandas, contextos e tecnologias, mantendo aprendizado cont\xEDnuo e capacidade de atua\xE7\xE3o em cen\xE1rios de mudan\xE7a.;Todos;#OrientadosADesafios \u2014 abra\xE7ar a incerteza como oportunidade. Meta-compet\xEAncia transversal que habilita crescimento em todas as trilhas.;Design Organizacional: enfrentando mudan\xE7as com m\xE9todos \xE1geis;https://cursos.alura.com.br/course/design-organizacional-enfrentando-mudancas-metodos-ageis;Aprender a aprender: t\xE9cnicas para seu autodesenvolvimento;https://cursos.alura.com.br/course/aprender-a-aprender-tecnicas-para-seu-autodesenvolvimento;Aprendizado cont\xEDnuo: desenvolvendo o perfil de lifelong learner;https://cursos.alura.com.br/course/aprendizado-continuo-desenvolvendo-perfil-lifelong-learner';

  // ../../src/domain/specializationApplicability.ts
  var DEFAULT_SOFT_SKILL_POLICY_SOURCE = "pol\xEDtica-padr\xE3o:soft-skills-core";
  function includeDefaultSoftSkillApplicability(relationships, specializationIds) {
    const result = [...relationships];
    const existing = new Set(
      relationships.map(
        (item) => `${item.specializationId}:${item.capabilityId}`
      )
    );
    for (const specializationId of [...new Set(specializationIds)]) {
      for (const capabilityId of SOFT_CAPS) {
        const relationshipKey = `${specializationId}:${capabilityId}`;
        if (existing.has(relationshipKey)) continue;
        existing.add(relationshipKey);
        result.push({
          capabilityId,
          specializationId,
          applicable: true,
          sourceFile: DEFAULT_SOFT_SKILL_POLICY_SOURCE
        });
      }
    }
    return result;
  }

  // ../../src/parsers/parseCapabilities.ts
  var import_papaparse = __toESM(require_papaparse_min(), 1);
  function parseDescritivoSkill(raw) {
    const result = import_papaparse.default.parse(raw, { skipEmptyLines: true });
    const rows = result.data;
    const capabilities = [];
    const diagnosticos = [];
    const capPattern = /^[HS]\d{1,2}$/;
    const seenIds = /* @__PURE__ */ new Set();
    for (const row of rows) {
      let id = "", nomeIdx = -1, defIdx = -1;
      for (let i = 0; i < Math.min(row.length, 4); i++) {
        const val = row[i]?.trim();
        if (val && capPattern.test(val)) {
          id = val;
          nomeIdx = i + 1;
          defIdx = i + 2;
          break;
        }
      }
      if (!id) continue;
      const nome = row[nomeIdx]?.trim() ?? "";
      if (!nome) {
        diagnosticos.push({ severity: "aviso", categoria: "Descritivo", mensagem: `${id} sem nome \u2014 ignorado` });
        continue;
      }
      if (seenIds.has(id)) {
        diagnosticos.push({ severity: "aviso", categoria: "Descritivo", mensagem: `ID duplicado: ${id}` });
        continue;
      }
      seenIds.add(id);
      capabilities.push({
        id,
        nome,
        tipo: id.startsWith("H") ? "Hard Skill" : "Soft Skill",
        definicao: row[defIdx]?.trim() ?? ""
      });
    }
    for (const capId of ALL_CAPS) {
      if (!seenIds.has(capId))
        diagnosticos.push({ severity: "aviso", categoria: "Descritivo", mensagem: `${capId} ausente no Descritivo` });
    }
    return { capabilities, diagnosticos };
  }

  // ../../src/parsers/parseCapabilityExpectations.ts
  var import_papaparse2 = __toESM(require_papaparse_min(), 1);
  function toSlug(s) {
    return s.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
  }
  function parseNivelRefs(text) {
    const found = /* @__PURE__ */ new Set();
    for (const m of text.matchAll(/\bN([1-5])\b/g)) found.add(`N${m[1]}`);
    return Array.from(found).sort();
  }
  function parseMatrizCapabilidades(raw) {
    const result = import_papaparse2.default.parse(raw, { delimiter: ";", skipEmptyLines: false });
    const rows = result.data;
    const diagnosticos = [];
    if (rows.length < 2) {
      diagnosticos.push({ severity: "erro", categoria: "Matriz", mensagem: "Arquivo insuficiente \u2014 menos de 2 linhas" });
      return { cargos: [], expectations: [], diagnosticos };
    }
    const headerRow = rows[0];
    const colCapMap = {};
    const capHeaderPat = /^\s*([HS](?:10|[1-9]))\b/i;
    for (let i = 1; i < headerRow.length; i++) {
      const cell = headerRow[i]?.trim();
      if (!cell) continue;
      const m = cell.match(capHeaderPat);
      if (m) {
        const capId = m[1].toUpperCase();
        if (ALL_CAPS.includes(capId)) {
          colCapMap[i] = capId;
        } else {
          diagnosticos.push({ severity: "aviso", categoria: "Matriz", mensagem: `Coluna com ID desconhecido: "${cell}"` });
        }
      } else {
        diagnosticos.push({ severity: "aviso", categoria: "Matriz", mensagem: `Coluna ignorada: "${cell}"` });
      }
    }
    const cargos = [];
    const expectations = [];
    const seenCargos = /* @__PURE__ */ new Set();
    for (let i = 1; i < rows.length; i++) {
      const row = rows[i];
      if (row.every((c) => !c?.trim())) continue;
      const cargoName = row[0]?.trim();
      if (!cargoName) continue;
      const cargoId = toSlug(cargoName);
      if (seenCargos.has(cargoId)) {
        diagnosticos.push({ severity: "aviso", categoria: "Matriz", mensagem: `Cargo duplicado: "${cargoName}"` });
      } else {
        seenCargos.add(cargoId);
        cargos.push({ cargoId, cargoName });
      }
      for (const [colIdxStr, capId] of Object.entries(colCapMap)) {
        const cellVal = row[Number(colIdxStr)]?.trim() ?? "";
        if (!cellVal) continue;
        const levels = parseNivelRefs(cellVal);
        const parsingStatus = levels.length > 0 ? "parsed" : cellVal ? "partial" : "unparsed";
        expectations.push({
          cargoId,
          cargoName,
          capabilityId: capId,
          expectedDescription: cellVal,
          referencedLevels: levels,
          sourceValue: cellVal,
          parsingStatus
        });
      }
    }
    diagnosticos.push({ severity: "sucesso", categoria: "Matriz", mensagem: `${cargos.length} cargo(s), ${expectations.length} expectativas` });
    const partial = expectations.filter((e) => e.parsingStatus === "partial").length;
    const unparsed = expectations.filter((e) => e.parsingStatus === "unparsed").length;
    if (partial > 0) diagnosticos.push({ severity: "aviso", categoria: "Matriz", mensagem: `${partial} expectativa(s) sem refer\xEAncia N1\u2013N5 (parsingStatus: partial)` });
    if (unparsed > 0) diagnosticos.push({ severity: "aviso", categoria: "Matriz", mensagem: `${unparsed} expectativa(s) n\xE3o interpretadas` });
    return { cargos, expectations, diagnosticos };
  }

  // ../../src/parsers/parseMergeSkills.ts
  var import_papaparse3 = __toESM(require_papaparse_min(), 1);
  function parseMergeSkills(raw, sourceFile) {
    const result = import_papaparse3.default.parse(raw, { delimiter: ";", skipEmptyLines: false });
    const rows = result.data;
    const diagnosticos = [];
    const entries = [];
    let headerRowIdx = -1, idColIdx = -1;
    for (let i = 0; i < rows.length; i++) {
      const idx = rows[i].findIndex((c) => c.trim() === "ID");
      if (idx !== -1) {
        headerRowIdx = i;
        idColIdx = idx;
        break;
      }
    }
    if (headerRowIdx === -1) {
      diagnosticos.push({ severity: "erro", categoria: sourceFile, mensagem: "Coluna 'ID' n\xE3o encontrada" });
      return { entries, specIds: [], diagnosticos };
    }
    const headerRow = rows[headerRowIdx];
    const specIds = headerRow.slice(0, idColIdx).map((s) => s.trim()).filter((s) => s !== "");
    const seenCombos = /* @__PURE__ */ new Set();
    for (let i = headerRowIdx + 1; i < rows.length; i++) {
      const row = rows[i];
      if (row.every((c) => !c.trim())) continue;
      const capId = row[idColIdx]?.trim();
      if (!capId) continue;
      if (!ALL_CAPS.includes(capId)) {
        diagnosticos.push({ severity: "aviso", categoria: sourceFile, mensagem: `ID desconhecido: "${capId}" \u2014 ignorado` });
        continue;
      }
      if (!capId.startsWith("H")) {
        diagnosticos.push({ severity: "aviso", categoria: sourceFile, mensagem: `${capId} n\xE3o \xE9 Hard Skill \u2014 ignorado (apenas H1\u2013H10)` });
        continue;
      }
      for (let si = 0; si < specIds.length; si++) {
        const specId = specIds[si];
        const val = row[si]?.trim() ?? "";
        const applicable = val.toUpperCase() === "X";
        if (val !== "" && val.toUpperCase() !== "X")
          diagnosticos.push({ severity: "aviso", categoria: sourceFile, mensagem: `Valor desconhecido: coluna ${specId}, capability ${capId}: "${val}"` });
        const key = `${capId}|${specId}`;
        if (seenCombos.has(key)) {
          diagnosticos.push({ severity: "aviso", categoria: sourceFile, mensagem: `Duplicidade: ${capId} \xD7 ${specId}` });
          continue;
        }
        seenCombos.add(key);
        entries.push({ capabilityId: capId, specializationId: specId, applicable, sourceFile });
      }
    }
    diagnosticos.push({
      severity: "sucesso",
      categoria: sourceFile,
      mensagem: `${entries.filter((e) => e.applicable).length} combina\xE7\xF5es aplic\xE1veis (${specIds.join(", ")})`
    });
    return { entries, specIds, diagnosticos };
  }

  // ../../src/electron/shared/courseCatalogParser.ts
  var import_papaparse4 = __toESM(require_papaparse_min(), 1);
  function clean(value) {
    return value?.trim().replace(/\s+/g, " ") ?? "";
  }
  function parseCourseCatalogCsv(csv) {
    const parsed = import_papaparse4.default.parse(csv.replace(/^\uFEFF/, ""), {
      header: true,
      delimiter: ";",
      skipEmptyLines: "greedy"
    });
    const warnings = parsed.errors.map(
      (error) => `Linha ${(error.row ?? 0) + 2}: ${error.message}`
    );
    const tracks = [];
    for (const [index, row] of parsed.data.entries()) {
      const capabilityKey = clean(row.ID).toUpperCase();
      if (!capabilityKey) {
        warnings.push(`Linha ${index + 2}: ID da capacidade ausente.`);
        continue;
      }
      const courses = [1, 2, 3].flatMap((option) => {
        const title = clean(row[`Curso (Op\xE7\xE3o ${option})`]);
        const url = clean(row[`Link ${option}`]);
        if (!title && !url) return [];
        if (!title || !/^https:\/\//iu.test(url)) {
          warnings.push(`Linha ${index + 2}: curso ${option} ignorado por t\xEDtulo ou link inv\xE1lido.`);
          return [];
        }
        return [{ title, url }];
      });
      tracks.push({
        capabilityKey,
        trackName: clean(row["Capabilidade / Trilha"]),
        objective: clean(row["Objetivo da trilha"]),
        expectedOutcome: clean(row["Resultado esperado ao concluir"]),
        recommendedLevel: clean(row["N\xEDvel recomendado"]),
        careerConnection: clean(row["Conex\xE3o Sou Bradesco e Carreira"]),
        courses
      });
    }
    return { tracks, warnings };
  }

  // src/framework/bundledDefaults.ts
  function createBundledFramework() {
    const capabilityResult = parseDescritivoSkill(capabilities_default);
    const matrixResult = parseMatrizCapabilidades(capability_expectations_default);
    const ux = parseMergeSkills(specialization_ux_default, "specialization-ux.csv");
    const designOps = parseMergeSkills(
      specialization_designops_default,
      "specialization-designops.csv"
    );
    const specializationIds = [.../* @__PURE__ */ new Set([...ux.specIds, ...designOps.specIds])];
    const applicability = includeDefaultSoftSkillApplicability(
      [...ux.entries, ...designOps.entries],
      specializationIds
    );
    return {
      id: "bundled-skill-mapping-framework",
      name: "Framework Skill Mapping",
      version: 1,
      capabilities: capabilityResult.capabilities.map((capability) => ({
        id: capability.id,
        name: capability.nome,
        type: capability.tipo === "Hard Skill" ? "hard" : "soft",
        definition: capability.definicao
      })),
      roles: matrixResult.cargos.map((role) => ({
        id: role.cargoId,
        name: role.cargoName,
        expectations: matrixResult.expectations.filter((expectation) => expectation.cargoId === role.cargoId).map((expectation) => ({
          capabilityId: expectation.capabilityId,
          description: expectation.expectedDescription,
          referencedLevels: expectation.referencedLevels,
          parsingStatus: expectation.parsingStatus
        }))
      })),
      specializations: specializationIds.map((specializationId) => ({
        id: specializationId,
        name: SPEC_DISPLAY[specializationId] ?? specializationId,
        group: SPEC_GROUP[specializationId] ?? "Design",
        capabilityApplicability: applicability.filter((item) => item.specializationId === specializationId).map((item) => ({
          capabilityId: item.capabilityId,
          applicable: item.applicable
        }))
      }))
    };
  }
  function readBundledCatalog() {
    const parsed = parseCourseCatalogCsv(cursos_default);
    return {
      catalog: parsed.tracks.flatMap(
        (track) => track.courses.map((course) => ({
          id: `course-${track.capabilityKey.toLowerCase()}-${checksum(course.url)}`,
          title: course.title,
          capabilityIds: [track.capabilityKey],
          level: track.recommendedLevel || null,
          url: course.url,
          trackName: track.trackName,
          objective: track.objective,
          expectedOutcome: track.expectedOutcome,
          careerConnection: track.careerConnection
        }))
      ),
      warnings: parsed.warnings
    };
  }
  function createBundledCatalog() {
    return readBundledCatalog().catalog;
  }
  function createBundledWorkspace(documentName, now = /* @__PURE__ */ new Date()) {
    const timestamp2 = now.toISOString();
    return {
      workspace: {
        id: `workspace-${checksum(`${documentName}:${timestamp2}`)}`,
        name: documentName.trim() || "Skill Mapping",
        importedAt: timestamp2,
        sourceFileName: null,
        sourceHash: null
      },
      framework: createBundledFramework(),
      people: [],
      assessments: [],
      results: [],
      groups: [],
      catalog: createBundledCatalog(),
      cycles: [],
      developmentActions: [],
      reportRecords: []
    };
  }

  // src/analytics/evolutionEngine.ts
  function mean2(values) {
    return values.length > 0 ? values.reduce((total, value) => total + value, 0) / values.length : null;
  }
  function observedStatus(delta) {
    if (delta === null) return "insufficient";
    if (delta > 0) return "advance";
    if (delta < 0) return "regression";
    return "stable";
  }
  function latestAssessment(items) {
    return [...items].sort(
      (left, right) => (right.completedAt ?? "").localeCompare(left.completedAt ?? "") || right.id.localeCompare(left.id)
    )[0] ?? null;
  }
  function compareBasis(baseline, followup, baselineFramework, followupFramework) {
    if (!baseline) return { status: "baseline_missing", explanation: "N\xE3o h\xE1 assessment no ciclo baseline." };
    if (!followup) return { status: "followup_missing", explanation: "N\xE3o h\xE1 assessment no ciclo follow-up." };
    if (!baseline.methodologyBasis || !followup.methodologyBasis) {
      return { status: "basis_unknown", explanation: "A base metodol\xF3gica n\xE3o foi registrada em um dos assessments." };
    }
    if (!baselineFramework || !followupFramework) {
      return { status: "basis_unknown", explanation: "A c\xF3pia hist\xF3rica do framework ainda n\xE3o foi confirmada para um dos ciclos." };
    }
    if (baseline.methodologyBasis.frameworkId !== baselineFramework.id || baseline.methodologyBasis.frameworkVersion !== baselineFramework.version || followup.methodologyBasis.frameworkId !== followupFramework.id || followup.methodologyBasis.frameworkVersion !== followupFramework.version) {
      return { status: "framework_changed", explanation: "A base de um assessment difere do framework hist\xF3rico registrado em seu ciclo." };
    }
    if (baseline.methodologyBasis.frameworkId !== followup.methodologyBasis.frameworkId || baseline.methodologyBasis.frameworkVersion !== followup.methodologyBasis.frameworkVersion) {
      return { status: "framework_changed", explanation: "O framework ou sua vers\xE3o mudou entre os ciclos." };
    }
    if (baseline.methodologyBasis.roleId !== followup.methodologyBasis.roleId) {
      return { status: "role_changed", explanation: "O cargo mudou entre os ciclos; o resultado n\xE3o recebe delta." };
    }
    if (baseline.methodologyBasis.specializationId !== followup.methodologyBasis.specializationId) {
      return { status: "specialization_changed", explanation: "A especializa\xE7\xE3o mudou entre os ciclos; o resultado n\xE3o recebe delta." };
    }
    return { status: "comparable", explanation: "Mesma pessoa, framework, cargo e especializa\xE7\xE3o nos dois ciclos." };
  }
  function scopeAssessmentIds(snapshot, request) {
    if (request.scope.type === "workspace") return null;
    if (request.scope.type === "person") {
      const personId = request.scope.personId;
      return new Set(snapshot.assessments.filter((assessment) => assessment.personId === personId).map((assessment) => assessment.id));
    }
    const groupId = request.scope.groupId;
    const group = snapshot.groups.find((item) => item.id === groupId);
    if (!group) throw new Error("O grupo escolhido para evolu\xE7\xE3o n\xE3o existe mais.");
    return new Set(readGroupComputed(group).assessmentIds);
  }
  function frameworkLabels(assessments) {
    return [...new Set(assessments.map((assessment) => assessment.methodologyBasis ? `${assessment.methodologyBasis.frameworkId} \xB7 v${assessment.methodologyBasis.frameworkVersion}` : "Base n\xE3o registrada"))].sort();
  }
  function buildEvolutionAnalysis(snapshot, request) {
    if (request.baselineCycleId === request.followupCycleId) {
      throw new Error("Selecione ciclos diferentes para baseline e follow-up.");
    }
    const cycles = hydrateCycles(snapshot);
    const baselineCycle = cycles.find((cycle) => cycle.id === request.baselineCycleId);
    const followupCycle = cycles.find((cycle) => cycle.id === request.followupCycleId);
    if (!baselineCycle || !followupCycle) throw new Error("Um dos ciclos selecionados n\xE3o existe mais.");
    const allowedIds = scopeAssessmentIds(snapshot, request);
    const scoped = snapshot.assessments.filter(
      (assessment) => !allowedIds || allowedIds.has(assessment.id)
    );
    const baselineAssessments = scoped.filter(
      (assessment) => readAssessmentCycleId(assessment) === baselineCycle.id
    );
    const followupAssessments = scoped.filter(
      (assessment) => readAssessmentCycleId(assessment) === followupCycle.id
    );
    const personIds = [.../* @__PURE__ */ new Set([
      ...baselineAssessments.map((assessment) => assessment.personId),
      ...followupAssessments.map((assessment) => assessment.personId)
    ])];
    const warnings = [];
    const duplicatePeople = personIds.filter(
      (personId) => baselineAssessments.filter((assessment) => assessment.personId === personId).length > 1 || followupAssessments.filter((assessment) => assessment.personId === personId).length > 1
    );
    if (duplicatePeople.length > 0) {
      warnings.push(`${duplicatePeople.length} pessoa(s) possuem m\xFAltiplos assessments no mesmo ciclo; foi usado o mais recente.`);
    }
    const pairs = personIds.map((personId) => {
      const baseline = latestAssessment(baselineAssessments.filter((item) => item.personId === personId));
      const followup = latestAssessment(followupAssessments.filter((item) => item.personId === personId));
      return {
        personId,
        baseline,
        followup,
        ...compareBasis(
          baseline,
          followup,
          baselineCycle.frameworkSnapshot,
          followupCycle.frameworkSnapshot
        )
      };
    });
    const comparable = pairs.filter((pair) => pair.status === "comparable" && pair.baseline && pair.followup);
    const analyses = comparable.map((pair) => ({
      pair,
      baseline: buildIndividualAnalysis({
        ...snapshot,
        framework: baselineCycle.frameworkSnapshot ?? snapshot.framework
      }, pair.baseline.id),
      followup: buildIndividualAnalysis({
        ...snapshot,
        framework: followupCycle.frameworkSnapshot ?? snapshot.framework
      }, pair.followup.id)
    }));
    const overallPairs = analyses.flatMap(
      (item) => item.baseline.overallPercentage !== null && item.followup.overallPercentage !== null ? [{ baseline: item.baseline.overallPercentage, followup: item.followup.overallPercentage }] : []
    );
    const overallBaseline = mean2(overallPairs.map((item) => item.baseline));
    const overallFollowup = mean2(overallPairs.map((item) => item.followup));
    const overallDelta = overallBaseline !== null && overallFollowup !== null ? overallFollowup - overallBaseline : null;
    const pairOverallStatuses = analyses.map(
      (item) => item.baseline.overallPercentage !== null && item.followup.overallPercentage !== null ? observedStatus(item.followup.overallPercentage - item.baseline.overallPercentage) : "insufficient"
    );
    const capabilities = snapshot.framework.capabilities.map((capability) => {
      const values = analyses.flatMap((item) => {
        const baseline = item.baseline.capabilities.find((entry) => entry.capabilityId === capability.id)?.aggregatePercentage ?? null;
        const followup = item.followup.capabilities.find((entry) => entry.capabilityId === capability.id)?.aggregatePercentage ?? null;
        return baseline !== null && followup !== null ? [{ baseline, followup }] : [];
      });
      const baselineAverage = mean2(values.map((item) => item.baseline));
      const followupAverage = mean2(values.map((item) => item.followup));
      const delta = baselineAverage !== null && followupAverage !== null ? followupAverage - baselineAverage : null;
      const statuses = values.map((item) => observedStatus(item.followup - item.baseline));
      return {
        capabilityId: capability.id,
        capabilityName: capability.name,
        capabilityType: capability.type,
        baselineAveragePercentage: baselineAverage,
        followupAveragePercentage: followupAverage,
        differencePercentagePoints: delta,
        status: observedStatus(delta),
        comparablePairs: values.length,
        peopleInScope: pairs.length,
        advanceCount: statuses.filter((status) => status === "advance").length,
        stableCount: statuses.filter((status) => status === "stable").length,
        regressionCount: statuses.filter((status) => status === "regression").length,
        insufficientCount: pairs.length - values.length
      };
    }).sort((left, right) => {
      if (left.differencePercentagePoints === null) return 1;
      if (right.differencePercentagePoints === null) return -1;
      return Math.abs(right.differencePercentagePoints) - Math.abs(left.differencePercentagePoints);
    });
    const contextChangedStatuses = ["framework_changed", "role_changed", "specialization_changed"];
    const selectedPersonId = request.scope.type === "person" ? request.scope.personId : null;
    const personRecord = selectedPersonId ? snapshot.people.find((person) => person.id === selectedPersonId) ?? null : null;
    const personPair = selectedPersonId ? pairs.find((pair) => pair.personId === selectedPersonId) ?? null : null;
    let scopeLabel = "Todo o workspace";
    if (request.scope.type === "group") {
      const groupId = request.scope.groupId;
      scopeLabel = snapshot.groups.find((group) => group.id === groupId)?.name ?? "Grupo removido";
    } else if (request.scope.type === "person") {
      scopeLabel = personRecord?.name ?? "Pessoa n\xE3o encontrada";
    }
    if (pairs.some((pair) => pair.status === "basis_unknown")) {
      warnings.push("H\xE1 assessments antigos sem base hist\xF3rica confirmada; eles n\xE3o foram usados nos deltas.");
    }
    if (pairs.some((pair) => contextChangedStatuses.includes(pair.status))) {
      warnings.push("Mudan\xE7as de framework, cargo ou especializa\xE7\xE3o foram separadas da evolu\xE7\xE3o observada.");
    }
    return {
      request,
      scopeLabel,
      baseline: {
        cycleId: baselineCycle.id,
        cycleName: baselineCycle.name,
        frameworkLabels: frameworkLabels(baselineAssessments)
      },
      followup: {
        cycleId: followupCycle.id,
        cycleName: followupCycle.name,
        frameworkLabels: frameworkLabels(followupAssessments)
      },
      summary: {
        peopleInScope: pairs.length,
        comparablePeople: comparable.length,
        baselineOnlyPeople: pairs.filter((pair) => pair.status === "followup_missing").length,
        followupOnlyPeople: pairs.filter((pair) => pair.status === "baseline_missing").length,
        contextChangedPeople: pairs.filter((pair) => contextChangedStatuses.includes(pair.status)).length,
        insufficientPeople: pairs.filter((pair) => pair.status === "basis_unknown").length,
        advanceCount: pairOverallStatuses.filter((status) => status === "advance").length,
        stableCount: pairOverallStatuses.filter((status) => status === "stable").length,
        regressionCount: pairOverallStatuses.filter((status) => status === "regression").length
      },
      overall: {
        baselineAveragePercentage: overallBaseline,
        followupAveragePercentage: overallFollowup,
        differencePercentagePoints: overallDelta,
        status: observedStatus(overallDelta),
        comparablePairs: overallPairs.length
      },
      capabilities,
      person: personRecord ? {
        personId: personRecord.id,
        personName: personRecord.name,
        baselineAssessmentId: personPair?.baseline?.id ?? null,
        followupAssessmentId: personPair?.followup?.id ?? null,
        comparisonStatus: personPair?.status ?? "baseline_missing",
        explanation: personPair?.explanation ?? "A pessoa n\xE3o possui assessments nos ciclos selecionados."
      } : null,
      warnings
    };
  }

  // src/development/developmentPlan.ts
  function unique(values) {
    return [...new Set(values.map((value) => value.trim()).filter(Boolean))];
  }
  function saveDevelopmentAction(snapshot, input, now = /* @__PURE__ */ new Date()) {
    const person = snapshot.people.find((item) => item.id === input.personId);
    if (!person) throw new Error("A pessoa da a\xE7\xE3o de desenvolvimento n\xE3o existe mais.");
    if (input.assessmentId) {
      const assessment = snapshot.assessments.find((item) => item.id === input.assessmentId);
      if (!assessment || assessment.personId !== person.id) {
        throw new Error("O assessment de origem n\xE3o pertence \xE0 pessoa selecionada.");
      }
    }
    const capabilityIds = unique(input.capabilityIds);
    const unknownCapabilities = capabilityIds.filter(
      (id) => !snapshot.framework.capabilities.some((capability) => capability.id === id)
    );
    if (capabilityIds.length === 0 || unknownCapabilities.length > 0) {
      throw new Error("A a\xE7\xE3o precisa estar relacionada a capabilities v\xE1lidas.");
    }
    if (input.courseId && !snapshot.catalog.some((course) => course.id === input.courseId)) {
      throw new Error("O curso de origem n\xE3o existe mais no cat\xE1logo.");
    }
    const title = input.title.trim();
    if (!title) throw new Error("Informe o t\xEDtulo da a\xE7\xE3o de desenvolvimento.");
    const owner = input.owner.trim();
    if (input.status !== "dismissed" && !owner) {
      throw new Error("Informe a pessoa respons\xE1vel pela a\xE7\xE3o.");
    }
    if (input.dueDate && !/^\d{4}-\d{2}-\d{2}$/u.test(input.dueDate)) {
      throw new Error("O prazo da a\xE7\xE3o deve usar o formato AAAA-MM-DD.");
    }
    const actions = snapshot.developmentActions ?? [];
    const existing = input.id ? actions.find((action2) => action2.id === input.id) : null;
    if (input.id && !existing) throw new Error("A a\xE7\xE3o editada n\xE3o existe mais.");
    if (input.courseId && input.status !== "dismissed" && actions.some(
      (action2) => action2.id !== input.id && action2.personId === input.personId && action2.courseId === input.courseId && action2.status !== "dismissed"
    )) {
      throw new Error("Este curso j\xE1 possui uma a\xE7\xE3o ativa para a pessoa selecionada.");
    }
    const timestamp2 = now.toISOString();
    const action = {
      id: existing?.id ?? `development-${now.getTime().toString(36)}-${Math.random().toString(36).slice(2, 7)}`,
      personId: input.personId,
      assessmentId: input.assessmentId,
      capabilityIds,
      courseId: input.courseId,
      title,
      description: input.description.trim(),
      decision: input.decision,
      priority: input.priority,
      dueDate: input.dueDate || null,
      owner,
      status: input.status,
      createdAt: existing?.createdAt ?? timestamp2,
      updatedAt: timestamp2
    };
    return {
      snapshot: {
        ...snapshot,
        developmentActions: [...actions.filter((item) => item.id !== action.id), action]
      },
      action
    };
  }
  function deleteDevelopmentAction(snapshot, actionId) {
    const actions = snapshot.developmentActions ?? [];
    if (!actions.some((action) => action.id === actionId)) {
      throw new Error("A a\xE7\xE3o de desenvolvimento n\xE3o existe mais.");
    }
    return { ...snapshot, developmentActions: actions.filter((action) => action.id !== actionId) };
  }

  // src/code.ts
  var STORAGE_PROOF_CACHE_KEY = "skill-mapping:last-storage-proof";
  var UI_SIZE_CACHE_KEY = "skill-mapping:ui-size";
  var UI_DIMENSIONS = {
    compact: { width: 480, height: 720 },
    workspace: { width: 840, height: 800 },
    wide: { width: 1040, height: 860 }
  };
  var workspaceStore = new DocumentWorkspaceStore(figma.root);
  figma.showUI(__html__, {
    ...UI_DIMENSIONS.workspace,
    title: "Skill Mapping",
    themeColors: true
  });
  function postToUi(message) {
    figma.ui.postMessage(message);
  }
  function ensureBundledWorkspace() {
    const current = workspaceStore.loadActiveWorkspace();
    const currentSummary = workspaceStore.getActiveSummary();
    if (current && currentSummary) {
      return { snapshot: current, summary: currentSummary, created: false };
    }
    const schema = workspaceStore.ensureSchema();
    const snapshot = createBundledWorkspace(figma.root.name);
    const summary = workspaceStore.writeWorkspace(snapshot, {
      expectedRevision: schema.revision
    });
    return { snapshot, summary, created: true };
  }
  async function sendBootstrap() {
    const storedUiSize = await figma.clientStorage.getAsync(UI_SIZE_CACHE_KEY);
    const uiSize = storedUiSize === "compact" || storedUiSize === "wide" ? storedUiSize : "workspace";
    figma.ui.resize(UI_DIMENSIONS[uiSize].width, UI_DIMENSIONS[uiSize].height);
    const lastStorageProof = await figma.clientStorage.getAsync(
      STORAGE_PROOF_CACHE_KEY
    );
    const existingSchema = workspaceStore.readSchema();
    const initialized = existingSchema ? ensureBundledWorkspace() : null;
    const activeWorkspace = initialized?.snapshot ?? null;
    const payload = {
      documentName: figma.root.name,
      editorType: figma.editorType,
      schema: workspaceStore.readSchema(),
      supportedPlan: "professional-or-higher",
      storageSummary: initialized?.summary ?? null,
      lastStorageProof: lastStorageProof ?? null,
      operationalState: toOperationalState(activeWorkspace),
      uiSize
    };
    postToUi({ type: "plugin/bootstrap", payload });
  }
  function postError(error) {
    postToUi({
      type: "plugin/error",
      message: error instanceof Error ? error.message : "Falha inesperada ao processar a opera\xE7\xE3o."
    });
  }
  function persistWorkspaceUpdate(snapshot, announcement, notifyUser = true) {
    const schema = workspaceStore.ensureSchema();
    const summary = workspaceStore.writeWorkspace(snapshot, {
      expectedRevision: schema.revision
    });
    const operationalState = toOperationalState(snapshot);
    if (!operationalState) throw new Error("O workspace atualizado n\xE3o p\xF4de ser reconstru\xEDdo.");
    postToUi({
      type: "workspace/updated",
      payload: { summary, operationalState, announcement }
    });
    if (notifyUser) figma.notify(announcement);
  }
  figma.ui.onmessage = async (message) => {
    if (!isUiToPluginMessage(message)) {
      postToUi({
        type: "plugin/error",
        message: "O plugin recebeu uma mensagem inv\xE1lida da interface."
      });
      return;
    }
    try {
      if (message.type === "ui/resize") {
        const dimensions = UI_DIMENSIONS[message.size];
        figma.ui.resize(dimensions.width, dimensions.height);
        await figma.clientStorage.setAsync(UI_SIZE_CACHE_KEY, message.size);
        postToUi({ type: "ui/resized", size: message.size });
        return;
      }
      if (message.type === "ui/ready") {
        await sendBootstrap();
        return;
      }
      if (message.type === "schema/initialize") {
        const existingSchema = workspaceStore.readSchema();
        workspaceStore.ensureSchema();
        const initialized = ensureBundledWorkspace();
        const schema = workspaceStore.readSchema();
        if (!schema) throw new Error("O schema do workspace n\xE3o p\xF4de ser confirmado.");
        const operationalState = toOperationalState(initialized.snapshot);
        if (!operationalState) throw new Error("O framework padr\xE3o n\xE3o p\xF4de ser reconstru\xEDdo.");
        postToUi({ type: "schema/initialized", payload: schema });
        postToUi({
          type: "workspace/updated",
          payload: {
            summary: initialized.summary,
            operationalState,
            announcement: initialized.created ? "Workspace preparado com framework e cat\xE1logo padr\xE3o." : "Workspace existente carregado."
          }
        });
        if (!existingSchema || initialized.created) {
          figma.notify("Framework e cat\xE1logo padr\xE3o preparados neste arquivo.");
        }
        return;
      }
      if (message.type === "storage/run-synthetic-proof") {
        const current = workspaceStore.loadActiveWorkspace();
        if (current && (current.people.length > 0 || current.assessments.length > 0 || current.results.length > 0)) {
          throw new Error(
            "A prova sint\xE9tica exige um workspace sem pessoas ou assessments. Exporte um backup e restaure o template antes de execut\xE1-la."
          );
        }
        postToUi({ type: "storage/working", action: "proof" });
        const metrics = workspaceStore.runProof(createSyntheticWorkspace());
        await figma.clientStorage.setAsync(STORAGE_PROOF_CACHE_KEY, metrics);
        postToUi({ type: "storage/proof-complete", payload: metrics });
        figma.notify("Prova sint\xE9tica conclu\xEDda com 12.000 resultados.");
        return;
      }
      if (message.type === "storage/clear") {
        postToUi({ type: "storage/working", action: "clear" });
        workspaceStore.clearWorkspace();
        await figma.clientStorage.deleteAsync(STORAGE_PROOF_CACHE_KEY);
        const initialized = ensureBundledWorkspace();
        const schema = workspaceStore.readSchema();
        if (!schema) throw new Error("O schema n\xE3o foi preservado ap\xF3s a limpeza.");
        const operationalState = toOperationalState(initialized.snapshot);
        if (!operationalState) throw new Error("O template padr\xE3o n\xE3o p\xF4de ser reconstru\xEDdo.");
        postToUi({
          type: "storage/cleared",
          schema,
          summary: initialized.summary,
          operationalState
        });
        figma.notify("Dados removidos e framework padr\xE3o restaurado.");
        return;
      }
      if (message.type === "assessment-import/commit") {
        postToUi({ type: "storage/working", action: "import" });
        const current = workspaceStore.loadActiveWorkspace();
        const merged = mergeAssessmentImport(current, message.payload);
        const schema = workspaceStore.ensureSchema();
        const summary = workspaceStore.writeWorkspace(merged.snapshot, {
          expectedRevision: schema.revision
        });
        postToUi({
          type: "assessment-import/committed",
          payload: {
            summary,
            importedPeople: merged.importedPeople,
            importedAssessments: merged.importedAssessments,
            importedResults: merged.importedResults
          }
        });
        figma.notify(
          `${merged.importedAssessments} assessment(s) importado(s) no workspace.`
        );
        return;
      }
      if (message.type === "context/apply") {
        postToUi({ type: "storage/working", action: "context" });
        const current = workspaceStore.loadActiveWorkspace();
        if (!current) throw new Error("N\xE3o h\xE1 workspace ativo para contextualizar.");
        const updated = applyAssessmentContext(current, message.payload);
        const schema = workspaceStore.ensureSchema();
        const summary = workspaceStore.writeWorkspace(updated.snapshot, {
          expectedRevision: schema.revision
        });
        const operationalState = toOperationalState(updated.snapshot);
        if (!operationalState) throw new Error("O contexto n\xE3o p\xF4de ser reconstru\xEDdo.");
        postToUi({
          type: "context/applied",
          payload: {
            summary,
            operationalState,
            updatedAssessments: updated.updatedAssessments
          }
        });
        figma.notify(
          `Contexto aplicado a ${updated.updatedAssessments} assessment(s).`
        );
        return;
      }
      if (message.type === "analytics/individual") {
        postToUi({ type: "storage/working", action: "analytics" });
        const current = workspaceStore.loadActiveWorkspace();
        if (!current) throw new Error("N\xE3o h\xE1 workspace ativo para analisar.");
        postToUi({
          type: "analytics/individual-ready",
          payload: buildIndividualAnalysis(current, message.assessmentId)
        });
        return;
      }
      if (message.type === "analytics/collective") {
        postToUi({ type: "storage/working", action: "analytics" });
        const current = workspaceStore.loadActiveWorkspace();
        if (!current) throw new Error("N\xE3o h\xE1 workspace ativo para analisar.");
        postToUi({
          type: "analytics/collective-ready",
          payload: buildCollectiveAnalysis(current, message.filters)
        });
        return;
      }
      if (message.type === "analytics/group-comparison") {
        postToUi({ type: "storage/working", action: "analytics" });
        const current = workspaceStore.loadActiveWorkspace();
        if (!current) throw new Error("N\xE3o h\xE1 workspace ativo para comparar grupos.");
        postToUi({
          type: "analytics/group-comparison-ready",
          payload: "groupIds" in message ? buildMultiGroupComparison(current, message.groupIds) : buildGroupComparison(current, message.leftGroupId, message.rightGroupId)
        });
        return;
      }
      if (message.type === "analytics/evolution") {
        postToUi({ type: "storage/working", action: "analytics" });
        const current = workspaceStore.loadActiveWorkspace();
        if (!current) throw new Error("N\xE3o h\xE1 workspace ativo para comparar ciclos.");
        postToUi({
          type: "analytics/evolution-ready",
          payload: buildEvolutionAnalysis(current, message.payload)
        });
        return;
      }
      if (message.type === "reports/generate") {
        postToUi({ type: "storage/working", action: "report" });
        const current = workspaceStore.loadActiveWorkspace();
        if (!current) throw new Error("N\xE3o h\xE1 workspace ativo para gerar relat\xF3rios.");
        const request = message.payload;
        const model = buildReportModelForRequest(current, request);
        const result = await renderReportToCanvas(model, request.strategy);
        persistWorkspaceUpdate(
          recordReportGeneration(current, request, model, result),
          "Invent\xE1rio de relat\xF3rios atualizado.",
          false
        );
        postToUi({ type: "reports/generated", payload: result });
        const actionLabel = result.action === "unchanged" ? "j\xE1 estava atualizado" : result.action === "duplicated-to-preserve-edits" ? "foi duplicado para preservar edi\xE7\xF5es manuais" : "foi gerado no canvas";
        figma.notify(`O relat\xF3rio ${actionLabel}.`);
        return;
      }
      if (message.type === "reports/generate-batch") {
        postToUi({ type: "storage/working", action: "report" });
        const current = workspaceStore.loadActiveWorkspace();
        if (!current) throw new Error("N\xE3o h\xE1 workspace ativo para gerar relat\xF3rios.");
        const assessmentIds = [...new Set(message.payload.assessmentIds)];
        if (assessmentIds.length === 0) throw new Error("O lote n\xE3o possui assessments selecionados.");
        if (assessmentIds.length > 200) throw new Error("O lote pode gerar no m\xE1ximo 200 relat\xF3rios por execu\xE7\xE3o.");
        let updated = current;
        const completed = [];
        const failures = [];
        for (const assessmentId of assessmentIds) {
          const request = {
            target: "individual",
            assessmentId,
            strategy: message.payload.strategy,
            composition: message.payload.composition
          };
          try {
            const model = buildReportModelForRequest(updated, request);
            const result = await renderReportToCanvas(model, request.strategy);
            updated = recordReportGeneration(updated, request, model, result);
            completed.push(result);
          } catch (error) {
            failures.push({
              assessmentId,
              message: error instanceof Error ? error.message : "Falha inesperada ao gerar o relat\xF3rio."
            });
          }
        }
        if (completed.length > 0) {
          persistWorkspaceUpdate(
            updated,
            `Invent\xE1rio atualizado com ${completed.length} relat\xF3rio(s) do lote.`,
            false
          );
        }
        postToUi({
          type: "reports/batch-generated",
          payload: { requested: assessmentIds.length, completed, failures }
        });
        figma.notify(`${completed.length}/${assessmentIds.length} relat\xF3rio(s) gerado(s) no lote.`);
        return;
      }
      if (message.type === "group/save") {
        postToUi({ type: "storage/working", action: "group" });
        const current = workspaceStore.loadActiveWorkspace();
        if (!current) throw new Error("N\xE3o h\xE1 workspace ativo para criar grupos.");
        const updated = saveGroup(current, message.payload);
        persistWorkspaceUpdate(
          updated.snapshot,
          `Grupo \u201C${updated.group.name}\u201D salvo com ${updated.group.assessmentIds?.length ?? 0} assessment(s).`
        );
        return;
      }
      if (message.type === "group/delete") {
        postToUi({ type: "storage/working", action: "delete" });
        const current = workspaceStore.loadActiveWorkspace();
        if (!current) throw new Error("N\xE3o h\xE1 workspace ativo para excluir grupos.");
        persistWorkspaceUpdate(
          deleteGroup(current, message.groupId),
          "Grupo removido do workspace."
        );
        return;
      }
      if (message.type === "group/duplicate") {
        postToUi({ type: "storage/working", action: "group" });
        const current = workspaceStore.loadActiveWorkspace();
        if (!current) throw new Error("N\xE3o h\xE1 workspace ativo para duplicar grupos.");
        const updated = duplicateGroup(current, message.groupId);
        persistWorkspaceUpdate(
          updated.snapshot,
          `Grupo \u201C${updated.group.name}\u201D duplicado com ${updated.group.assessmentIds?.length ?? 0} assessment(s).`
        );
        return;
      }
      if (message.type === "cycle/save") {
        postToUi({ type: "storage/working", action: "cycle" });
        const current = workspaceStore.loadActiveWorkspace();
        if (!current) throw new Error("N\xE3o h\xE1 workspace ativo para salvar ciclos.");
        const updated = saveCycle(current, message.payload);
        persistWorkspaceUpdate(updated.snapshot, `Ciclo \u201C${updated.cycle.name}\u201D salvo.`);
        return;
      }
      if (message.type === "cycle/register-basis") {
        postToUi({ type: "storage/working", action: "cycle" });
        const current = workspaceStore.loadActiveWorkspace();
        if (!current) throw new Error("N\xE3o h\xE1 workspace ativo para registrar a base hist\xF3rica.");
        const updated = registerLegacyCycleBasis(current, message.cycleId);
        persistWorkspaceUpdate(
          updated.snapshot,
          `Base hist\xF3rica registrada em ${updated.updatedAssessments} assessment(s).`
        );
        return;
      }
      if (message.type === "development/save") {
        postToUi({ type: "storage/working", action: "development" });
        const current = workspaceStore.loadActiveWorkspace();
        if (!current) throw new Error("N\xE3o h\xE1 workspace ativo para salvar o plano.");
        const updated = saveDevelopmentAction(current, message.payload);
        persistWorkspaceUpdate(updated.snapshot, `A\xE7\xE3o \u201C${updated.action.title}\u201D salva no plano.`);
        return;
      }
      if (message.type === "development/delete") {
        postToUi({ type: "storage/working", action: "development" });
        const current = workspaceStore.loadActiveWorkspace();
        if (!current) throw new Error("N\xE3o h\xE1 workspace ativo para editar o plano.");
        persistWorkspaceUpdate(
          deleteDevelopmentAction(current, message.actionId),
          "A\xE7\xE3o removida do plano de desenvolvimento."
        );
        return;
      }
      if (message.type === "assessments/delete") {
        postToUi({ type: "storage/working", action: "delete" });
        const current = workspaceStore.loadActiveWorkspace();
        if (!current) throw new Error("N\xE3o h\xE1 workspace ativo para excluir assessments.");
        const updated = deleteAssessments(current, message.assessmentIds);
        persistWorkspaceUpdate(
          updated.snapshot,
          `${updated.deletedAssessments} assessment(s) e ${updated.deletedPeople} pessoa(s) sem avalia\xE7\xF5es removidos.`
        );
        return;
      }
      if (message.type === "assessment-result/resolve") {
        postToUi({ type: "storage/working", action: "evidence" });
        const current = workspaceStore.loadActiveWorkspace();
        if (!current) throw new Error("N\xE3o h\xE1 workspace ativo para revisar o resultado.");
        const updated = resolveAssessmentResult(current, message.payload);
        persistWorkspaceUpdate(
          updated,
          message.payload.decision === "confirmed_zero" ? "Resultado confirmado como zero por decis\xE3o humana." : "Resultado mantido como dado ausente por decis\xE3o humana."
        );
        return;
      }
      if (message.type === "assessment-result/undo-resolution") {
        postToUi({ type: "storage/working", action: "evidence" });
        const current = workspaceStore.loadActiveWorkspace();
        if (!current) throw new Error("N\xE3o h\xE1 workspace ativo para desfazer a decis\xE3o.");
        persistWorkspaceUpdate(
          undoAssessmentResultResolution(current, message.payload),
          "Decis\xE3o manual desfeita; o valor original do CSV foi restaurado."
        );
        return;
      }
      if (message.type === "framework/mutate") {
        postToUi({ type: "storage/working", action: "framework" });
        const current = workspaceStore.loadActiveWorkspace();
        if (!current) throw new Error("N\xE3o h\xE1 workspace ativo para editar o framework.");
        const updated = mutateFramework(current, message.payload);
        persistWorkspaceUpdate(
          updated,
          `Framework salvo na vers\xE3o ${updated.framework.version}.`
        );
        return;
      }
      if (message.type === "catalog/mutate") {
        postToUi({ type: "storage/working", action: "catalog" });
        const current = workspaceStore.loadActiveWorkspace();
        if (!current) throw new Error("N\xE3o h\xE1 workspace ativo para editar o cat\xE1logo.");
        const updated = mutateCatalog(current, message.payload);
        persistWorkspaceUpdate(
          updated,
          message.payload.type === "delete-course" ? "Curso removido do cat\xE1logo." : "Curso salvo no cat\xE1logo."
        );
        return;
      }
      if (message.type === "backup/export") {
        postToUi({ type: "storage/working", action: "export" });
        const snapshot = workspaceStore.loadActiveWorkspace();
        if (!snapshot) throw new Error("N\xE3o h\xE1 workspace ativo para exportar.");
        postToUi({
          type: "backup/export-ready",
          fileName: `skill-mapping-backup-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`,
          serialized: serializeWorkspaceBackup(snapshot)
        });
        return;
      }
      if (message.type === "backup/import") {
        postToUi({ type: "storage/working", action: "import" });
        const backup = parseWorkspaceBackup(message.serialized);
        const schema = workspaceStore.ensureSchema();
        const summary = workspaceStore.writeWorkspace(backup.snapshot, {
          expectedRevision: schema.revision
        });
        postToUi({ type: "backup/imported", payload: summary });
        figma.notify("Backup do Skill Mapping restaurado neste documento.");
      }
    } catch (error) {
      postError(error);
    }
  };
})();
/*! Bundled license information:

papaparse/papaparse.min.js:
  (* @license
  Papa Parse
  v5.5.4
  https://github.com/mholt/PapaParse
  License: MIT
  *)
*/
